---
name: academic-brainstorm
description: Shape and stress-test a new economics research idea before implementation, including contribution, feasibility, data, and a plausible identification strategy. Use empirical-workflow once the question is established.
---

# Academic Brainstorm

Use this skill to lock the research design before implementation.

## Required outcome

By the end of the brainstorm, the design must state:

- the causal question
- the unit and time structure
- the treatment, outcome, and variation level
- the comparison group
- the key identifying assumption
- the top 2-3 threats
- the minimum data needed
- the next handoff: `empirical-workflow`, `.codex/PLANS.md`, or implementation

## Workflow

1. Read existing context before asking questions.
   Check the root `README.md`, relevant notes in `00_docs/`, any user-provided memo, draft, paper, or dataset description.

2. Ask only for non-discoverable gaps.
   Ask one major question at a time when the answer materially changes feasibility or design choice.

3. Propose 2-3 identification approaches.
   For each approach, state:
   - strategy
   - required variation
   - key assumption
   - main reviewer concern
   - feasibility verdict: high / medium / low

4. Converge on one recommended design.
   State clearly what the paper claims, what comparison identifies it, and what evidence is required before coding begins.

5. Write a concise design note only when the user wants it persisted.
   Save under `00_docs/` using the repo naming rule `NN-task-name-YYYYMMDD-vN.ext`.

## Output contract

Default response structure:

### Research question

### Candidate approaches

### Recommended design

### Main threats

### Minimum data requirements

### Next handoff

## Rules

- Do not jump to regression code.
- Do not pretend feasibility is better than it is.
- If none of the designs is credible, say so directly.
- If the design is already locked, stop and hand off to `empirical-workflow`, `.codex/PLANS.md`, or the relevant implementation skill.
