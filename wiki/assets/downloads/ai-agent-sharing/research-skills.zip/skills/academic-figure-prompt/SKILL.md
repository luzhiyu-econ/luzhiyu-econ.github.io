---
name: academic-figure-prompt
description: Generate English prompts for external image tools to create academic framework, architecture, pipeline, comparison, or ablation diagrams. Use when the deliverable is a prompt; use academic-figure for data plots and imagegen for direct image creation.
---

# Academic Figure Prompt

Turn a paper's concepts into an executable prompt for a conceptual academic diagram.

## Boundaries

- Produce a prompt, not a data visualization or final bitmap.
- Preserve the user's terminology, causal direction, and module hierarchy.
- Do not imitate a living artist or reproduce a copyrighted figure.
- If the user asks for the image itself, hand off to `imagegen`.

## Workflow

1. Extract the figure's claim, entities, relationships, and reading order.
2. Infer the smallest useful diagram type; ask only if ambiguity changes the figure materially.
3. Define composition, section labels, arrows, annotations, and visual hierarchy.
4. Select an accessible palette and specify typography, spacing, background, and aspect ratio.
5. State exclusions that prevent decorative clutter, fake data, illegible text, and ambiguous arrows.
6. Check that every visual element maps to a concept in the paper.

For palette tables, diagram templates, thumbnail vocabulary, and detailed prompt structure, read `references/prompt-design-guide.md` only when needed.

## Output

Return:

- a short Chinese figure rationale;
- one self-contained English generation prompt;
- an optional negative prompt when the target tool supports it;
- a compact label list with exact spelling.

Prefer precise spatial language over adjectives. Keep detail proportional to the figure's complexity.
