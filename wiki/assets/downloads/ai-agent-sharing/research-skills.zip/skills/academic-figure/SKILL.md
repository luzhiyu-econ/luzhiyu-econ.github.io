---
name: academic-figure
description: Create publication-quality matplotlib figures from research data or estimates. Use for paper charts such as event studies, coefficient plots, binscatters, and time series; not for conceptual diagrams or AI-generated illustrations.
---

# Academic Figure

使用 matplotlib 从研究数据或估计结果生成投稿级图形。概念框架图、AI 插画和海报不属于本 skill。

## Reference Router

- 每次先读 `references/style_guide.md`，复用其中的 rcParams、字体、颜色和尺寸设置。
- binscatter、残差化或拟合线任务再读 `references/binscatter_utils.md`。
- 需要已验证代码样板时读 `references/figure_patterns.md`。
- 字体资源位于 `assets/times.ttf` 与 `assets/simsun.ttf`。

## Workflow

1. 确认一行数据代表什么、横纵轴变量、估计量、置信区间和样本范围。
2. 根据分析目标选择图形类型和聚合方式，不让视觉设计替代统计判断。
3. 应用 style guide，生成最小但完整的图例、轴标签、单位和必要注释。
4. 同时保存 PDF 与高分辨率 PNG，并检查字体回退、裁切、重叠和灰度可辨性。
5. 将关键数据点或估计值与源结果交叉核对。

## Hard Constraints

- 图内不放主标题；标题和图注由论文正文承担。
- 多条线同时使用颜色、线型和标记编码，确保灰度打印可区分。
- 图例通常置于图下方且无边框。
- 英文与数字使用 Times New Roman，中文使用 SimSun，数学符号使用 STIX。
- 默认移除上、右脊线；网格如需使用，仅保留轻量 y 轴网格。
- 使用期刊单栏、1.5 栏或双栏宽度，不随意拉伸。

## Output Contract

返回 PDF、PNG 和生成代码路径，说明数据口径、图形选择、输出尺寸及 QA 结果。若源数据不足以支持图形，先报告缺口，不伪造示意结果。
