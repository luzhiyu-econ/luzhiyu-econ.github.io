# Binscatter & Statistical Utilities

Reusable functions for binned scatter plots and OLS overlays. These are the workhorses of empirical research figures. Import them from `scripts/binscatter.py` or paste into your notebook config cell.

---

## Core Functions

### `binscatter(x, y, n_bins=30)`

Bin `x` into equal-frequency quantile bins, compute the mean of `x` and `y` within each bin, and return the bin centers. This is the standard "binscatter" used in applied economics (cf. Cattaneo et al. 2024).

```python
def binscatter(x, y, n_bins=30):
    """Equal-frequency binned scatter.

    Parameters
    ----------
    x, y : array-like
        Raw data vectors (same length). NaN/Inf values are dropped.
    n_bins : int
        Number of quantile bins. 20–40 is typical for most datasets.

    Returns
    -------
    xm : ndarray  — bin-mean x values
    ym : ndarray  — bin-mean y values
    n  : int      — number of valid observations used
    """
    x, y = np.asarray(x, dtype=float), np.asarray(y, dtype=float)
    ok = np.isfinite(x) & np.isfinite(y)
    x, y = x[ok], y[ok]
    if len(x) < n_bins * 2:
        return np.array([]), np.array([]), len(x)
    edges = np.percentile(x, np.linspace(0, 100, n_bins + 1))
    edges[-1] += 1e-10          # ensure the max value falls inside the last bin
    bi = np.clip(np.digitize(x, edges), 1, n_bins)
    xm, ym = [], []
    for b in range(1, n_bins + 1):
        m = bi == b
        if m.sum() > 0:
            xm.append(x[m].mean())
            ym.append(y[m].mean())
    return np.array(xm), np.array(ym), len(x)
```

**When to adjust `n_bins`:**
- N < 500 → use 15–20 bins
- 500 < N < 5000 → use 25–30 bins (default)
- N > 5000 → use 30–50 bins
- Very noisy data → fewer bins to stabilize means

### `ols_coef(x, y)`

Simple bivariate OLS returning slope, intercept, p-value, and sample size.

```python
def ols_coef(x, y):
    """Bivariate OLS regression.

    Returns
    -------
    slope, intercept, p_value, n
    """
    x, y = np.asarray(x, dtype=float), np.asarray(y, dtype=float)
    ok = np.isfinite(x) & np.isfinite(y)
    x, y = x[ok], y[ok]
    if len(x) < 10:
        return np.nan, np.nan, np.nan, len(x)
    slope, intercept, _, p, _ = stats.linregress(x, y)
    return slope, intercept, p, len(x)
```

### `ols_with_ci(x, y, alpha=0.05)`

OLS with confidence interval on the fitted line (not prediction interval).

```python
def ols_with_ci(x, y, alpha=0.05):
    """OLS with confidence band for the regression line.

    Returns
    -------
    xfit    : ndarray — 200 evenly spaced x values
    yfit    : ndarray — predicted y at xfit
    ci_lo   : ndarray — lower bound of CI
    ci_hi   : ndarray — upper bound of CI
    slope, intercept, p, n
    """
    x, y = np.asarray(x, dtype=float), np.asarray(y, dtype=float)
    ok = np.isfinite(x) & np.isfinite(y)
    x, y = x[ok], y[ok]
    n = len(x)
    if n < 10:
        return (np.array([]),)*4 + (np.nan, np.nan, np.nan, n)

    slope, intercept, _, p, se = stats.linregress(x, y)
    xfit = np.linspace(x.min(), x.max(), 200)
    yfit = slope * xfit + intercept

    # Standard error of the fitted line
    x_mean = x.mean()
    ss_x = np.sum((x - x_mean)**2)
    resid = y - (slope * x + intercept)
    mse = np.sum(resid**2) / (n - 2)
    se_line = np.sqrt(mse * (1/n + (xfit - x_mean)**2 / ss_x))

    t_crit = stats.t.ppf(1 - alpha/2, df=n-2)
    ci_lo = yfit - t_crit * se_line
    ci_hi = yfit + t_crit * se_line

    return xfit, yfit, ci_lo, ci_hi, slope, intercept, p, n
```

---

## Plotting Helpers

### `plot_binscatter(ax, x, y, color, label, n_bins=30, show_ols=True, show_ci=False, **scatter_kw)`

All-in-one: draws binned dots + optional OLS line + optional CI band + coefficient annotation.

```python
def plot_binscatter(ax, x, y, color, label='',
                    n_bins=30, show_ols=True, show_ci=False,
                    marker='o', ms=12, annot_pos=(0.05, 0.92),
                    **scatter_kw):
    """Draw a complete binscatter panel.

    Parameters
    ----------
    ax : matplotlib Axes
    x, y : array-like
    color : str — hex color
    label : str — legend label for the dots
    show_ols : bool — overlay OLS fit line
    show_ci : bool — shade 95% CI band
    annot_pos : tuple — (x, y) in axes coords for the β/N annotation
    scatter_kw : passed to ax.scatter
    """
    xb, yb, n = binscatter(x, y, n_bins=n_bins)
    if len(xb) == 0:
        return

    ax.scatter(xb, yb, s=ms, c=color, edgecolors=C_DARK,
               linewidths=0.3, zorder=3, label=label,
               marker=marker, **scatter_kw)

    if show_ols or show_ci:
        xfit, yfit, ci_lo, ci_hi, slope, intercept, p, _ = ols_with_ci(x, y)
        if len(xfit) > 0:
            if show_ols:
                ax.plot(xfit, yfit, color=color, lw=1.0, ls='--', zorder=2)
            if show_ci:
                ax.fill_between(xfit, ci_lo, ci_hi,
                                color=color, alpha=0.12, lw=0, zorder=1)
            stars = '***' if p < 0.01 else ('**' if p < 0.05 else ('*' if p < 0.1 else ''))
            ax.text(annot_pos[0], annot_pos[1],
                    f'β = {slope:.3f}{stars}\nN = {n:,}',
                    transform=ax.transAxes, fontsize=7,
                    fontproperties=prop_en, va='top')
```

### `format_panel(ax, xlabel, ylabel, xlim=None, ylim=None)`

Apply standard axis formatting to a single panel.

```python
def format_panel(ax, xlabel='', ylabel='', xlim=None, ylim=None,
                 grid_y=False, grid_x=False):
    """Standard formatting for one subplot."""
    if xlabel:
        ax.set_xlabel(xlabel, fontproperties=prop_en)
    if ylabel:
        ax.set_ylabel(ylabel, fontproperties=prop_en)
    if xlim:
        ax.set_xlim(*xlim)
    if ylim:
        ax.set_ylim(*ylim)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    if grid_y:
        ax.grid(axis='y', linewidth=0.3, alpha=0.3, color=C_VLIGHT, zorder=0)
    if grid_x:
        ax.grid(axis='x', linewidth=0.3, alpha=0.3, color=C_VLIGHT, zorder=0)
```

---

## Residualized Binscatter

When you need to partial out controls (à la Frisch-Waugh), residualize both `x` and `y` before binning:

```python
import statsmodels.api as sm

def residualize(var, controls):
    """Residualize var on controls via OLS."""
    ok = np.isfinite(var)
    for c in controls:
        ok &= np.isfinite(c)
    X = np.column_stack(controls)[ok]
    X = sm.add_constant(X)
    y = var[ok]
    resid = sm.OLS(y, X).fit().resid
    out = np.full_like(var, np.nan)
    out[ok] = resid
    return out

# Usage:
# x_r = residualize(x, [fe_year, fe_province])
# y_r = residualize(y, [fe_year, fe_province])
# plot_binscatter(ax, x_r, y_r, ...)
```

Note: label residualized axes as `'X (residualized)'` to be transparent about the transformation.

---

## Weighted Binscatter

For frequency-weighted data (e.g., policy-level observations with different population weights):

```python
def binscatter_weighted(x, y, w, n_bins=30):
    """Weighted equal-frequency binscatter."""
    x, y, w = [np.asarray(v, float) for v in (x, y, w)]
    ok = np.isfinite(x) & np.isfinite(y) & np.isfinite(w) & (w > 0)
    x, y, w = x[ok], y[ok], w[ok]
    if len(x) < n_bins * 2:
        return np.array([]), np.array([]), len(x)

    # Weighted quantile edges
    sort_idx = np.argsort(x)
    x_s, y_s, w_s = x[sort_idx], y[sort_idx], w[sort_idx]
    cum_w = np.cumsum(w_s)
    total_w = cum_w[-1]
    edges_w = np.linspace(0, total_w, n_bins + 1)

    xm, ym = [], []
    for i in range(n_bins):
        mask = (cum_w > edges_w[i]) & (cum_w <= edges_w[i+1])
        if i == 0:
            mask |= (cum_w <= edges_w[1])
        if mask.sum() > 0:
            wm = w_s[mask]
            xm.append(np.average(x_s[mask], weights=wm))
            ym.append(np.average(y_s[mask], weights=wm))
    return np.array(xm), np.array(ym), len(x)
```
