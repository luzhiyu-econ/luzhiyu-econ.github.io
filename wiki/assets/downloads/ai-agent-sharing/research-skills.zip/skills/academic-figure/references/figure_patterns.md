# Figure Patterns Reference

Complete code recipes for common academic figure types. Each pattern is self-contained: copy, adapt data variables, and save. All patterns assume the project config (rcParams, fonts, palette) is already loaded.

---

## Table of Contents
- [§ A — Time-Series Share Plot](#a--time-series-share-plot)
- [§ B — Binscatter Grid with OLS](#b--binscatter-grid-with-ols)
- [§ C — Coefficient / Forest Plot](#c--coefficient--forest-plot)
- [§ D — Heatmap with Colorbar](#d--heatmap-with-colorbar)
- [§ E — Stacked Area Chart](#e--stacked-area-chart)
- [§ F — Distribution Comparison](#f--distribution-comparison)
- [§ G — Choropleth Map](#g--choropleth-map)
- [§ H — Event Study / Difference-in-Differences](#h--event-study--difference-in-differences)
- [§ I — Saving Utility](#i--saving-utility)

---

## § A — Time-Series Share Plot

Two-panel figure showing the share (%) of categories over time with reference event lines.

```python
# ── Data: edge_ma, casc_ma are DataFrames indexed by year, columns = category keys
# ── SPEC: list of (key, label, color, linestyle, marker)

fig, (ax_a, ax_b) = plt.subplots(1, 2, figsize=(8.5, 3.4), dpi=300)
fig.subplots_adjust(left=0.08, right=0.98, top=0.90, bottom=0.30, wspace=0.30)

EVENTS = [(1989, 'Jiang'), (2002, 'Hu'), (2012, 'Xi')]  # reference events

for ax, data, spec, panel in [(ax_a, edge_ma, E_SPEC, '(a)'),
                               (ax_b, casc_ma, C_SPEC, '(b)')]:
    # Reference event lines (behind data)
    for yr, _ in EVENTS:
        ax.axvline(x=yr, color='#a0a0a0', ls='--', lw=1.2, zorder=0)

    yrs = data.index.values
    for key, lbl, col, ls, mk in spec:
        if key in data.columns:
            ax.plot(yrs, data[key].values,
                    color=col, ls=ls, marker=mk,
                    markersize=2.2, markevery=5, linewidth=1.2,
                    label=lbl,
                    markeredgewidth=0.3, markeredgecolor=C_DARK, zorder=3)

    ax.set_ylabel('Share (%)', fontproperties=prop_en)
    ax.set_xlabel('Year', fontproperties=prop_en)
    ax.set_xlim(YR_RANGE)
    ax.set_ylim(0, None)
    ax.xaxis.set_major_locator(mticker.MultipleLocator(10))
    ax.xaxis.set_minor_locator(mticker.MultipleLocator(5))
    ax.grid(axis='y', linewidth=0.3, alpha=0.3, color=C_VLIGHT, zorder=0)

    # Bottom legend
    ax.legend(loc='upper center', bbox_to_anchor=(0.5, -0.25),
              ncol=2, fontsize=7, prop=prop_en, frameon=False,
              handlelength=2.5, borderpad=0.3, labelspacing=0.3,
              columnspacing=1.5)

    # Panel label
    ax.text(-0.12, 1.05, panel, transform=ax.transAxes,
            fontsize=10, fontweight='bold', fontproperties=prop_en)

save_fig(fig, 'fig1_temporal_dynamics')
```

**Key decisions:**
- Moving average smoothing (3–5 year) happens in data prep, not in the plot function.
- `markevery=5` thins markers to avoid clutter while maintaining data density.
- Each panel gets its own bottom legend (works when category sets differ across panels).

---

## § B — Binscatter Grid with OLS

Multi-panel grid where each subplot is a binscatter of a different variable pair.

```python
panels = [
    # (x_col, y_col, xlabel, ylabel)
    ('log_gdp',   'policy_count', 'Log GDP per capita', 'Policy count'),
    ('urbanize',  'policy_count', 'Urbanization rate',  'Policy count'),
    ('fiscal',    'diffusion_speed', 'Fiscal capacity',  'Diffusion speed (days)'),
    ('edu_years', 'diffusion_speed', 'Avg. education (yrs)', 'Diffusion speed (days)'),
]

n_rows, n_cols = 2, 2
fig, axes = plt.subplots(n_rows, n_cols, figsize=(7.0, 5.5), dpi=300)
fig.subplots_adjust(left=0.10, right=0.97, top=0.94, bottom=0.08,
                    wspace=0.35, hspace=0.40)

import string
for idx, (ax, (xcol, ycol, xlab, ylab)) in enumerate(zip(axes.flat, panels)):
    x = df_pd[xcol].values
    y = df_pd[ycol].values

    plot_binscatter(ax, x, y, color=C_HORIZONTAL, n_bins=30,
                    show_ols=True, show_ci=True)
    format_panel(ax, xlabel=xlab, ylabel=ylab)

    label = f'({string.ascii_lowercase[idx]})'
    ax.text(-0.16, 1.05, label, transform=ax.transAxes,
            fontsize=10, fontweight='bold', fontproperties=prop_en)

save_fig(fig, 'fig3_binscatter_grid')
```

**Key decisions:**
- `wspace=0.35, hspace=0.40` prevents y-axis labels from colliding with neighboring panels.
- No legend needed when there's a single series per panel; the β/N annotation replaces it.

---

## § C — Coefficient / Forest Plot

Horizontal coefficient plot with confidence intervals, sorted by effect size.

```python
# ── Data: coef_df with columns ['variable', 'beta', 'ci_lo', 'ci_hi', 'p']
coef_df = coef_df.sort_values('beta')

fig, ax = plt.subplots(figsize=(4.5, 0.35 * len(coef_df) + 1.0), dpi=300)
fig.subplots_adjust(left=0.35, right=0.92, top=0.95, bottom=0.10)

y_pos = np.arange(len(coef_df))

# CI whiskers
ax.hlines(y_pos, coef_df['ci_lo'], coef_df['ci_hi'],
          color=C_DARK, linewidth=0.8, zorder=2)

# Point estimates — color by significance
colors = [C_TOPDOWN if p < 0.05 else C_LIGHT for p in coef_df['p']]
ax.scatter(coef_df['beta'], y_pos, c=colors, s=20,
           edgecolors=C_DARK, linewidths=0.3, zorder=3)

# Zero reference line
ax.axvline(x=0, color=C_MID, ls='-', lw=0.6, zorder=0)

ax.set_yticks(y_pos)
ax.set_yticklabels(coef_df['variable'], fontproperties=prop_en, fontsize=7)
ax.set_xlabel('Coefficient estimate', fontproperties=prop_en)
ax.spines['left'].set_visible(False)
ax.tick_params(axis='y', length=0)   # remove y ticks, keep labels

# Significance legend
from matplotlib.lines import Line2D
legend_handles = [
    Line2D([0],[0], marker='o', color='w', markerfacecolor=C_TOPDOWN,
           markeredgecolor=C_DARK, markersize=5, label='p < 0.05'),
    Line2D([0],[0], marker='o', color='w', markerfacecolor=C_LIGHT,
           markeredgecolor=C_DARK, markersize=5, label='p ≥ 0.05'),
]
ax.legend(handles=legend_handles, loc='upper center',
          bbox_to_anchor=(0.5, -0.08), ncol=2, frameon=False,
          fontsize=7, prop=prop_en)

save_fig(fig, 'fig4_coefficients')
```

**Key decisions:**
- Figure height scales with the number of variables (`0.35 * n + 1.0`).
- Left spine is hidden (clean forest-plot look); y-tick marks are suppressed but labels remain.
- Color encodes significance (red = significant, gray = not) — a natural semantic mapping.

---

## § D — Heatmap with Colorbar

Correlation or similarity matrix with a tight colorbar.

```python
fig, ax = plt.subplots(figsize=(5.5, 4.8), dpi=300)
fig.subplots_adjust(left=0.18, right=0.88, top=0.95, bottom=0.18)

# Re-enable all four spines for matrix display
for spine in ax.spines.values():
    spine.set_visible(True)
    spine.set_linewidth(0.4)

im = ax.imshow(corr_matrix, cmap='RdBu_r', vmin=-1, vmax=1, aspect='auto')

# Tight colorbar using axes_grid1
divider = make_axes_locatable(ax)
cax = divider.append_axes('right', size='4%', pad=0.08)
cb = fig.colorbar(im, cax=cax)
cb.ax.tick_params(labelsize=7, width=0.4, length=2)
cb.outline.set_linewidth(0.4)

# Labels
ax.set_xticks(range(len(labels)))
ax.set_xticklabels(labels, rotation=45, ha='right', fontsize=7, fontproperties=prop_en)
ax.set_yticks(range(len(labels)))
ax.set_yticklabels(labels, fontsize=7, fontproperties=prop_en)

# Optional: annotate cells
for i in range(len(labels)):
    for j in range(len(labels)):
        val = corr_matrix[i, j]
        color = 'white' if abs(val) > 0.6 else C_DARK
        ax.text(j, i, f'{val:.2f}', ha='center', va='center',
                fontsize=5.5, color=color, fontproperties=prop_en)

save_fig(fig, 'fig5_heatmap')
```

---

## § E — Stacked Area Chart

```python
fig, ax = plt.subplots(figsize=(6.0, 3.2), dpi=300)
fig.subplots_adjust(left=0.10, right=0.97, top=0.92, bottom=0.28)

years = data.index.values
cols = ['top_down', 'horizontal', 'bottom_up']
colors = [C_TOPDOWN, C_HORIZONTAL, C_BOTTOMUP]
labels_text = ['Top-down', 'Horizontal', 'Bottom-up']

ax.stackplot(years, *[data[c].values for c in cols],
             colors=colors, labels=labels_text, alpha=0.85, lw=0.3,
             edgecolor='white')

ax.set_ylabel('Share (%)', fontproperties=prop_en)
ax.set_xlabel('Year', fontproperties=prop_en)
ax.set_xlim(years[0], years[-1])
ax.set_ylim(0, 100)

ax.legend(loc='upper center', bbox_to_anchor=(0.5, -0.20),
          ncol=3, frameon=False, fontsize=7, prop=prop_en)

save_fig(fig, 'fig6_stacked_area')
```

---

## § F — Distribution Comparison

Side-by-side violins or overlaid histograms.

```python
fig, ax = plt.subplots(figsize=(5.0, 3.2), dpi=300)
fig.subplots_adjust(left=0.12, right=0.97, top=0.92, bottom=0.28)

# Overlaid histograms with transparency
for vals, col, lbl in [(data_a, C_TOPDOWN, 'Group A'),
                        (data_b, C_HORIZONTAL, 'Group B')]:
    ax.hist(vals, bins=40, density=True, alpha=0.45,
            color=col, edgecolor='white', lw=0.3, label=lbl, zorder=2)

# Optional KDE overlay
from scipy.stats import gaussian_kde
for vals, col in [(data_a, C_TOPDOWN), (data_b, C_HORIZONTAL)]:
    kde = gaussian_kde(vals[np.isfinite(vals)])
    xs = np.linspace(vals.min(), vals.max(), 300)
    ax.plot(xs, kde(xs), color=col, lw=1.2, zorder=3)

ax.set_xlabel('Value', fontproperties=prop_en)
ax.set_ylabel('Density', fontproperties=prop_en)

ax.legend(loc='upper center', bbox_to_anchor=(0.5, -0.20),
          ncol=2, frameon=False, fontsize=7, prop=prop_en)

save_fig(fig, 'fig7_distributions')
```

---

## § G — Choropleth Map

Province-level or country-level map using geopandas.

```python
import geopandas as gpd

fig, ax = plt.subplots(figsize=(7.0, 5.0), dpi=300)
fig.subplots_adjust(left=0.02, right=0.88, top=0.95, bottom=0.05)

# Re-enable spines for map frame
for spine in ax.spines.values():
    spine.set_visible(True)
    spine.set_linewidth(0.3)

gdf.plot(column='value', cmap='YlOrRd', linewidth=0.3,
         edgecolor=C_DARK, ax=ax, legend=False)

ax.set_aspect('equal')
ax.set_xticks([])
ax.set_yticks([])

# Manual colorbar
sm = plt.cm.ScalarMappable(cmap='YlOrRd',
     norm=plt.Normalize(vmin=gdf['value'].min(), vmax=gdf['value'].max()))
sm._A = []
divider = make_axes_locatable(ax)
cax = divider.append_axes('right', size='3%', pad=0.1)
cb = fig.colorbar(sm, cax=cax)
cb.ax.tick_params(labelsize=7)
cb.outline.set_linewidth(0.4)

save_fig(fig, 'fig8_choropleth')
```

---

## § H — Event Study / Difference-in-Differences

Coefficient path plot with pre/post treatment period markers and confidence bands.

```python
fig, ax = plt.subplots(figsize=(5.5, 3.5), dpi=300)
fig.subplots_adjust(left=0.12, right=0.97, top=0.92, bottom=0.28)

periods = es_df['period'].values   # relative time: -5, -4, ..., 0, 1, 2, ...
betas = es_df['beta'].values
ci_lo = es_df['ci_lo'].values
ci_hi = es_df['ci_hi'].values

# CI band
ax.fill_between(periods, ci_lo, ci_hi,
                color=C_HORIZONTAL, alpha=0.15, lw=0, zorder=1)

# Point estimates
ax.plot(periods, betas, color=C_HORIZONTAL, ls='-', marker='o',
        markersize=4, markeredgecolor=C_DARK, markeredgewidth=0.3,
        linewidth=1.2, zorder=3, label='Treatment effect')

# Zero reference
ax.axhline(y=0, color=C_MID, ls='-', lw=0.6, zorder=0)

# Treatment onset
ax.axvline(x=-0.5, color=C_TOPDOWN, ls='--', lw=1.0, zorder=0)
ax.text(-0.3, ax.get_ylim()[1]*0.9, 'Treatment', fontsize=7,
        color=C_TOPDOWN, fontproperties=prop_en, ha='left')

ax.set_xlabel('Period relative to treatment', fontproperties=prop_en)
ax.set_ylabel('Coefficient estimate', fontproperties=prop_en)
ax.xaxis.set_major_locator(mticker.MultipleLocator(1))

ax.legend(loc='upper center', bbox_to_anchor=(0.5, -0.20),
          ncol=1, frameon=False, fontsize=7, prop=prop_en)

save_fig(fig, 'fig9_event_study')
```

---

## § I — Saving Utility

A helper to enforce the dual-format save convention:

```python
def save_fig(fig, name, fig_dir=FIG_DIR, extensions=('pdf', 'png'),
             close=True, show=True):
    """Save figure in multiple formats and optionally display + close.

    Parameters
    ----------
    fig : matplotlib Figure
    name : str — filename stem without extension (e.g., 'fig1_dynamics')
    fig_dir : str — output directory
    extensions : tuple — file formats to save
    close : bool — call plt.close() after saving
    show : bool — call plt.show() before closing
    """
    for ext in extensions:
        path = os.path.join(fig_dir, f'{name}.{ext}')
        fig.savefig(path, format=ext)
    if show:
        plt.show()
    if close:
        plt.close(fig)
    print(f'  ✅ {name} saved ({", ".join(extensions)})')
```

Place this in the project config cell so all figures share it.
