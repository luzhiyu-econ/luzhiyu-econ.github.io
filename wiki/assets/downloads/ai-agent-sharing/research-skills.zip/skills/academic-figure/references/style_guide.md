# Style Guide Reference

Complete design system for academic figures. This file is the single source of truth for all visual parameters. Read it before writing any figure code.

---

## Table of Contents
1. [Project Config Template](#1-project-config-template)
2. [rcParams Master Block](#2-rcparams-master-block)
3. [Semantic Palette Specification](#3-semantic-palette-specification)
4. [Typography Details](#4-typography-details)
5. [Axis & Spine Cookbook](#5-axis--spine-cookbook)
6. [Legend Recipes](#6-legend-recipes)
7. [Panel Label System](#7-panel-label-system)
8. [Journal-Specific Overrides](#8-journal-specific-overrides)

---

## 1 · Project Config Template

Copy this block into a shared module or the first cell of every notebook. Adapt only the paths and the semantic palette to your project.

```python
import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import matplotlib.patches as mpatches
from matplotlib import font_manager
from matplotlib.gridspec import GridSpec
from matplotlib.lines import Line2D
from mpl_toolkits.axes_grid1 import make_axes_locatable
import scipy.stats as stats
import warnings, os

warnings.filterwarnings('ignore')

# ══════════════════════════════════════════════
#  PROJECT PATHS — EDIT THESE PER PROJECT
# ══════════════════════════════════════════════
try:
    HERE = os.path.dirname(os.path.abspath(__file__))
except NameError:
    # __file__ is undefined in notebooks; set this manually there.
    HERE = '/path/to/academic-figure'

ASSET_DIR  = os.path.join(HERE, 'assets')
BASE_DIR   = '/path/to/project'
FIG_DIR    = os.path.join(BASE_DIR, 'figures')
os.makedirs(FIG_DIR, exist_ok=True)

# ══════════════════════════════════════════════
#  FONT REGISTRATION
# ══════════════════════════════════════════════
FONT_CN = os.path.join(ASSET_DIR, 'simsun.ttf')
FONT_EN = os.path.join(ASSET_DIR, 'times.ttf')

font_manager.fontManager.addfont(FONT_CN)
font_manager.fontManager.addfont(FONT_EN)

prop_cn = font_manager.FontProperties(fname=FONT_CN)
prop_en = font_manager.FontProperties(fname=FONT_EN)
CN_FAMILY = prop_cn.get_name()
EN_FAMILY = prop_en.get_name()

# ══════════════════════════════════════════════
#  GLOBAL rcParams
# ══════════════════════════════════════════════
plt.rcParams.update({
    # -- Typography --
    'font.family':        [EN_FAMILY, CN_FAMILY, 'serif'],
    'font.size':          9,
    'axes.unicode_minus': False,       # avoid glyph issues with CJK fonts
    'mathtext.fontset':   'stix',      # math symbols match Times

    # -- Axes --
    'axes.linewidth':  0.6,
    'axes.labelsize':  9,
    'axes.titlesize':  10,
    'axes.titleweight': 'normal',
    'axes.spines.top':    False,       # remove top spine globally
    'axes.spines.right':  False,       # remove right spine globally

    # -- Ticks --
    'xtick.labelsize':   8,
    'ytick.labelsize':   8,
    'xtick.major.width': 0.5,
    'ytick.major.width': 0.5,
    'xtick.minor.width': 0.3,
    'ytick.minor.width': 0.3,
    'xtick.major.size':  3,
    'ytick.major.size':  3,
    'xtick.minor.size':  1.5,
    'ytick.minor.size':  1.5,
    'xtick.direction':   'in',
    'ytick.direction':   'in',

    # -- Legend --
    'legend.fontsize':  8,
    'legend.frameon':   False,
    'legend.borderpad': 0.3,
    'legend.handlelength': 2.0,
    'legend.labelspacing': 0.3,

    # -- Lines & patches --
    'lines.linewidth':  0.8,
    'lines.markersize': 4,
    'patch.linewidth':  0.5,

    # -- Figure & saving --
    'figure.dpi':         300,
    'savefig.dpi':        600,
    'savefig.bbox':       'tight',
    'savefig.pad_inches': 0.05,
    'savefig.transparent': False,
})

# ══════════════════════════════════════════════
#  SEMANTIC COLOR PALETTE
# ══════════════════════════════════════════════
# Map colors to conceptual meaning, not arbitrary series order.
# Override these per project; the names should stay stable.

C_TOPDOWN    = '#d62728'   # red    — authority / top-down
C_HORIZONTAL = '#1f77b4'   # blue   — peer / horizontal
C_BOTTOMUP   = '#2ca02c'   # green  — grassroots / bottom-up
C_MIXED      = '#ff7f0e'   # orange — hybrid / mixed
C_CENTRAL    = '#9467bd'   # purple — central / internal

# Grayscale utility ramp (never used for data series)
C_BLACK  = '#000000'
C_DARK   = '#333333'
C_MID    = '#666666'
C_LIGHT  = '#999999'
C_VLIGHT = '#cccccc'
C_BG     = '#f7f7f7'       # optional light background for insets

# ══════════════════════════════════════════════
#  LINE SPEC BUILDER
# ══════════════════════════════════════════════
# Each data series is a (key, label, color, linestyle, marker) tuple.
# This ensures triple-encoding: hue + dash + shape.

LSTYLES = ['-', '--', ':', '-.', (0,(3,1,1,1))]
MARKERS = ['o', 's', '^', 'D', 'v', 'P', 'X']

def make_spec(keys_labels_colors):
    """Build spec list auto-assigning linestyles and markers.

    Parameters
    ----------
    keys_labels_colors : list of (key, label, color)

    Returns
    -------
    list of (key, label, color, linestyle, marker)
    """
    return [
        (k, l, c, LSTYLES[i % len(LSTYLES)], MARKERS[i % len(MARKERS)])
        for i, (k, l, c) in enumerate(keys_labels_colors)
    ]
```

---

## 2 · rcParams Master Block

The template above already contains the full rcParams. Below are the design rationale notes:

**Why `axes.spines.top/right = False` globally?**
Removing decorative spines is the single highest-impact change for a cleaner academic look. The few figure types that need four spines (e.g., maps, matrix heatmaps) can re-enable them locally with `ax.spines['top'].set_visible(True)`.

**Why `savefig.pad_inches = 0.05`?**
Journals crop tightly. The default `0.1` is already small; `0.05` prevents accidental whitespace while `bbox='tight'` handles the rest.

**Why `mathtext.fontset = 'stix'`?**
STIX glyphs are metrically compatible with Times New Roman. This keeps inline math (e.g., `$\beta$`, `$R^2$`) visually consistent with axis labels.

**Why inward ticks?**
Inward ticks avoid collision with data points near axes. This is standard practice in economics, political science, and most natural science journals.

---

## 3 · Semantic Palette Specification

### 3.1 Default Five-Color Palette

| Name | Hex | Role | Grayscale approx. |
|------|-----|------|-------------------|
| `C_TOPDOWN` | `#d62728` | Authority, top-down processes | Dark |
| `C_HORIZONTAL` | `#1f77b4` | Peer-level, horizontal | Medium-dark |
| `C_BOTTOMUP` | `#2ca02c` | Grassroots, bottom-up | Medium |
| `C_MIXED` | `#ff7f0e` | Hybrid, mixed type | Medium-light |
| `C_CENTRAL` | `#9467bd` | Central/internal | Medium |

These five colors have sufficient luminance spread to remain distinguishable when printed in grayscale. Verify with:
```python
from matplotlib.colors import rgb_to_hsv, hex2color
for c in [C_TOPDOWN, C_HORIZONTAL, C_BOTTOMUP, C_MIXED, C_CENTRAL]:
    r,g,b = hex2color(c)
    lum = 0.299*r + 0.587*g + 0.114*b
    print(f'{c}  luminance={lum:.2f}')
```

### 3.2  Alternative Palettes

For projects that need different semantics, define a new mapping with the same variable names. Examples:

**Treatment/control design:**
```python
C_TREAT   = '#d62728'
C_CONTROL = '#1f77b4'
C_PLACEBO = '#999999'
```

**Sequential emphasis (1st, 2nd, 3rd…):**
```python
from matplotlib.cm import get_cmap
SEQ = [get_cmap('YlOrRd')(0.25 + 0.15*i) for i in range(5)]
```

### 3.3  Colorblind Safety

The default palette passes deuteranopia simulation. To verify:
```python
from matplotlib import colormaps
# Use colorspacious or daltonize to simulate
```
When more than 5 categories exist, switch to a colorblind-safe qualitative set like `'Set2'` or manually curated palettes from ColorBrewer.

---

## 4 · Typography Details

### 4.1  Font Registration Troubleshooting

If fonts fail to register (common in Docker / CI environments):
```python
# Force rebuild font cache
font_manager._load_fontmanager(try_read_cache=False)
```

If a `.ttf` file is not found, fall back gracefully:
```python
if os.path.exists(FONT_EN):
    font_manager.fontManager.addfont(FONT_EN)
    prop_en = font_manager.FontProperties(fname=FONT_EN)
else:
    prop_en = font_manager.FontProperties(family='serif')
    print("⚠ English font not found; falling back to serif")
```

### 4.2  Mixed-Language Labels

For axis labels mixing English and Chinese, matplotlib's font fallback handles it automatically if the font stack is set correctly. For legend entries or annotations where you need explicit control:
```python
ax.set_xlabel('政策数量 (Policy count)', fontproperties=prop_cn)
# SimSun will render 政策数量; Times renders the English portion.
```

Alternatively, use two `ax.text()` calls side by side for perfect font control when the automatic fallback misbehaves.

### 4.3  Math in Labels

Use LaTeX-style inline math with `mathtext`:
```python
ax.set_ylabel(r'Effect size ($\hat{\beta}$)')
ax.set_xlabel(r'Log GDP per capita ($\log y_{it}$)')
```
The `stix` fontset renders these in Times-compatible glyphs.

---

## 5 · Axis & Spine Cookbook

### 5.1  Standard Two-Spine Axis
Already the global default after rcParams. Nothing to do.

### 5.2  Four-Spine Axis (Heatmaps, Maps)
```python
for spine in ax.spines.values():
    spine.set_visible(True)
    spine.set_linewidth(0.4)
```

### 5.3  Broken Axis
```python
from mpl_toolkits.axes_grid1 import make_axes_locatable
# Use two axes with a diagonal break indicator
# See figure_patterns.md § H for full recipe
```

### 5.4  Dual Y-Axis
```python
ax2 = ax.twinx()
ax2.spines['right'].set_visible(True)  # re-enable for dual-y
ax2.spines['right'].set_linewidth(0.6)
ax2.set_ylabel('Right-axis label', fontproperties=prop_en)
```

### 5.5  Tick Formatting
```python
# Integer ticks (e.g., years)
ax.xaxis.set_major_locator(mticker.MultipleLocator(10))
ax.xaxis.set_minor_locator(mticker.MultipleLocator(5))

# Percentage
ax.yaxis.set_major_formatter(mticker.PercentFormatter(xmax=100, decimals=0))

# Thousands separator
ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f'{x:,.0f}'))

# Log scale with clean labels
ax.set_yscale('log')
ax.yaxis.set_major_formatter(mticker.ScalarFormatter())
```

---

## 6 · Legend Recipes

### 6.1  Single-Panel Bottom Legend
```python
ax.legend(
    loc='upper center', bbox_to_anchor=(0.5, -0.22),
    ncol=3, frameon=False, fontsize=7,
    prop=prop_en,
    handlelength=2.5, columnspacing=1.5, borderpad=0.3,
)
fig.subplots_adjust(bottom=0.28)
```

### 6.2  Shared Legend for Multi-Panel Figure
```python
handles, labels = ax1a.get_legend_handles_labels()
fig.legend(handles, labels,
           loc='lower center', bbox_to_anchor=(0.5, 0.02),
           ncol=4, frameon=False, fontsize=7, prop=prop_en,
           handlelength=2.5, columnspacing=1.8)
fig.subplots_adjust(bottom=0.16)
```

### 6.3  Custom Legend Handles
When the automatic legend is insufficient (e.g., combining line + scatter + patch):
```python
custom = [
    Line2D([0],[0], color=C_TOPDOWN, ls='-', marker='o', ms=4, label='Top-down'),
    mpatches.Patch(facecolor=C_HORIZONTAL, alpha=0.3, label='CI (horizontal)'),
]
ax.legend(handles=custom, loc='upper center', bbox_to_anchor=(0.5, -0.22),
          ncol=2, frameon=False, fontsize=7, prop=prop_en)
```

---

## 7 · Panel Label System

### 7.1  Automatic Panel Labeling
For a grid of subplots:
```python
import string
for idx, ax in enumerate(axes.flat):
    label = f'({string.ascii_lowercase[idx]})'
    ax.text(-0.12, 1.05, label, transform=ax.transAxes,
            fontsize=10, fontweight='bold', fontproperties=prop_en,
            va='bottom', ha='right')
```

### 7.2  Manual Adjustment
When panels have different widths (e.g., `GridSpec` with unequal ratios), adjust `x` per panel:
- Narrow left panel: `x = -0.18`
- Wide right panel: `x = -0.08`

### 7.3  Vertical Stacking
For stacked panels (column layout), use `(-0.12, 1.05)` uniformly but ensure `hspace` is large enough (≥ 0.45) so labels don't collide with the panel above.

---

## 8 · Journal-Specific Overrides

### AER / QJE / Econometrica (Economics)
- Max width: 5.5 in (single col), 7.3 in (double col)
- Font: Times preferred
- No color requirement but color allowed; grayscale fallback mandatory
- Notes below figure, not inside

### Nature / Science
- Max width: 89 mm (single), 183 mm (double)
- Font: Helvetica / Arial (override `EN_FAMILY` to sans-serif)
- Minimum text size: 6 pt after scaling

### PNAS
- Max width: 8.7 cm (single), 17.8 cm (double)
- Font: any serif acceptable; 6 pt minimum

### China-specific journals (管理世界, 经济研究)
- 宋体 (SimSun) required for Chinese text
- English in Times New Roman
- Width typically matches A4 margins: ~15 cm for full-width

To apply an override, create a small dict and call `plt.rcParams.update(...)` after the base config:
```python
NATURE_OVERRIDE = {
    'font.family': ['Helvetica', 'Arial', CN_FAMILY, 'sans-serif'],
    'font.size': 7,
    'axes.labelsize': 7,
    'xtick.labelsize': 6,
    'ytick.labelsize': 6,
    'legend.fontsize': 6,
}
```
