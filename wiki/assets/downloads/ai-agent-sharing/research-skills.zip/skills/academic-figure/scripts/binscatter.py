"""
Binscatter and OLS utilities for academic figures.

Usage:
    from scripts.binscatter import binscatter, ols_coef, ols_with_ci

Or copy into your notebook config cell.
"""

import numpy as np
import scipy.stats as stats


def binscatter(x, y, n_bins=30):
    """Equal-frequency binned scatter.

    Bins x into quantile-based groups, computes the mean of x and y
    within each bin. Standard approach in applied economics.

    Parameters
    ----------
    x, y : array-like
        Raw data vectors. NaN/Inf values are dropped automatically.
    n_bins : int
        Number of quantile bins. 20–40 is typical.

    Returns
    -------
    xm : ndarray — bin-mean x values
    ym : ndarray — bin-mean y values
    n  : int    — number of valid observations
    """
    x, y = np.asarray(x, dtype=float), np.asarray(y, dtype=float)
    ok = np.isfinite(x) & np.isfinite(y)
    x, y = x[ok], y[ok]
    if len(x) < n_bins * 2:
        return np.array([]), np.array([]), len(x)

    edges = np.percentile(x, np.linspace(0, 100, n_bins + 1))
    edges[-1] += 1e-10
    bi = np.clip(np.digitize(x, edges), 1, n_bins)

    xm, ym = [], []
    for b in range(1, n_bins + 1):
        m = bi == b
        if m.sum() > 0:
            xm.append(x[m].mean())
            ym.append(y[m].mean())
    return np.array(xm), np.array(ym), len(x)


def ols_coef(x, y):
    """Bivariate OLS regression.

    Returns
    -------
    slope : float
    intercept : float
    p_value : float
    n : int
    """
    x, y = np.asarray(x, dtype=float), np.asarray(y, dtype=float)
    ok = np.isfinite(x) & np.isfinite(y)
    x, y = x[ok], y[ok]
    if len(x) < 10:
        return np.nan, np.nan, np.nan, len(x)
    slope, intercept, _, p, _ = stats.linregress(x, y)
    return slope, intercept, p, len(x)


def ols_with_ci(x, y, alpha=0.05):
    """OLS with confidence interval on the fitted line.

    Returns
    -------
    xfit, yfit, ci_lo, ci_hi : ndarray (length 200)
    slope, intercept, p, n
    """
    x, y = np.asarray(x, dtype=float), np.asarray(y, dtype=float)
    ok = np.isfinite(x) & np.isfinite(y)
    x, y = x[ok], y[ok]
    n = len(x)
    if n < 10:
        empty = np.array([])
        return empty, empty, empty, empty, np.nan, np.nan, np.nan, n

    slope, intercept, _, p, _ = stats.linregress(x, y)
    xfit = np.linspace(x.min(), x.max(), 200)
    yfit = slope * xfit + intercept

    x_mean = x.mean()
    ss_x = np.sum((x - x_mean) ** 2)
    resid = y - (slope * x + intercept)
    mse = np.sum(resid ** 2) / (n - 2)
    se_line = np.sqrt(mse * (1.0 / n + (xfit - x_mean) ** 2 / ss_x))

    t_crit = stats.t.ppf(1 - alpha / 2, df=n - 2)
    ci_lo = yfit - t_crit * se_line
    ci_hi = yfit + t_crit * se_line

    return xfit, yfit, ci_lo, ci_hi, slope, intercept, p, n


def binscatter_weighted(x, y, w, n_bins=30):
    """Weighted equal-frequency binscatter.

    Parameters
    ----------
    x, y, w : array-like
        Data and positive weights.
    n_bins : int

    Returns
    -------
    xm, ym : ndarray
    n : int
    """
    x, y, w = [np.asarray(v, float) for v in (x, y, w)]
    ok = np.isfinite(x) & np.isfinite(y) & np.isfinite(w) & (w > 0)
    x, y, w = x[ok], y[ok], w[ok]
    if len(x) < n_bins * 2:
        return np.array([]), np.array([]), len(x)

    sort_idx = np.argsort(x)
    x_s, y_s, w_s = x[sort_idx], y[sort_idx], w[sort_idx]
    cum_w = np.cumsum(w_s)
    total_w = cum_w[-1]
    edges_w = np.linspace(0, total_w, n_bins + 1)

    xm, ym = [], []
    for i in range(n_bins):
        mask = (cum_w > edges_w[i]) & (cum_w <= edges_w[i + 1])
        if i == 0:
            mask |= (cum_w <= edges_w[1])
        if mask.sum() > 0:
            wm = w_s[mask]
            xm.append(np.average(x_s[mask], weights=wm))
            ym.append(np.average(y_s[mask], weights=wm))
    return np.array(xm), np.array(ym), len(x)
