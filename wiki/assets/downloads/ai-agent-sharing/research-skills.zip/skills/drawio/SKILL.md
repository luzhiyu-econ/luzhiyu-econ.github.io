---
name: drawio
description: Create or edit editable Draw.io diagrams and render them to PNG, SVG, or PDF. Use for flowcharts, architecture diagrams, sequence diagrams, ER diagrams, network diagrams, organization charts, and swimlanes; do not use for statistical plots or slide decks.
---

# Draw.io diagrams

Produce an editable `.drawio` source and a rendered preview. Prefer the local
headless workflow; use the Draw.io MCP only when the user wants interactive
browser preview or incremental browser-side editing.

## Local workflow

1. Design a clear single-direction layout and write uncompressed Draw.io XML.
2. Render locally:
   `~/.local/bin/drawio-headless -x -f png -s 2 -b 10 -o output.png input.drawio`
3. Inspect the PNG with `view_image`. Fix overflow, crossings, clipping, uneven
   spacing, or unreadable Chinese text, then render again.
4. Deliver the `.drawio` file plus PNG; add SVG or PDF only when useful.

Read [references/xml-and-layout.md](references/xml-and-layout.md) when creating
XML from scratch or repairing a malformed diagram.

## Interactive MCP workflow

The `drawio` MCP exposes `start_session`, `create_new_diagram`, `load_diagram`,
`edit_diagram`, `get_diagram`, `export_diagram`, and page-management tools.

- Call `start_session` first and give the Browser URL to the user.
- On a remote host, explain that port forwarding may be needed while preserving
  the URL query string.
- Use `create_new_diagram` only for a new document because it replaces the
  current document. Use `edit_diagram` for later cell-level changes.
- Fetch the current diagram before editing an unfamiliar file or after a stale
  state error.
- Browser-rendered PNG/SVG export requires the preview tab to remain connected;
  otherwise export `.drawio` and render it locally.

For confidential material, prefer local rendering. Browser preview loads the
configured Draw.io web application unless the MCP is pointed at a self-hosted
instance.
