# Draw.io XML and layout checks

Use an uncompressed `<mxfile>` containing one or more `<diagram>` elements.
Each page contains an `<mxGraphModel><root>` with reserved root cells:

```xml
<mxfile host="app.diagrams.net">
  <diagram id="p1" name="Page-1">
    <mxGraphModel grid="1" gridSize="10" page="1">
      <root>
        <mxCell id="0"/>
        <mxCell id="1" parent="0"/>
      </root>
    </mxGraphModel>
  </diagram>
</mxfile>
```

## Cells

- Give every non-root cell a meaningful unique id.
- A node needs `vertex="1"`, a parent, and `<mxGeometry ... as="geometry"/>`.
- An edge needs `edge="1"`, valid `source` and `target` ids, and
  `<mxGeometry relative="1" as="geometry"/>`.
- Use `whiteSpace=wrap;html=1;` for wrapped labels and `&lt;br&gt;` for line
  breaks. Escape `&`, `<`, `>`, and quotes in XML attributes.
- Prefer ordinary shapes when a vendor-specific shape name is uncertain;
  unknown shapes can render blank without a useful error.

## Layout

- Use one main flow direction and align peers to a 10 px grid.
- Leave at least 40 px between nodes and more space around labeled edges.
- Size boxes for the rendered label, not merely the character count.
- Prefer orthogonal edges and set connection sides or waypoints when automatic
  routing crosses nodes or reuses another edge's path.
- Keep 10-20 px outer whitespace in addition to the export margin.

## Validation

Render and inspect every page that will be delivered. Check XML parsing,
missing elements, clipped text, blank vendor shapes, edge crossings, contrast,
visual balance, and Chinese font rendering. Do not treat valid XML as proof of
a usable diagram.
