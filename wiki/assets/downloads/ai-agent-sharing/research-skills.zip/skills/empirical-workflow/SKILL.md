---
name: empirical-workflow
description: Design an empirical economics strategy after the research question is established, including estimand, baseline specification, fixed effects, inference, endogeneity, robustness, mechanisms, heterogeneity, and presentation planning.
---

# Empirical Workflow

Turn a research question into a defensible identification and evidence plan before estimation code is finalized.

## Decision Process

1. Define the observation unit, treatment or exposure, outcome, estimand, timing, and comparison group.
2. State the identifying variation and the counterfactual assumption in plain language.
3. Choose the baseline specification, controls, fixed effects, and inference level from the assignment mechanism, not convention alone.
4. Identify the strongest endogeneity threats and the evidence that could distinguish them.
5. Design robustness checks that target those threats; avoid decorative specification grids.
6. Separate mechanism tests from heterogeneity and define what each result would mean.
7. Plan tables and figures around claims, then hand estimation to `pyfixest-empirical` when Python/PyFixest is appropriate.

## Reference Router

- Baseline, controls, fixed effects, clustering: `references/baseline_and_fe.md`.
- IV, DID, selection, reverse causality: `references/endogeneity.md`.
- Robustness design: `references/robustness.md`.
- Mechanisms and heterogeneity: `references/mechanism_heterogeneity.md`.
- Table and figure sequence: `references/tables_and_presentation.md`.

## Output Contract

Return five parts: core concern, feasible design, designs to avoid, recommended next step, and likely reviewer challenge. State assumptions and data requirements explicitly.

Use `academic-brainstorm` before this skill when the research question itself is still unsettled; use `referee-review` after results exist.
