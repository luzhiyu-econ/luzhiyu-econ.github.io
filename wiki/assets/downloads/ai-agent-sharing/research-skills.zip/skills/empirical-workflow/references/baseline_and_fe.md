# Baseline Specification & Fixed Effects

## Contents
- `Baseline intake`
- `Fixed Effects Selection`
- `Outcome Scaling`
- `Clustering Strategy`
- `When OLS -> IV helps`
- `Balanced vs Unbalanced Panel`

## Baseline intake

在讨论 baseline 之前，先尽量锁定这些信息：
- `Unit`：firm, worker, county, school, region
- `Time`：cross-section, repeated cross-section, short panel, long panel
- `Treatment variation level`：individual, firm, city, state, cohort, state×cohort
- `Outcome type`：level, log, ratio, revenue-scaled, zero-heavy
- `Main estimand`：ATT, LATE, incidence, intensive margin, extensive margin
- `Composition concern`：entry/exit 是否重要

如果这些信息不清楚，不要直接推荐一套 FE 和聚类；先把推荐写成 conditional advice。

---

## Fixed Effects Selection

### Core rule

Choose FE to absorb a clearly articulated omitted-variable concern.
不要把 FE 当成"越多越好"的 checklist。

### Can do

| Data structure | Typical FE choice | What it absorbs | When it fits |
|---|---|---|---|
| Individual panel | `individual + time` | 个体不变特征 + common time shocks | 面板因果推断的起点 |
| Individual panel | `individual + industry×time` | 个体 + 行业时变冲击 | 担心行业层面混淆 |
| Multi-level panel | `firm + city×year` | 企业不变特征 + 城市时变政策环境 | 企业数据，政策在城市层级变化 |
| Repeated cross-section | `cohort×region + time` | 群组区域差异 + common time shocks | 无法追踪同一人 |

### Flexible alternative to over-absorbing FE

如果你担心不同类型单位有不同的时间趋势，但 `firm×year` 一类 FE 会吃掉所有识别变异，可以考虑把一组**基期特征**与 year 做灵活交互。
这通常比盲目升级到超高维 FE 更稳，也更容易解释。

### Reference cases

- **Barwick et al.**: `student FE + class-semester FE`，并加入 `CEE score × semester trend`。关键点不在于 FE 多，而在于保留了 `individual-time` 层面的核心变异。
- **Rao and Risch**: 让 baseline firm and market characteristics 与 year 灵活交互来控制异质趋势，而不是直接用 `firm×year FE` 吸收掉全部识别。

### Should not do

- 不要加入与 treatment 同层级变化的 FE。比如 treatment 在 `firm-year` 变化时再加 `firm×year FE`，会直接吸收主效应。
- 不要把交互 FE 当成默认升级路径。先问：你到底在吸收什么混淆？
- 不要忽视 singleton 问题。高维 FE 可能显著压缩有效样本。

### Reviewer lens

审稿人通常不会因为 FE 少就直接否定你；他们会问的是：
"你为什么加这个 FE？它吸收的到底是什么？你是否因此吃掉了真正的识别变异？"

---

## Outcome Scaling

### Core rule

Choose scaling based on the economic question, not formatting preference.
不同 scaling 回答的是不同问题。

### Can do

| Scaling | Typical form | Best use case | Main caution |
|---|---|---|---|
| Level | `Y_it` | 绝对量变化 | 大单位权重大，异方差可能更强 |
| Log | `ln(Y_it)` | 百分比变化 | 零值/负值问题 |
| Baseline-scaled | `Y_it / Y_i0` | 相对基期变化 | 依赖清晰基期 |
| Revenue-scaled | `Z_it / Revenue_i0` | incidence / burden sharing | 适合 income-statement style outcomes |
| Standardized | `Y_it / SD(Y)` | 比较不同 outcome 的相对 magnitude | 对解释不如 level/log 直观 |

### Reference case

**Rao and Risch** 用 `z_jt / revenue_{j,s-1}` 统一缩放 wage bill、revenue、COGS、other deductions、owner profits。
这让不同 outcome 可以直接放在一个 accounting frame 里比较，从而回答 incidence：谁承担了成本。

### Should not do

- 不要在 incidence 分析中混用不可比 scaling。否则"谁承担成本"的加减逻辑会断掉。
- 不要对有大量零值的 outcome 直接取 log 而不解释处理方式。
- 不要只报统计显著性，不报经济量级。

---

## Clustering Strategy

### Hard constraint

Cluster level should be **at least as high as** the treatment-variation level.
这是少数真正可以写成 `must` 的地方。

### Can do

| Treatment variation level | Recommended clustering | Why |
|---|---|---|
| `individual-time` | `individual` | 允许个体内跨期误差相关 |
| `group-time` | `group` | 如 state、industry policy shocks |
| `peer/group interaction` | `class/group` | 允许组内相关 |
| `state policy × cohort` | `state×cohort` | 保守允许同州同 cohort 相关 |

- 可以把 two-way clustering 当作稳健性，而不是默认神圣标准。
- 当 cluster 数量很少时，可以补 wild bootstrap p-value。

### Reference cases

- **Rao and Risch**: cluster at `state×cohort`，因为政策在 state 层级变化，不同 cohort 对应不同政策时点。
- **Barwick et al.**: cluster at `class`，因为 peer environment 和未观测冲击可能在班级内相关。

### Should not do

- 不要 cluster 低于 treatment variation level。
- 不要为了显得"保守"而无理由无限上提聚类层级。

---

## When OLS -> IV helps

### Can do

Use an `OLS -> IV` progression when:
- OLS+FE 仍然有描述性或弱因果解释价值
- OLS vs IV 的差异本身具有解释意义
- 读者需要一个 baseline magnitude 的直觉参照

### Reference case

**Barwick et al.** 先报 OLS，再报 IV。
价值不只是"IV 更可信"，还在于 OLS 与 IV 的差异揭示了偏误方向。

### When not necessary

如果 DID 本身已经是识别设计，没必要机械地先报一个 naive OLS。
**Rao and Risch** 直接把 DID 当作 baseline。

### Should not do

- 不要把 `OLS -> IV` 当作必经模板。
- 不要因为有 IV 就完全放弃讨论 OLS 的信息量。

---

## Balanced vs Unbalanced Panel

### Core rule

This is not just a sample-cleaning choice. It changes the estimand.

### Can do

| Panel choice | What it estimates | When it fits |
|---|---|---|
| Balanced panel | surviving units' intensive-margin response | 关注行为调整，不想让 composition 主导 |
| Unbalanced panel | total average effect including entry/exit composition | 关注整体平均效应 |
| Collapsed / aggregated data | sector or region aggregate effect | 关注 net entry/exit、总量重塑 |

### Reference case

**Rao and Risch** 同时使用：
- `balanced panel` 看存续企业如何调整
- `unbalanced panel` 看平均效应和 composition change
- `collapsed state×industry×year` 看 aggregate reallocation and entry/exit

这三层一起讲出完整故事，而不是互相替代。

### Should not do

- 不要只用 balanced panel 却声称估计了"全部效应"。
- 不要只给 unbalanced panel 结果却不讨论 composition effect。
- 不要在新进入/退出本身是 outcome 时仍然坚持做 firm-level before-after regression。

## Recommended answer pattern

在用户问 baseline 怎么设时，优先按这个格式回答：
1. `Empirical object`：unit / time / treatment variation / estimand
2. `Baseline recommendation`：首选 FE、cluster、sample、outcome scaling
3. `Can do alternatives`：2-3 套可替代设定
4. `Should not do`：最可能被质疑的错误设定
5. `Next diagnostic`：下一步该画图、换样本，还是比较 panel choice
