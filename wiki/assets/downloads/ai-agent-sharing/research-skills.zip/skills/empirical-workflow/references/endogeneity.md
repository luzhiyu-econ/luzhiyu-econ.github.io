# Endogeneity

## Contents
- `Problem framing`
- `Estimator routing`
- `IV workflow`
- `DID and staggered adoption`
- `Covariate handling in DID`
- `Control-group choice`
- `PSM positioning`

## Problem framing

Treat endogeneity as a **credibility problem**, not a purely technical problem.
先明确用户真正担心的是哪一种偏误：
- `selection on unobservables`
- `timing-based identification`
- `reverse causality`
- `policy endogeneity`
- `staggered-adoption bias`

Do not jump to a method before naming the threat.

---

## Estimator routing

### Quick routing tree

```text
What is the main concern?

1. Selection on unobservables
   -> panel + persistent confounding: FE first, then ask whether IV or quasi-experiment exists
   -> cross-section + credible instrument: IV
   -> no strong design: sensitivity logic, Oster bound, cautious interpretation

2. Timing-based identification
   -> policy varies across units and time: DID / event study
   -> staggered adoption: TWFE baseline + robust estimator validation
   -> continuous exposure: continuous DID or shift-share style design

3. Reverse causality
   -> lag structure credible: timing argument or lagged treatment
   -> exogenous shock exists: IV
```

### Can do

| Setting | Can do | Main assumption |
|---|---|---|
| Omitted-variable concern with credible instrument | IV / 2SLS | relevance + exclusion |
| Policy timing variation | DID / event study | parallel trends |
| Staggered treatment timing | TWFE baseline + het. TE estimator validation | parallel trends + no het. TE bias |
| Weak design environment | FE + sensitivity analysis | bounded omitted bias logic |

### Should not do

- 不要因为数据是 panel 就自动默认 DID。
- 不要把"文献常用 IV"当成自己的 validity proof。
- 不要把 estimator choice 当成软件选择题。

---

## IV workflow

### Can do

- 先说明为什么 OLS 可能有偏，再说明 IV 解决哪一层偏误。
- 同时报告 `OLS` 和 `IV`，比较方向和量级差异。
- 报告 `first-stage F` 和在需要时的 `effective F`。
- 如果 over-identified，报告 `Hansen J`，但不要过度神化它。
- 用 placebo / event-study style evidence 支撑 exclusion restriction。
- 讨论 `LATE` 的对象到底是谁，是否与政策问题相关。

### Reference case

**Barwick et al.** 的强点不只是"有 IV"，而是他们把 IV 的可信度拆成多块来讲：
- why this shock moves app usage
- why it should not directly move unrelated outcomes
- why OLS and IV differ
- why the compliers matter

### Should not do

- 不要只报 second stage，不报 first stage。
- 不要假装 first-stage 强就等于 exclusion restriction 成立。
- 不要在 weak-IV 风险明显时还把 IV 结果当唯一主结论。

### Recommended answer pattern

当用户问"这个 IV 行不行"时，优先回答：
1. `What endogeneity does it solve?`
2. `Why relevance is plausible`
3. `Why exclusion is vulnerable or defensible`
4. `What evidence can support it`
5. `What not to over-claim`

---

## DID and staggered adoption

### Core rule

For DID, the first question is not "which estimator to use".
The first question is: **what comparison identifies the effect?**

### Baseline choice

#### Can do

| Setting | Baseline approach | Why it fits |
|---|---|---|
| Clean before/after with untreated units | TWFE + event study | 简单透明，读者熟悉 |
| Staggered adoption (typical) | TWFE baseline，辅以 het. TE estimators 验证 | TWFE 是审稿人和读者最熟悉的起点；robust estimators 证明结论不因负权重失效 |
| Staggered adoption + cohort-specific clean controls needed | stacked DID 或其他 robust estimator 作为 baseline | 当设计上有明确理由需要 cohort-level comparison structure 时可以采用 |
| Phase-in policy | dynamic event study | 追踪累积效应 |

#### Should not do

- 不要在 staggered adoption 下跳过 TWFE 直接上某个 robust estimator 作为唯一 baseline，除非有明确设计理由。
- 不要只报单一 DID 系数而不给 event-study diagnostics。
- 不要把已处理单位拿来给后续 treated cohort 当对照却不解释。

### Specification ladder

#### Can do

在 baseline 表中用列展示 specification ladder，逐步扩展 FE 和控制变量，观察核心系数稳定性：
- 从 minimal specification（仅 unit FE 或 unit + time FE）开始
- 逐步加入控制变量、region×year FE、unit linear trend、industry×year FE 等
- 报告 Oster δ* 量化不可观测偏误威胁
- β 跨列稳定是识别成立的间接证据；若加入高维 FE 后系数骤降，需讨论混淆渠道

#### Should not do

- 不要把所有 FE 组合一次性全加，不给读者理解每步在吸收什么的机会。
- 不要只报最全规格而不展示系数如何随 specification 变化。

### Event study and parallel trends

#### Can do

- 每个 baseline specification 对应一张 event study 图，正文呈现最全规格，其余放附录并排
- Event study 结果优先用图呈现，而非表
- 可以用 HonestDiD（Roth 2022; Roth & Sant'Anna 2023）做 parallel trends sensitivity，对处理后显著系数给出 breakdown 图

#### Should not do

- 不要只报 event study 但不看 pre-period 系数的联合检验。
- 不要把 pre-trend 不平行的图悄悄放进 appendix 不解释。
- 不要忽视 anticipation effects，尤其在 phase-in policy 下。

### Het. TE estimator validation

#### Can do

在 staggered DID 场景下，可以用多个 robust estimators 验证 TWFE baseline 结论的稳健性：

| Estimator | Reference | Key feature |
|---|---|---|
| Callaway & Sant'Anna (CS) | Callaway & Sant'Anna (2021) | group-time ATT，灵活聚合 |
| Sun & Abraham (SA) | Sun & Abraham (2021) | interaction-weighted estimator |
| Borusyak et al. (BJS) | Borusyak et al. (2024) | imputation-based，计算高效 |
| de Chaisemartin & D'Haultfœuille (dCDH) | de Chaisemartin & D'Haultfœuille (2020) | 允许 treatment switching |
| JWDID (Wooldridge) | Wooldridge (2021) | Mundlak device，支持协变量异质性 CATT 和高维 FE |
| Stacked DID | various | cohort-specific clean comparison structure |

- 将多个 estimator 的 event study 图并排展示（3×2 或 2×3），统一坐标轴范围
- 如果所有 estimator 方向和量级一致 → TWFE baseline 可信
- 如果出现实质性差异 → 在正文讨论差异来源，考虑是否需要调整 baseline

#### Should not do

- 不要只跑一两个 robust estimator 而选择性忽略不利结果。
- 不要把 robust estimator validation 与 baseline 的叙事角色混淆——读者通常期待 TWFE 作为主结果的参照。
- 不要在没有 staggered adoption 的简单 DID 场景下机械使用这些 estimators。

### Reference case

**Rao and Risch**: 用 never-treated states 作为 clean controls，在 cohort level 组织比较，把 firm-level、aggregate-level、worker-level 结果串成同一个政策故事。

---

## Covariate handling in DID

### Core distinction

在 DID 框架中，"协变量"与"控制变量"承担不同识别角色，需区分处理（参照许文立 2026）。

#### Can do

| Variable type | Role | Form | How to enter |
|---|---|---|---|
| 协变量 / Covariate | 条件平行趋势 | 处理前时间不变（处理前一期 / 样本起始期 / 处理前均值） | TWFE 中通过 Mundlak 均值；CS/JWDID 中作为条件变量 |
| 控制变量 / Control | 吸收异质趋势 | 处理前基期值 × 时间趋势交乘 | 直接加入回归作为交乘项 |

- 协变量构造为处理前时间不变形式后，与个体 FE 共线，不能直接放入 TWFE 的 $X_{it}$ 位置
- 控制变量用 $X_i^{pre} \times t$ 形式，避免引入处理后内生性
- 在 JWDID 中，协变量对应 `controls` 参数，基期值对应 `xasis()` 选项

#### Should not do

- 不要把处理后时变控制变量原始形式直接放入 DID 回归——可能是 bad controls。
- 不要把协变量和控制变量不加区分地混用。
- 不要在 TWFE 中直接放入时间不变协变量而不经 Mundlak 均值处理。

---

## Control-group choice

### Core concern

Policy endogeneity usually enters through the control group.
最常见的问题不是"模型形式错了"，而是"对照组不可信"。

### Can do

- 用 `never-treated controls`，如果它们在制度和趋势上可比。
- 用 `not-yet-treated controls`，但要承认其比较结构更复杂。
- 用 `border design` 缩小不可观测异质性。
- 用 `placebo groups` 测试效应是否只出现在真正暴露组。
- 讨论 concurrent policies，而不是假装不存在。

### Should not do

- 不要只因为 control group 样本大就觉得它好。
- 不要在 treated 和 control 明显制度环境不同的情况下只靠 FE 安心。

---

## PSM positioning

### Can do

Treat `PSM` as a supporting device, not a premier identification strategy:
- 用它构造更可比的 control group，再进入 DID
- 用它做 robustness，说明 observables-driven selection 不是全部故事
- 在没有更强设计时，把它作为有限度的补充证据

### Should not do

- 不要把 PSM 说成解决了 unobservables。
- 不要只展示 balance table 就宣称有因果识别。
- 不要在存在更可信的 timing or instrument variation 时还把 PSM 当主角。

## Recommended answer pattern

当用户问"内生性怎么处理"时，默认输出：
1. `Core endogeneity problem`
2. `Can do options`：按可信度排序，不按技术炫度排序
3. `Key assumption for each option`
4. `Should not do`
5. `Best next diagnostic`
