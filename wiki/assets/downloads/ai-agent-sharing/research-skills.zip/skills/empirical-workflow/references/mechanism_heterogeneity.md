# Mechanism & Heterogeneity

## Contents
- `Mechanism design logic`
- `Five mechanism modes`
- `Implementation: interaction, split sample, and moderator construction`
- `Common over-claims`

## Mechanism design logic

Before doing mechanism analysis, lock two questions:
1. `What channel would have to operate if the main story is true?`
2. `What evidence would move this from storytelling to supported interpretation?`

机制分析应在 baseline identification 已经可信之后再做。
重心放在"D 是否移动了渠道变量"和"异质性是否与理论预期一致"，而不是追求间接效应的精确度量（江艇 2022）。

---

## Five mechanism modes

### Mode A: Alternative outcomes（首选）

用渠道变量替换主 outcome，沿用 baseline 识别策略只估计 D→M。

| Step | Can do | Should not do |
|---|---|---|
| 选择 M | M 与 Y 的因果关系在理论上直接、显然 | 不要选因果链条过长或明显受 Y 反向影响的 M |
| 估计 | 只跑 D→Y 和 D→M | 不要把 D 和 M 放进同一回归 |
| 解释 | D 显著影响 M → 渠道活跃 | 不要声称度量了间接效应的大小 |

**Reference**: Barwick et al. 用 study-time outcomes 替代 GPA；Dell (2011) 依次替换为土地所有权、教育、公共品供给。

### Mode B: Heterogeneity as causal argument

通过处理效应的组间异质性来验证机制，同时强化因果识别（江艇 2022）。

| Step | Logic |
|---|---|
| 1. 提出理论 T | D 通过某机制影响 Y，该机制在 M=1 组更强 / 在 M=0 组更弱或不存在 |
| 2. 检验数据 | D→Y 效应是否在 M=1 组更强，在 M=0 组更弱或不存在 |
| 3. 排除竞争性解释 | 反向因果 R 或遗漏变量 C 能否也预测此组间差异？不能 → T 成立 |

- **Strong argument**: 效应只在 M=1 组存在，M=0 组完全不存在，竞争性解释无法预测此差异。
- **Weak argument**: 效应在两组都存在但 M=1 组显著更强，组间差异显著。

**Reference**: Rajan and Zingales (1998) 用外部融资依存度做分组；Brown (2011) 用选手水平做分组；Muralidharan and Prakash (2017) 用离学校距离做连续调节。

### Mode C: Decomposition and internal consistency

把总效应拆成逻辑上应闭合的多个 margin。

**When to use**: 当 outcome 可以拆成多个 accounting items，且各项之和应等于总效应时。

**Reference**: Rao and Risch 把最低工资冲击拆成 wage bill、revenue、COGS、other deductions、owner profit，用共同 scaling 做 incidence accounting。

### Mode D: Cross-level reconciliation

在不同分析单位上比较同一现象，用层级间的张力推进机制理解。

**When to use**: 当 firm-level 和 worker-level（或 aggregate-level）结果看起来矛盾时。

**Reference**: Rao and Risch 让 firm-level employment decline 与 worker-level employment flat 形成张力，再通过 transition / retention 解释两层级为何不矛盾。

### Mode E: Extra data source

用调查、文本、高频数据或行政数据链接来三角验证渠道。

**When to use**: 当主数据源无法直接观测渠道变量时。

**Reference**: Barwick et al. 用 GPS、高频 app 数据、调查数据共同支撑机制。

---

## Implementation: interaction, split sample, and moderator construction

本节为共用实现层，主要服务 Mode B，也适用于 Mode C / D 中需要分组或交互的场景。

### 两种实现方式（建议都做）

| Style | Strength | Weakness |
|---|---|---|
| Split sample | 灵活，直观展示各组效应 | 样本量下降，不能直接检验组间差异 |
| Interaction term | 保留样本量，正式检验差异 | 交互形式更结构化 |

### 呈现格式

| Format | When to use |
|---|---|
| 表格：左两列分组 + 右一列交互 | 分组少（2-3 组） |
| Forest plot：各组点估计 + CI 并排 | 分组维度多 |
| 边际效应图 | M 为连续变量 |

### 交互项设定

**OLS**：直接加一次项和交互项。
`Y = β₀ + β₁D + β₂M + β₃D×M + controls + ε`，β₃ = 组间差异。

**DID**：加入 `Treat×Post×M` 后需注意低阶项控制。

| Term | 是否必须 | 说明 |
|---|---|---|
| `Treat×Post` | 必须 | DID 主效应 |
| `Treat×M` | 通常保留 | 控制处理组与控制组在 M 上的固有差异 |
| `Post×M` | 可选 | 只看调节效应时可省；做正式 DDD 时必须加 |

- M 为虚拟变量 → 交互项系数 = 两组 DID 效应之差
- M 为连续变量 → 交互项系数 = DID 效应随 M 的边际变化

### 分组变量的样本范围

| 情形 | 例子 | 做法 |
|---|---|---|
| M 仅处理组有意义 | 政策执行强度 | 处理组内部按 M 分组，各子样本与原控制组做 DID |
| M 全样本有意义 | 地区市场化程度、企业规模 | 全样本按 M 分组各自做 DID + 全样本交互项 |

### Moderator variable construction

M 必须是**处理前确定的**，不受 D 或 Y 影响（Balli and Sorensen 2013; 江艇 2022）。

| Approach | Construction | When it fits |
|---|---|---|
| 绝对外生变量 | 地理、自然禀赋、历史制度等时间不变特质 | 首选 |
| 处理前一期值 | 取样本起始前一期或政策实施前一期的值 | 短面板、基期清晰 |
| 处理前均值 | 取样本跨度开始前所有期的均值 | 长面板、M 噪声大 |

方法 2 和 3 可互换。对 DID，处理组和控制组统一取同一基期（如样本起始年或样本期均值）。

**Reference**: Rajan and Zingales (1998) 用美国各行业的外部融资占比作为其他国家的外部融资依存度指标，因为一国实际值同时反映供给面和需求面，不适合直接做 M。

### Should not do

- 不要用处理后时变变量作为分组依据。
- 不要用受 D 影响的变量作为 M——交互项可能捕捉 D 的非线性效应。
- 不要用同一变量既做调节变量又做中介变量。
- 不要在十几个维度里挑两个显著的讲故事。
- 不要缺乏事前理论预期，事后附会解释。

---

## Common over-claims

- 不要把 mechanism section 写成"可能有很多渠道"的空泛段落。
- 不要让 heterogeneity 变成 appendix 式数据采矿。
- 不要忽略跨层级结果之间的张力。
- 不要在 heterogeneity 与主故事矛盾时回避讨论。

## Recommended answer pattern

当用户问"机制怎么做 / 异质性怎么做"时，默认输出：
1. `Main story to test`
2. `Can do mechanism options`：首选 Mode A，辅以 Mode B-E
3. `Moderator construction`：M 如何确保处理前外生
4. `Should not do`
5. `Best next empirical move`
