# Robustness & Validity

## Contents
- `Concern-first logic`
- `Specification robustness`
- `Identification validity`
- `Heterogeneous TE estimator validation`
- `Placebo design`
- `Main text vs appendix`

## Concern-first logic

Treat robustness as a response to a specific concern, not as decorative volume.
先问"reviewer 会质疑什么"，再决定做什么检验。

---

## Specification robustness

Use this section when the concern is: 
"你的结果是否依赖于某个具体设定？"

### Can do

| Exercise | Reviewer concern | What it tests |
|---|---|---|
| Alternative outcome definition | 结果是否依赖 outcome 的定义 | measurement dependence |
| Alternative treatment coding | 结果是否依赖 treatment 的构造 | treatment-definition dependence |
| Add/drop controls | 结果是否被控制变量集合驱动 | omitted-variable sensitivity |
| Alternative FE | 结果是否被 FE choice 驱动 | absorption sensitivity |
| Alternative sample | 结果是否由特定样本驱动 | sample sensitivity |
| Alternative SE / clustering | 推断是否稳健 | inference sensitivity |
| Alternative scaling | 结果是否依赖量纲 | interpretation sensitivity |
| Oster bound | 未观测偏误要多大才会推翻结果 | omitted-variable severity |
| Covariate construction robustness | 协变量构造方式是否影响结果 | pre-treatment covariate sensitivity |
| Border design | 是否由跨地区不可观测差异驱动 | local comparability |

### Reference case

**Rao and Risch** 的稳健性体系有一个优点：每一个练习都对应一个明确 concern。
控制变量敏感性、panel choice、scaling、border design 并不是乱堆，而是在逐项回答"你到底担心什么"。

### Should not do

- 不要机械堆 FE permutations。
- 不要只展示"通过了"的稳健性检验。
- 不要用样本筛选去把结果"调稳健"。

---

## Identification validity

Use this section when the concern is: 
"你的因果解释是否可信？"

### Can do

| Diagnostic | Best for | Reviewer concern |
|---|---|---|
| Pre-trends | DID / event study | treated 和 control 原本趋势不同 |
| HonestDiD sensitivity | DID / event study | 平行趋势被违背到什么程度结论仍成立 |
| Placebo timing | DID / event study | 效果在真实处理前就出现 |
| Placebo outcome | IV / OLS / DID | treatment / IV 影响了不该影响的结果 |
| Placebo group | DID | 效果是否只在真正暴露组出现 |
| Exclusion-restriction logic | IV | IV 是否走了别的渠道 |
| First-stage / effective F | IV | weak IV |
| Over-ID test | IV with multiple instruments | 多个 IV 是否共同可接受 |
| Event-study shape | DID / IV | 处理前无效应、处理后有动态 |
| Internal consistency | Any | 结果之间是否逻辑自洽 |

### Reference cases

- **Barwick et al.**: placebo outcomes 检查 Yuanshen 和 minors' policy 不影响购物/新闻类 app。核心不是"我做了 placebo"，而是 placebo outcome 与主机制之间有清晰理论关系。
- **Rao and Risch**: pre-trends、placebo industries、placebo timing、以及 low-wage worker / teen margin 的内部一致性，共同支持 minimum wage story。

### Should not do

- 不要把 pre-trend 不平行的图悄悄放进 appendix 不解释。
- 不要把 first-stage strength 当成 exclusion restriction 的替代品。
- 不要做没有理论逻辑的 placebo。

---

## Heterogeneous TE estimator validation

### When to use

This section applies to **staggered DID** papers.
当 baseline 使用 TWFE 时，审稿人会问："有没有负权重问题？异质处理效应是否导致 TWFE 偏误？"

### Can do

- 将 TWFE / CS / SA / BJS / dCDH / JWDID 的 event study 图并排展示（3×2 或 2×3），统一坐标轴范围
- 所有 estimator 方向和量级一致 → TWFE baseline 可信，validation 放附录
- 部分 estimator 量级有差异但方向一致 → 讨论差异来源（控制组选择、聚合方式），TWFE 仍可作为 baseline
- 方向或显著性发生实质性变化 → 在正文讨论，考虑调整 baseline estimator
- JWDID CATT 可单独呈现连续调节变量的边际效应图

### Should not do

- 不要只跑一两个 robust estimator 而选择性忽略不利结果。
- 不要把六个 estimator 的系数表放正文——图已经足够，表放附录。
- 不要在没有 staggered adoption 的简单 DID 场景下机械使用这些 estimators。

---

## Placebo design

A good placebo must satisfy both conditions:
1. 如果你的主故事成立，它应当**不受影响**。
2. 如果替代解释成立，它应当**可能受影响**。

### Three common placebo types

#### Placebo outcome

选一个理论上不应受 treatment 影响的结果变量。
适合测试"是不是 treatment/IV 影响了所有东西"。

- **Barwick-style logic**: 如果游戏渠道影响学业，那购物 app 不应受影响。

#### Placebo group

选一个理论上不应受 treatment 影响的组。
适合测试"是不是 treated vs control 的别的差异在驱动结果"。

- **Rao-Risch-style logic**: 如果最低工资是主渠道，不雇佣最低工资劳动的行业不应有同样效应。

#### Placebo timing

把处理时点人为前移到真实处理前。
适合测试"是不是 pre-existing trend 在假装政策效应"。

### Randomization placebo

随机化安慰剂（如 500 次随机抽取处理组）可以提供系数分布的 benchmark：
- 绘制 placebo 系数分布密度图
- 将真实系数标注在分布中
- 如果真实系数远超 placebo 分布 → 排除随机噪声

### Should not do

- 不要把"随便挑个不相关变量"叫 placebo。
- 不要忽视 anticipation，尤其在 phase-in policy 下。

---

## Main text vs appendix

### Put in main text

- 最核心的识别诊断（event study、HonestDiD）
- 1-2 个最关键的 robustness exercises
- 排除备择解释的核心检验

### Put in appendix

- 替换变量定义
- 替换样本窗口
- FE 或 clustering 的敏感性组合
- 补充性 subgroup exercises
- Het. TE estimator validation 并排图
- 多规格 event study 图

### Core rule

If a robustness exercise does not change interpretation, summarize it briefly and move it out of the main narrative.

## Recommended answer pattern

当用户问"robustness 做哪些"时，默认输出：
1. `Main concern`
2. `High-value checks`：只列最值得做的 3-5 个
3. `Het. TE estimator validation`：如果是 staggered DID，说明并排验证逻辑
4. `Lower-value checks`：说明哪些可以放 appendix
5. `Should not do`
6. `Reviewer lens`
