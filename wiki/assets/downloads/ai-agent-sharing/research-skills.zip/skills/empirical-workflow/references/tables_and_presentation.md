# Tables & Presentation

## Contents
- `Presentation logic`
- `Table planning`
- `Figure planning`
- `Working with academic-figure`
- `Working with regression-table`
- `Main text vs appendix`
- `Paper blueprints`
- `Cross-paper lessons`
- `Recommended answer pattern`
- `Handoff template for regression-table`
- `Handoff template for academic-figure`

## Presentation logic

Treat presentation as part of identification strategy communication.
表和图不是结果仓库，而是帮助读者理解你的 empirical logic。

Ask first:
- 这张表/图回答哪个问题？
- 它是在建立 baseline、验证识别、展示动态路径，还是解释机制？
- 这个信息应该放正文还是 appendix？

---

## Table planning

### Typical table functions

| Table role | Main question | Typical content |
|---|---|---|
| `Table 1` | What does the sample look like? | summary statistics, treated vs control, pre-treatment balance, cohort distribution |
| `Baseline table` | What is the core estimate? | specification ladder (progressive FE and controls), Oster δ* |
| `Alternative explanations table` | Can competing stories be ruled out? | concurrent policy, anticipation, Triple DID, group placebo |
| `Robustness table` | Does the result survive key concerns? | high-value robustness checks |
| `Mechanism table` | Through what channel? | alternative outcomes / decomposition |
| `Heterogeneity table` | For whom is the effect stronger? | interaction or subgroup estimates |

This is a reference layout, not a mandatory sequence.

### Can do

- 把列从简到繁组织成 specification ladder。
- 在表底集中汇报 FE、controls、SE choice，而不是铺满控制变量系数。
- 对 incidence 问题，把不同 accounting items 放进同一缩放框架。
- 如果 story 同时包含 entrants / incumbents / all firms，可并列展示，而不是拆成许多零散表。
- 在排除备择解释表中，每列对应一个具体 alternative story。

### Should not do

- 不要让一张表同时回答三个不同问题。
- 不要在正文里放大量低价值 FE permutations。
- 不要把 aggregate effect 和 average effect 混写成同一类结果。

---

## Figure planning

### Can do

Use figures when the visual shape matters:
- `event study`：展示 pre-trends 和动态路径
- `HonestDiD sensitivity`：展示平行趋势违背容忍度
- `het. TE estimator comparison`：多 estimator event study 并排图
- `decomposition figure`：展示 net change 的来源
- `distribution shift`：展示 top/bottom tail changes
- `randomization placebo`：系数分布密度图 + 真实系数标注
- `figure + table pair`：图管动态与识别，表管精确 magnitude

### Should not do

- 不要给 event-study 图省略 confidence intervals。
- 不要让图和表重复展示完全同一信息。
- 不要把识别图放 appendix、把不关键的 robustness 图放正文中央。
- Event study 结果优先用图呈现，而非表。

---

## Working with `academic-figure`

Use this skill to decide **what the figure should show**.
Use `academic-figure` to decide **how the final figure should be styled and exported**.

### Recommended handoff

Before delegating to `academic-figure`, lock these fields:
- `Figure type`: event study / coefficient plot / binscatter / decomposition / distribution shift / multi-panel figure / HonestDiD breakdown / estimator comparison
- `Main question`: 这张图要回答什么 empirical question
- `Narrative role`: baseline evidence / identification diagnostic / dynamic effect / mechanism / heterogeneity / estimator validation
- `Axes`: x 和 y 分别是什么，单位是什么
- `Series design`: 单条主线、多条对比线、分组分面，还是 panel structure
- `Uncertainty display`: confidence interval / standard error band / none
- `Sample and scaling`: 使用哪个样本、是否做标准化或基期缩放
- `Main-text vs appendix`: 这张图是否承担核心叙事功能

### Division of labor

- `empirical-workflow`: 负责图的研究设计逻辑，例如这张图是否应该存在、它回答什么问题、放正文还是附录、是否应该与某张表成对出现
- `academic-figure`: 负责最终视觉实现，例如画法、版式、字体、配色、面板结构、导出格式、publication-quality 风格

### Should not do

- 不要让 `empirical-workflow` 直接代替 `academic-figure` 处理具体绘图样式和导出细节
- 不要在图的叙事功能还没锁定时就直接进入绘图，否则容易画出"好看但不承担论文功能"的图
- 不要把应该由表承担的精确数值比较硬塞进图里，也不要把应该由图承担的动态路径完全压缩成表

---

## Working with `regression-table`

Use this skill to decide **what the table should do**.
Use `regression-table` to decide **how the final table should be rendered**.

### Recommended handoff

Before delegating to `regression-table`, lock these fields:
- `Language`: English or 中文
- `Output format`: `.docx` or `.tex`
- `Table type`: baseline / heterogeneity / panel / robustness
- `Data contract`: coefficients, SEs, stars, N, R², FE indicators, Notes
- `Model ordering`: what progression the reader should see across columns or panels

### Division of labor

- `empirical-workflow`: 负责表的研究设计逻辑，例如哪张表回答哪个问题、正文与附录如何分工、列顺序是否应该体现 specification ladder
- `regression-table`: 负责最终排版与导出，例如 `.docx` / `.tex`、三线表结构、Notes、Panel 标题、输出路径

### Should not do

- 不要让 `empirical-workflow` 直接代替 `regression-table` 处理最终的表格格式细节
- 不要把一个尚未锁定逻辑的问题直接丢给 `regression-table`，否则只会得到格式正确但叙事混乱的表

---

## Main text vs appendix

### Put in main text

- baseline design 的关键结果（specification ladder table）
- readers 必须先看到的 identifying diagnostic（最全规格 event study 图、HonestDiD）
- 排除备择解释的核心检验
- 支撑核心故事的主要图表
- 少量最关键的 robustness

### Put in appendix

- 大量 sensitivity variants
- 次要 subgroup exercises
- 多规格 event study 图
- Het. TE estimator comparison 并排图
- 不改变解释的补充图表

### Core rule

Main text should teach the reader how the design works.
Appendix should prove you checked everything else.

---

## Paper blueprints

## Blueprint A: IV-led paper

Use this when the causal story is built around instrument validity.

### Example anchor: Barwick et al.

1. `Summary statistics`
2. `Reduced-form or descriptive baseline`
3. `First-stage / instrument validation evidence`
4. `Main IV results`
5. `Mechanism evidence`
6. `Appendix robustness and heterogeneity`

### Why it works

Barwick 的结构不是"按教科书顺序"，而是按 reader needs 排列：
先理解 peer setting，再相信 instrument，再接受 main outcome effects。

## Blueprint B: DID-led paper

Use this when policy timing is the main source of identification.

### Typical sequence

1. `Summary statistics`: full sample + treated vs control + pre-treatment balance + cohort distribution
2. `Baseline regression table`: specification ladder + Oster δ*
3. `Event study figure (main text)`: 最全规格的 event study 图
4. `HonestDiD sensitivity figures` (if applicable)
5. `Alternative explanations table`: concurrent policy, anticipation, Triple DID, group placebo
6. `Robustness (appendix)`: placebos, sample, variable, SE, FE robustness
7. `Het. TE estimator comparison (appendix)`: 多 estimator event study 并排图（staggered DID 场景）
8. `Mechanism table`
9. `Heterogeneity table + figures`

### Why it works

让读者按自然顺序消化 DID 故事：
先看 baseline magnitude → 再看 event study 动态路径和 pre-trends → 再排除备择解释 → 再确认 robust estimators 一致 → 最后讨论机制和异质性。

### Can do alternatives

- 有些论文把 event study 放在 baseline table 前面，用图先建立直觉再给精确数字
- incidence paper 可以把 decomposition table 紧跟 baseline，把不同 accounting items 在同一框架内呈现
- 当 firm-level 与 worker-level 结果有张力时，reconciliation evidence 可以成为独立的叙事环节

### Reference case

**Rao and Risch**: 把 event-study figures 放在叙事核心，因为这些图同时承担 validity check 和 substantive result 两个任务。用 never-treated states 做 clean controls，把 firm-level、aggregate-level、worker-level 结果串成同一个政策故事。

---

## Cross-paper lessons

### Barwick et al.

**What to learn**
- `OLS -> IV` 可以是叙事结构，而不只是估计技术
- instrument validation 可以通过 event-study 和 placebo outcomes 同时完成
- 多数据源 mechanism evidence 能显著增强说服力

### Rao and Risch

**What to learn**
- balanced / unbalanced / collapsed / individual-level 结果可以是同一故事的不同层级
- incidence table 的成功关键在共同 scaling，而不是表格格式本身
- seemingly conflicting results across units of analysis can become the paper's mechanism contribution

### Standard staggered DID workflow (许文立 2026)

**What to learn**
- TWFE 是 staggered DID 的标准 baseline
- Robust estimators（CS / SA / BJS / dCDH / JWDID）的主要角色是验证 TWFE 结论的稳健性
- Event study 优先用图呈现
- HonestDiD 是平行趋势敏感性分析的标准工具
- 协变量需区分条件平行趋势变量（处理前时间不变）和趋势控制变量（基期值×时间趋势交乘）

---

## Recommended answer pattern

当用户问"表怎么组织 / 结果怎么呈现"时，默认输出：
1. `Main empirical question of each table/figure`
2. `Recommended main-text package`
3. `Can do alternative organization`
4. `Should not do`
5. `Appendix allocation`

---

## Handoff template for `regression-table`

Use this template when the table logic is already locked and the next step is rendering.

```text
Use $regression-table to render the final table.

Language: [English / 中文]
Output format: [.docx / .tex]
Table type: [baseline / heterogeneity / panel / robustness]

Main question this table answers:
[One sentence]

Model ordering:
- Column (1): [minimal specification]
- Column (2): [add controls / add FE / reduced form / etc.]
- Column (3): [preferred specification]
- Column (4+): [IV / DID / subgroup / robustness columns if needed]

Required data contract:
- coefficients: [yes/no]
- standard errors: [yes/no]
- significance stars: [yes/no]
- N: [yes/no]
- R²: [yes/no]
- FE indicators: [yes/no]
- control-group indicators: [yes/no]
- panel labels: [yes/no]
- notes: [yes/no]

Notes to show:
- [clustered SE level]
- [fixed effects used]
- [sample restrictions]
- [any IV / first-stage / Hansen J note if needed]

Formatting constraints:
- Preserve model ordering
- Do not report nuisance control coefficients unless requested
- Use journal-style three-line layout
```

### How to use the template

- 先用 `empirical-workflow` 决定表的研究问题、列顺序、正文/附录位置。
- 再把上面的模板补全后交给 `regression-table`，让它专注于最终排版与导出。
- 如果表的逻辑还没锁定，不要急着进入 handoff；先回到本文件上面的 `Table planning` 和 `Main text vs appendix`。

### Why this helps

这个 handoff 模板把"研究设计逻辑"和"排版执行"拆开了。  
这样做可以避免一种常见问题：格式很漂亮，但列顺序、表类型和叙事功能并没有想清楚。

---

## Handoff template for `academic-figure`

Use this template when the figure logic is already locked and the next step is visual production.

```text
Use $academic-figure to produce the final figure.

Figure type: [event study / coefficient plot / binscatter / decomposition / distribution / multi-panel / HonestDiD / estimator comparison]
Narrative role: [baseline evidence / identification diagnostic / dynamic effect / mechanism / heterogeneity / estimator validation / sensitivity]

Main question this figure answers:
[One sentence]

Core design:
- x-axis: [variable / event time / bins / categories]
- y-axis: [outcome / coefficient / share / probability]
- units: [log points / percent / SD / revenue-scaled units / count]
- sample: [full sample / treated-control sample / subgroup / balanced panel / etc.]
- scaling: [none / log / standardized / baseline-scaled / revenue-scaled]

Series structure:
- main series: [single line / treated vs control / multiple groups]
- uncertainty: [95% CI / SE bars / shaded band / none]
- panel structure: [single panel / Panel A-B / 2x2 grid / 3x2 estimator comparison]
- reference lines: [t=0 / y=0 / policy date / threshold / none]

Main-text placement:
- location: [main text / appendix]
- paired table (if any): [Table X / none]
- why figure is needed: [dynamic path / pre-trends / decomposition / visual comparison / estimator validation]

Formatting priorities:
- show confidence intervals if this is an event-study or coefficient figure
- keep figure readable at journal size
- avoid decorative elements that do not add identification or interpretation value
- for estimator comparison: use unified axis ranges across all panels
```

### How to use the template

- 先用 `empirical-workflow` 决定这张图在论文里的功能：它是在建立直觉、验证识别、展示动态效应，还是支撑机制。
- 再把模板补全后交给 `academic-figure`，让它专注于 publication-quality 实现。
- 如果图和表需要配对出现，先在本文件里锁定两者分工，再进入 handoff。

### Why this helps

这个 handoff 模板把"图为什么存在"与"图怎么画得好"分开了。  
这样可以避免另一种常见问题：图做得很精美，但没有清楚回答论文中的某个 empirical question。
