---
name: journal-docx
description: Format a completed academic manuscript as a journal- or university-compliant DOCX. Use for named-journal submission formatting, thesis layout, or editorial review letters; not for drafting manuscript prose.
---

# Journal DOCX

Compile completed scholarly content into a target-compliant Word document without changing substantive claims.

## Target Router

- Generic English economics manuscript: `references/english-economics-generic.md`.
- 《经济研究》: `references/经济研究.md`.
- 中央财经大学毕业论文: `references/中央财经大学毕业论文.md`.
- Editorial review letter: `references/review-letter.md`.

Read only the selected target profile. If no profile exists, use the user's supplied author guide and record the assumptions applied.
For bundled templates and asset conventions, read `references/assets.md` only when those resources are needed.

## Workflow

1. Confirm the manuscript is ready for compilation and identify the target, language, and required components.
2. Inspect the source document, styles, sections, captions, equations, tables, references, headers, and footers.
3. Use the generic `docx` skill's bundled OOXML tools for low-level editing and validation.
4. Apply the selected target profile while preserving tracked changes, comments, equations, cross-references, and embedded objects where possible.
5. Validate package integrity, style usage, page setup, numbering, fonts, and representative rendered pages.
6. Save to a new output file unless replacement is explicit.

## Boundaries

Do not rewrite prose, regenerate analytical tables, or redesign figures. Report source defects that prevent compliant formatting rather than silently deleting content.

## Output Contract

Return the DOCX path, profile used, major formatting changes, validation results, and any unresolved target-specific requirements.
