# Assets 目录

本目录存放期刊排版可能需要的静态资源文件。

## 可能的内容

- 期刊官方 `.docx` 模板，用于提取版式细节
- 期刊 logo、封面元素或其他视觉素材
- 非系统字体文件（仅当目标期刊明确要求时）

## 使用说明

- 模板文件只作参考，正式参数以 `references/` 下的期刊规范文件为准
- 如需拆解模板文档，请调用 sibling `docx` skill 的脚本，而不是本目录下不存在的脚本：

```bash
python "/path/to/docx/scripts/office/unpack.py" template.docx unpacked/
```

- 如果从模板中提取到新的稳定规则，应回写到对应 `references/<journal>.md`
