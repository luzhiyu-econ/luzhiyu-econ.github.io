# English Economics Journal — Generic Formatting Reference

> A universal .docx manuscript format for English-language economics journals,
> based on the *Chicago Manual of Style* 18th edition (Author-Date system)
> and the submission guidelines of AER, QJE, Econometrica, REStud, and JPE.
>
> Last updated: 2026-03

---

## Table of Contents

1. [Page Setup](#1-page-setup)
2. [Title Page](#2-title-page)
3. [Abstract and Keywords](#3-abstract-and-keywords)
4. [Body Text](#4-body-text)
5. [Section Headings](#5-section-headings)
6. [Mathematics and Equations](#6-mathematics-and-equations)
7. [Tables](#7-tables)
8. [Figures](#8-figures)
9. [Footnotes](#9-footnotes)
10. [In-Text Citations (Author-Date)](#10-in-text-citations-author-date)
11. [Reference List](#11-reference-list)
12. [Appendices and Online Appendix](#12-appendices-and-online-appendix)
13. [docx-js Parameter Quick Reference](#13-docx-js-parameter-quick-reference)

---

## 1. Page Setup

| Parameter | Value | DXA / docx-js |
|-----------|-------|---------------|
| Paper size | US Letter (8.5 × 11 in) | width: 12240, height: 15840 |
| Top margin | 1 inch | 1440 |
| Bottom margin | 1 inch | 1440 |
| Left margin | 1 inch | 1440 |
| Right margin | 1 inch | 1440 |
| Content width | 6.5 inches | 9360 |
| Line spacing | 1.5 lines (submission) | `spacing.line: 360` |
| Page numbers | Bottom center or top right | — |

**Notes:**
- AER, QJE, REStud, and most top journals require 1-inch margins on all sides.
- Submission manuscripts use 1.5 line spacing (some journals accept double spacing; check individual guidelines).
- AER recommends manuscripts not exceed 40 pages at 11pt/1.5-spacing or 45 pages at 12pt/1.5-spacing.
- REStud caps at 45 pages total (including title page, tables, figures, references, appendices).

## 2. Title Page

### 2.1 Title

| Parameter | Value |
|-----------|-------|
| Font | Times New Roman |
| Size | 16pt → `size: 32` |
| Weight | Bold |
| Alignment | Centered |
| Spacing after | 24pt |

**Rules:**
- Title should be concise and informative
- Subtitle (if any) separated by a colon, same line or next line
- Capitalize headline-style (Chicago rule: capitalize first and last words, all major words)

### 2.2 Author Names

| Parameter | Value |
|-----------|-------|
| Font | Times New Roman |
| Size | 12pt → `size: 24` |
| Weight | Normal |
| Alignment | Centered |
| Spacing after | 6pt |

**Rules:**
- List all authors, separated by commas, with "and" before the last
- If using random author order (AEA ⓡ convention), place ⓡ between names
- Two-character Chinese/Korean names in Eastern order (family name first, no comma): "Liu Xinwu" not "Xinwu, Liu"

### 2.3 Affiliations

| Parameter | Value |
|-----------|-------|
| Font | Times New Roman |
| Size | 11pt → `size: 22` |
| Weight | Normal |
| Alignment | Centered |
| Format | Each institution on its own line |

**Rules:**
- Use superscript markers (*, †, ‡ or 1, 2, 3) to link authors to affiliations
- Include department, university/institution, and country
- Corresponding author email may appear here or in a footnote

### 2.4 Acknowledgment Footnote

| Parameter | Value |
|-----------|-------|
| Marker | * (asterisk) on title or first author name |
| Font | Times New Roman |
| Size | 10pt → `size: 20` |
| Spacing | Single-spaced |

**Content (in this order):**
1. Corresponding author contact information (email)
2. Grant/funding acknowledgments with grant numbers
3. RCT registration number (if applicable): "This RCT was registered as AEARCTR-XXXXXXX"
4. Thanks to colleagues, seminar participants, referees
5. Disclaimer: "The views expressed are those of the authors and do not necessarily reflect..."
6. AI disclosure (if applicable): brief description of AI use in manuscript preparation

## 3. Abstract and Keywords

### 3.1 Abstract

| Parameter | Value |
|-----------|-------|
| Label | "Abstract" (bold, left-aligned or centered) |
| Font | Times New Roman |
| Size | 12pt (same as body) → `size: 24` |
| Spacing | Single-spaced or 1.5-spaced (match body) |
| Indentation | Block indent 0.5 inch from both sides, or no indent (varies by journal) |
| Length | 100–150 words (most economics journals) |

**Rules:**
- No citations in the abstract
- No undefined acronyms
- One paragraph, no line breaks within

### 3.2 Keywords

| Parameter | Value |
|-----------|-------|
| Label | "Keywords:" (italic) |
| Font | Times New Roman, 12pt |
| Separator | Comma |
| Count | 3–5 keywords |

### 3.3 JEL Classification

| Parameter | Value |
|-----------|-------|
| Label | "JEL Classification:" or "JEL Codes:" (italic) |
| Font | Times New Roman, 12pt |
| Separator | Comma |
| Example | D82, G14, L15 |

**Rules:**
- Required by all AEA journals and most economics journals
- Use codes from https://www.aeaweb.org/econlit/jelCodes.php
- Place immediately after keywords, same formatting

## 4. Body Text

| Parameter | Value |
|-----------|-------|
| Font | Times New Roman |
| Size | 12pt → `size: 24` |
| Line spacing | 1.5 lines → `spacing.line: 360` |
| First-line indent | 0.5 inch = 720 DXA (except first paragraph after a heading) |
| Paragraph spacing | 0pt before, 0pt after |
| Alignment | Left-aligned (ragged right) or justified |

**Rules:**
- First paragraph after any heading: no indent
- All subsequent paragraphs: 0.5-inch first-line indent
- Do not add extra space between paragraphs (use indent, not spacing, to separate paragraphs)
- Use "per cent" or "percent" consistently (AEA uses "percent")
- Numbers one through nine spelled out in running text; 10 and above in numerals
- Use en-dash (–) for ranges: "pp. 117–18", "2010–2015"

## 5. Section Headings

Economics papers typically use a numbered heading hierarchy. The AEA style uses Roman numerals for top-level, letters for second-level, and Arabic numerals for third-level. Many journals also accept 1. / 1.1 / 1.1.1 numbering.

### 5.1 Level 1 — Section Heading

| Parameter | Value |
|-----------|-------|
| Numbering | I. / II. / III. (Roman) or 1. / 2. / 3. |
| Font | Times New Roman |
| Size | 14pt → `size: 28` |
| Weight | Bold |
| Alignment | Centered |
| Case | Title Case |
| Spacing before | 24pt |
| Spacing after | 12pt |

### 5.2 Level 2 — Subsection Heading

| Parameter | Value |
|-----------|-------|
| Numbering | A. / B. / C. or 1.1 / 1.2 / 1.3 |
| Font | Times New Roman |
| Size | 12pt → `size: 24` |
| Weight | Bold |
| Alignment | Left-aligned (flush left) |
| Case | Title Case |
| Spacing before | 18pt |
| Spacing after | 6pt |

### 5.3 Level 3 — Sub-subsection Heading

| Parameter | Value |
|-----------|-------|
| Numbering | 1. / 2. / 3. or 1.1.1 / 1.1.2 |
| Font | Times New Roman |
| Size | 12pt → `size: 24` |
| Weight | Bold italic |
| Alignment | Left-aligned |
| Case | Sentence case or Title Case |
| Spacing before | 12pt |
| Spacing after | 6pt |

### 5.4 Level 4 — Paragraph-Level Heading (run-in)

| Parameter | Value |
|-----------|-------|
| Format | Italic, followed by period, then text continues on same line |
| Example | *Robustness checks.* We also estimate... |

## 6. Mathematics and Equations

| Parameter | Value |
|-----------|-------|
| Display equations | Centered, numbered at right margin |
| Numbering | (1), (2), (3)... — right-aligned |
| Variables | Italic in text and equations |
| Vectors/matrices | Bold italic |
| Operators | Roman (upright): log, exp, max, min, Pr, E, Var |
| Inline fractions | Use solidus: *a*/*b* rather than built-up fractions |

**docx-js handling:**
- Simple inline math: use italic TextRun for variables, normal for operators
- Display equations: insert placeholder paragraph "【Equation (X): insert via Word equation editor or MathType】", centered, with right-aligned tab stop for equation number
- Or use Tab Stop pattern: content centered via center tab, number right-aligned via right tab

**"Where" clause:**
```
After a display equation, begin a new paragraph (no indent) with:
"where X is the ..., Y denotes ..., and Z represents ..."
```

## 7. Tables

### 7.1 Table Title

| Parameter | Value |
|-----------|-------|
| Position | Above the table |
| Label | "Table 1." or "TABLE 1." (bold or small caps) |
| Title text | Follows label after em-dash or period; not bold |
| Font | Times New Roman, 12pt |
| Alignment | Centered or left-aligned (varies) |

**Example:** `Table 1—Summary Statistics` or `TABLE 1. Summary Statistics`

### 7.2 Table Style

| Parameter | Value |
|-----------|-------|
| Style | Three-line (booktabs style) |
| Top rule | Thick (1.5pt) |
| Header separator | Thin (0.75pt) |
| Bottom rule | Thick (1.5pt) |
| Internal lines | None (no vertical rules, no internal horizontal rules) |
| Font | Times New Roman |
| Size | 10pt → `size: 20` (may be smaller than body text) |
| Numbers | Right-aligned, aligned on decimal point |
| Header text | Centered, bold |

### 7.3 Table Notes

| Parameter | Value |
|-----------|-------|
| Position | Below the table |
| Font | Times New Roman, 9–10pt → `size: 18–20` |
| Alignment | Left-aligned |
| Format | "*Notes:*" (italic) followed by general notes, then specific notes |
| Significance stars | Define consistently: *** p < 0.01, ** p < 0.05, * p < 0.1 |

**Notes hierarchy (AEA convention):**
1. *Notes:* General notes about the table (data source, sample description)
2. Standard errors in parentheses (or brackets) below coefficients
3. Significance levels: *** p < 0.01, ** p < 0.05, * p < 0.1

### 7.4 Table Placement

- For submission: tables may be placed at the end of the manuscript (after references) or embedded in the text
- Each table on its own page when placed at the end
- Reference every table in the text: "Table 1 reports..." or "...as shown in Table 1"

## 8. Figures

### 8.1 Figure Title

| Parameter | Value |
|-----------|-------|
| Position | Below the figure |
| Label | "Figure 1." or "FIGURE 1." (bold or small caps) |
| Title text | Follows label; not bold |
| Font | Times New Roman, 12pt |
| Alignment | Centered |

### 8.2 Figure Requirements

- Resolution: minimum 300 dpi for raster images
- Preferred formats: EPS, PDF (vector), or high-resolution PNG/TIFF
- Grayscale preferred for print journals; color acceptable for online-only
- All text in figures should be legible at printed size (minimum ~8pt)
- Axis labels required with units
- Legend placement: inside figure or below

### 8.3 Figure Notes

| Parameter | Value |
|-----------|-------|
| Position | Below figure title |
| Label | "*Notes:*" (italic) |
| Font | Times New Roman, 9–10pt |
| Content | Data source, sample description, variable definitions |

### 8.4 Figure Placement

- Same rules as tables: at the end or embedded in text
- Reference every figure in the text

## 9. Footnotes

| Parameter | Value |
|-----------|-------|
| Marker | Superscript Arabic numerals: 1, 2, 3... |
| Numbering | Continuous throughout the manuscript |
| Font | Times New Roman |
| Size | 10pt → `size: 20` |
| Spacing | Single-spaced |
| Placement | Bottom of each page (not endnotes) |

**Rules:**
- Footnote markers in text come after punctuation: "...results.¹" not "...results¹."
- Keep footnotes brief; substantive material belongs in the text or an appendix
- Do not use footnotes for citations — use in-text author-date citations instead
- First footnote (often unnumbered, marked with *) is the acknowledgment footnote on the title page

## 10. In-Text Citations (Author-Date)

Based on *Chicago Manual of Style* 18th edition, Author-Date system (CMOS ch. 13–14). This is the system recommended by AEA and used by most economics journals.

### 10.1 Basic Patterns

| Situation | Format | Example |
|-----------|--------|---------|
| Single author | (Author Year) | (Acemoglu 2009) |
| Single author, narrative | Author (Year) | Acemoglu (2009) shows that... |
| Two authors | (Author1 and Author2 Year) | (Acemoglu and Robinson 2012) |
| Three or more authors | (Author1 et al. Year) | (Snyder et al. 2025) |
| With page numbers | (Author Year, pp.) | (Acemoglu 2009, 142–45) |
| Multiple works, same parentheses | (Author1 Year; Author2 Year) | (Barro 1991; Mankiw 1995) |
| Same author, multiple years | (Author Year1, Year2) | (Romer 1986, 1990) |
| Same author, same year | (Author YearX) | (Barro 2000a, 2000b) |

### 10.2 Special Cases

**Direct quotation:**
> Acemoglu (2009, 45) argues that "institutions are the fundamental cause of long-run growth."

**Author name in text:**
> As Acemoglu and Robinson (2012) demonstrate, extractive institutions...

**Institutional author:**
> (World Bank 2023)

**No date:**
> (Smith n.d.)

### 10.3 "Et al." Rules (CMOS 18th ed.)

- **1 author:** always list the name
- **2 authors:** always list both names, joined by "and"
- **3+ authors:** list only the first author, followed by "et al." in both text and reference list (for 7+ authors in reference list, list first three then et al.)

**Note on reference list for 3+ authors:**
- 1–6 authors: list all in the reference list
- 7+ authors: list first three, then "et al."

## 11. Reference List

### 11.1 General Formatting

| Parameter | Value |
|-----------|-------|
| Title | "REFERENCES" or "References" |
| Font | Times New Roman, 12pt (same as body) |
| Line spacing | Same as body (1.5) or single-spaced with extra space between entries |
| Indent | Hanging indent: first line flush left, subsequent lines indented 0.5 inch (720 DXA) |
| Order | Alphabetical by first author's last name |
| Same-author entries | Chronological order; same year distinguished by a, b, c |

### 11.2 Journal Article

**Pattern:**
```
Author(s). Year. "Article Title." Journal Name Volume (Issue): Page–Range. DOI or URL.
```

**Examples:**

Single author:
```
Acemoglu, Daron. 2009. "When Does Labor Scarcity Encourage Innovation?" Journal of Political Economy 118 (6): 1037–78. https://doi.org/10.1086/658160.
```

Two authors:
```
Dittmar, Emily L., and Douglas W. Schemske. 2023. "Temporal Variation in Selection Influences Microgeographic Local Adaptation." American Naturalist 202 (4): 471–85. https://doi.org/10.1086/725865.
```

Seven authors (list first three, then et al.):
```
Snyder, Carl D., Manuel Bedrossian, Casey Barr, et al. 2025. "Extant Life Detection Using Label-Free Video Microscopy in Analog Aquatic Environments." PLOS ONE 20 (3): e0318239. https://doi.org/10.1371/journal.pone.0318239.
```

**Key rules:**
- Article titles in quotation marks, headline-style capitalization
- Journal names in italics, not abbreviated
- Volume in regular weight, issue number in parentheses, colon, page range
- DOI preferred over URL; format as full https://doi.org/... link
- Period at the end

### 11.3 Book

**Pattern:**
```
Author(s). Year. Book Title. Publisher.
```

Note: CMOS 18th edition no longer requires place of publication.

**Examples:**

```
Binder, Amy J., and Jeffrey L. Kidder. 2022. The Channels of Student Activism: How the Left and Right Are Winning (and Losing) in Campus Politics Today. University of Chicago Press.
```

Translated book:
```
Liu Xinwu. 2021. The Wedding Party. Translated by Jeremy Tiang. Amazon Crossing.
```

**Key rules:**
- Book titles in italics, headline-style capitalization
- No place of publication (CMOS 18th ed. change)
- Publisher name only
- Edition noted after title if not the first: "2nd ed."

### 11.4 Chapter in Edited Volume

**Pattern:**
```
Chapter Author(s). Year. "Chapter Title." In Book Title, edited by Editor Name(s). Publisher.
```

**Example:**
```
Doyle, Kathleen. 2023. "The Queen Mary Psalter." In The Book by Design: The Remarkable Story of the World's Greatest Invention, edited by P. J. M. Marks and Stephen Parkin. University of Chicago Press.
```

**Key rules:**
- Page ranges for chapters no longer required (CMOS 18th ed. change)
- Chapter titles in quotation marks
- Book title in italics
- "edited by" in lowercase

### 11.5 Working Paper

**Pattern:**
```
Author(s). Year. "Title." Working Paper Number, Institution. URL or DOI.
```

**Examples:**
```
Autor, David H., David Dorn, and Gordon H. Hanson. 2013. "The China Syndrome: Local Labor Market Effects of Import Competition in the United States." NBER Working Paper 18054, National Bureau of Economic Research. https://doi.org/10.3386/w18054.
```

### 11.6 Thesis or Dissertation

**Pattern:**
```
Author. Year. "Title." PhD diss., University. Database (ID).
```

**Example:**
```
Blajer de la Garza, Yuna. 2019. "A House Is Not a Home: Citizenship and Belonging in Contemporary Democracies." PhD diss., University of Chicago. ProQuest (13865986).
```

### 11.7 Website or Online Source

**Pattern:**
```
Author/Organization. Year. "Page Title." Site Name. URL.
```

**Example:**
```
Google. 2023. "Privacy Policy." Privacy & Terms. Effective November 15. https://policies.google.com/privacy.
```

For sources with no date, use "n.d." and include access date:
```
Yale University. n.d. "About Yale: Yale Facts." Accessed March 8, 2022. https://www.yale.edu/about-yale/yale-facts.
```

### 11.8 Government or Institutional Reports

**Pattern:**
```
Organization. Year. Title. Place: Publisher. URL.
```

**Example:**
```
World Bank. 2023. World Development Report 2023: Migrants, Refugees, and Societies. Washington, DC: World Bank. https://doi.org/10.1596/978-1-4648-1941-4.
```

### 11.9 Repeated Author Entries

When multiple works by the same author(s) appear consecutively:
- CMOS 18th edition: use 3-em dash (———) in place of the author name in the bibliography; in a reference list (author-date), repeat the name for each entry
- **Economics convention:** repeat the full author name for each entry (do NOT use the 3-em dash in author-date reference lists)

Order: chronological, then alphabetical by title for same year.
```
Acemoglu, Daron. 2009. ...
Acemoglu, Daron. 2012a. ...
Acemoglu, Daron. 2012b. ...
Acemoglu, Daron, and James A. Robinson. 2012. ...
```

Single-author entries precede multi-author entries beginning with the same name.

## 12. Appendices and Online Appendix

### 12.1 Print Appendix

| Parameter | Value |
|-----------|-------|
| Heading | "Appendix" or "Appendix A", "Appendix B"... |
| Numbering | Tables: Table A1, A2...; Figures: Figure A1, A2...; Equations: (A1), (A2)... |
| Placement | After references |
| Format | Same as body text |

### 12.2 Online Appendix

- Label clearly: "Online Appendix" or "Supplementary Material"
- REStud: max 30 pages, same formatting as manuscript
- Contains: robustness checks, additional results, detailed proofs, data description
- Main paper must be self-contained without the online appendix

## 13. docx-js Parameter Quick Reference

```javascript
// ===== Page Setup =====
page: {
  size: { width: 12240, height: 15840 },  // US Letter
  margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 }  // 1 inch all sides
}

// ===== Font =====
const FONT = "Times New Roman";

// ===== Sizes (half-point) =====
const SIZES = {
  title: 32,        // 16pt — paper title
  sectionH1: 28,    // 14pt — level 1 heading
  body: 24,         // 12pt — body text, headings 2–3, abstract, references
  affiliation: 22,  // 11pt — affiliations
  footnote: 20,     // 10pt — footnotes, table/figure notes
  tableBody: 20,    // 10pt — table content
  small: 18,        // 9pt — table notes if needed
};

// ===== Line Spacing (twip: 1pt = 20twip) =====
const SPACING = {
  body: { line: 360, lineRule: "atLeast" },     // 1.5 lines (submission format)
  double: { line: 480, lineRule: "atLeast" },    // double-spaced alternative
  single: { line: 240, lineRule: "atLeast" },    // single-spaced (footnotes, table notes)
};

// ===== Indentation =====
const INDENT = {
  firstLine: 720,    // 0.5 inch — body paragraph first-line indent
  hanging: 720,      // 0.5 inch — reference list hanging indent
  blockQuote: 720,   // 0.5 inch — block quote indent from left
};

// ===== Heading Spacing (twips) =====
const HEADING_SPACING = {
  h1: { before: 480, after: 240 },  // 24pt before, 12pt after
  h2: { before: 360, after: 120 },  // 18pt before, 6pt after
  h3: { before: 240, after: 120 },  // 12pt before, 6pt after
};

// ===== Three-Line Table Borders =====
const TABLE_BORDERS = {
  topRule:    { style: "single", size: 12, color: "000000" },  // 1.5pt
  midRule:    { style: "single", size: 6,  color: "000000" },  // 0.75pt
  bottomRule: { style: "single", size: 12, color: "000000" },  // 1.5pt
  none:       { style: "none",   size: 0,  color: "FFFFFF" },
};

// ===== Reference List Entry (hanging indent) =====
// paragraph: { indent: { left: 720, hanging: 720 } }
// This produces: first line flush left, continuation lines indented 0.5"
```

---

## Appendix A: Journal-Specific Deviations

Most top economics journals follow the conventions above with minor variations. Known deviations:

| Journal | Deviation |
|---------|-----------|
| AER | 11pt font acceptable; 40-page limit at 11pt/1.5-spacing; uses "Chicago Manual Author-Date" citation style explicitly |
| QJE | Double-spaced acceptable; Times New Roman or similar |
| REStud | 45-page limit (all inclusive); 12pt mandatory; references and footnotes may be single-spaced |
| Econometrica | Has its own LaTeX template; Word submissions less common |
| JPE | Follows Chicago style (University of Chicago Press journal) |
| AEJ series | Same as AER guidelines |

When submitting to a specific journal, always check the journal's current "Instructions to Authors" page for any updates to these general conventions.

## Appendix B: Headline-Style Capitalization (Chicago Rules)

For titles of articles, books, and headings. Capitalize:
- First and last word of the title/subtitle
- All "major" words (nouns, verbs, adjectives, adverbs, pronouns)
- Both parts of a hyphenated compound if both are major words

Do NOT capitalize:
- Articles: a, an, the
- Prepositions: of, in, to, for, with, on, at, by, from (unless first/last word)
- Coordinating conjunctions: and, but, or, nor, for, yet, so
- "to" in infinitives

**Examples:**
- "When Does Labor Scarcity Encourage Innovation?"
- "The China Syndrome: Local Labor Market Effects of Import Competition in the United States"
- "Give Credit Where Credit Is Due: Tracing Value Added in Global Production Chains"