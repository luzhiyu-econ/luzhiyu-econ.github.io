# Editorial Review Letter — Word Formatting Reference

> 将 `editorial_review.md` 编译为类邮件回复信格式的 `.docx`。
> 整体视觉：专业、克制、易读——像一封排版精良的编辑部回复函，不是论文稿件。
>
> Last updated: 2026-03

---

## Table of Contents

1. [Page Setup](#1-page-setup)
2. [Font System](#2-font-system)
3. [Document Structure](#3-document-structure)
4. [Letter Header Zone](#4-letter-header-zone)
5. [Letter Body](#5-letter-body)
6. [Separator](#6-separator)
7. [Review Detail Sections](#7-review-detail-sections)
8. [Footer](#8-footer)
9. [Inline Formatting](#9-inline-formatting)
10. [CJK Text Handling](#10-cjk-text-handling)
11. [docx-js Parameter Quick Reference](#11-docx-js-parameter-quick-reference)
12. [Mapping editorial_review.md → Word](#12-mapping-editorial_reviewmd--word)
13. [Output](#13-output)

---

## 1. Page Setup

| Parameter | Value | DXA / docx-js |
|-----------|-------|---------------|
| Paper size | US Letter (8.5 × 11 in) | width: 12240, height: 15840 |
| Top margin | 1.2 inch | 1728 |
| Bottom margin | 1 inch | 1440 |
| Left margin | 1.2 inch | 1728 |
| Right margin | 1.2 inch | 1728 |
| Content width | 6.1 inches | 8784 |

---

## 2. Font System

文档使用中英双语。不要用单一字符串设置字体——docx-js 会把字符串同时赋给 `ascii`、`hAnsi`、`cs`、`eastAsia` 四个 slot，导致中文字形丢失。必须使用对象形式分别指定 Latin 和 East Asian 字体。

### 2.1 字体对象

| 常量 | Latin (ascii / hAnsi / cs) | East Asian (eastAsia) | 用途 |
|------|---------------------------|----------------------|------|
| `FONT_BODY` | Times New Roman | SimSun (宋体) | 信件正文、审稿正文、列表、表格 |
| `FONT_HEADING` | Times New Roman | SimHei (黑体) | Section / Subsection / Concern 标题 |

```javascript
const FONT_BODY = {
  ascii: 'Times New Roman', hAnsi: 'Times New Roman',
  cs: 'Times New Roman', eastAsia: 'SimSun',
};
const FONT_HEADING = {
  ascii: 'Times New Roman', hAnsi: 'Times New Roman',
  cs: 'Times New Roman', eastAsia: 'SimHei',
};
```

### 2.2 Document-level 默认字体

在 `Document` 构造参数中设置 `styles.default.document.run`，使 numbering、list 等元素自动继承双字体，无需逐一指定。

```javascript
styles: {
  default: {
    document: {
      run: { font: FONT_BODY, size: 22 },
    },
  },
},
```

---

## 3. Document Structure

整个文档按阅读顺序分为三个视觉区域：

```
┌─────────────────────────────────────┐
│  Letter Header Zone (no numbering)  │  Label + Date / Paper Title / Decision
├─────────────────────────────────────┤
│  Letter Body (no numbering)         │  Dear Author(s), ... Sincerely, Editor
├─────────── separator ───────────────┤
│  Review Detail Sections (numbered)  │  §1 Rationale → §2 Diagnostic → §3 Roadmap → §4 Journal
├─────────────────────────────────────┤
│  Footer                            │  居中页码
└─────────────────────────────────────┘
```

不分 section（Word 的 section break）——用段落格式和一条水平线分隔即可。

---

## 4. Letter Header Zone

从上到下排列：

### 4.1 Label + Date Line (one paragraph, two tab stops)

| Parameter | Value |
|-----------|-------|
| Left text | "EDITORIAL REVIEW" (全大写) |
| Right text | 日期 (e.g. "March 2026") |
| Font | `FONT_BODY` |
| Size | 10pt → `size: 20` |
| Weight | Normal |
| Color | `#888888` |
| Letter spacing (left text) | 2pt → `characterSpacing: 40` |
| Alignment | 左文本 + 右对齐 tab stop `TabStopPosition.MAX` |
| Spacing after | 12pt → `after: 240` |

```javascript
new Paragraph({
  spacing: { after: 240 },
  tabStops: [{ type: TabStopType.RIGHT, position: TabStopPosition.MAX }],
  children: [
    new TextRun({
      text: 'EDITORIAL REVIEW',
      font: FONT_BODY, size: 20, color: '888888',
      characterSpacing: 40,
    }),
    new TextRun({
      text: '\t' + dateString,
      font: FONT_BODY, size: 20, color: '888888',
    }),
  ],
})
```

### 4.2 Paper Title

| Parameter | Value |
|-----------|-------|
| Font | `FONT_HEADING` |
| Size | 14pt → `size: 28` |
| Weight | Bold |
| Alignment | Left |
| Spacing after | 6pt → `after: 120` |
| Bottom border | Single, 0.5pt, color `#D0D0D0`, space 6pt — 在标题下方形成视觉分区 |

```javascript
new Paragraph({
  spacing: { after: 120 },
  border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: 'D0D0D0', space: 6 } },
  children: [
    new TextRun({ text: paperTitle, font: FONT_HEADING, size: 28, bold: true }),
  ],
})
```

### 4.3 Decision Line

| Parameter | Value |
|-----------|-------|
| Text | "Decision: [Reject / Reject and Resubmit / R&R / Conditional Accept]" |
| Font | `FONT_HEADING` |
| Size | 12pt → `size: 24` |
| Weight | Bold |
| Alignment | Left |
| Spacing before | 12pt → `before: 240` |
| Spacing after | 18pt → `after: 360` |

---

## 5. Letter Body

### 5.1 Salutation

| Parameter | Value |
|-----------|-------|
| Text | "Dear Author(s)," |
| Font | `FONT_BODY` |
| Size | 11.5pt → `size: 23` |
| Weight | Normal |
| Spacing after | 8pt → `after: 160` |

### 5.2 Letter Paragraphs

| Parameter | Value |
|-----------|-------|
| Font | `FONT_BODY` |
| Size | 11.5pt → `size: 23` |
| Line spacing | 1.15 lines → `spacing.line: 276` |
| First-line indent | None (block style letter) |
| Paragraph spacing | 0pt before, 8pt after |
| Alignment | Left (ragged right) |

Letter body 使用 block style（无首行缩进，段间距分隔段落），不使用 indented style。Letter body 为英文，保持 Left 对齐。

### 5.3 Closing

| Parameter | Value |
|-----------|-------|
| "Sincerely," | Same font/size as body, spacing before 16pt |
| "Editor" | Same font/size, spacing after 4pt |

---

## 6. Separator

Letter body 与 review detail 之间用一条水平线隔开。

| Parameter | Value |
|-----------|-------|
| Implementation | Paragraph with bottom border |
| Border style | Single, 0.75pt, color `#CCCCCC` |
| Spacing before | 18pt → `before: 360` |
| Spacing after | 18pt → `after: 360` |

```javascript
new Paragraph({
  spacing: { before: 360, after: 360 },
  border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: 'CCCCCC', space: 1 } },
  children: [],
})
```

---

## 7. Review Detail Sections

Separator 之后的内容是 `editorial_review.md` 的 §1–§4，在 Word 中保持编号和层级。

**重要**：Review detail 部分为中文，段落使用 **两端对齐 + 首行缩进**（见 §10）。

### 7.1 Section Heading (§1, §2, §3, §4)

| Parameter | Value |
|-----------|-------|
| Font | `FONT_HEADING` |
| Size | 13pt → `size: 26` |
| Weight | Bold |
| Alignment | Left |
| Spacing before | 24pt → `before: 480` |
| Spacing after | 8pt → `after: 160` |
| Numbering | "1. ", "2. ", "3. ", "4. " — inline text, not Word auto-numbering |

### 7.2 Subsection Heading (§2.1, §2.2, etc.)

| Parameter | Value |
|-----------|-------|
| Font | `FONT_HEADING` |
| Size | 11.5pt → `size: 23` |
| Weight | Bold |
| Alignment | Left |
| Spacing before | 14pt → `before: 280` |
| Spacing after | 6pt → `after: 120` |

### 7.3 Concern Heading (#### level in md)

Concern 名称与 severity tag 在同一段落中使用不同样式。

| 部分 | Font | Size | Weight | Style | Color |
|------|------|------|--------|-------|-------|
| Concern 名称 (e.g. "Concern 1. 核心贡献不够单一") | `FONT_HEADING` | 11pt → `size: 22` | Bold | Normal | 黑色 |
| " — " 分隔符 | `FONT_BODY` | 11pt → `size: 22` | Normal | Normal | `#666666` |
| Severity tag (e.g. "Identity-changing") | `FONT_BODY` | 11pt → `size: 22` | Normal | Italic | `#666666` |

| Parameter | Value |
|-----------|-------|
| Spacing before | 10pt → `before: 200` |
| Spacing after | 4pt → `after: 80` |

```javascript
function concernHeading(text) {
  const raw = text.replace(/^####\s+/, '').replace(/\*\*/g, '').replace(/`/g, '').trim();
  const parts = raw.split(' — ');
  const children = [];
  children.push(new TextRun({
    text: parts[0], font: FONT_HEADING, size: 22, bold: true,
  }));
  if (parts.length > 1) {
    children.push(new TextRun({
      text: ' — ', font: FONT_BODY, size: 22, color: '666666',
    }));
    children.push(new TextRun({
      text: parts.slice(1).join(' — '),
      font: FONT_BODY, size: 22, italics: true, color: '666666',
    }));
  }
  return new Paragraph({
    spacing: { before: 200, after: 80 },
    children,
  });
}
```

### 7.4 Body Text (review detail)

| Parameter | Value |
|-----------|-------|
| Font | `FONT_BODY` |
| Size | 11pt → `size: 22` |
| Line spacing | 1.3 lines → `spacing.line: 312` |
| **First-line indent** | **2 字符 ≈ 440 DXA** (`indent: { firstLine: 440 }`) |
| Paragraph spacing | 0pt before, 6pt after |
| **Alignment** | **Justified (两端对齐)** → `AlignmentType.JUSTIFIED` |

比 letter body 小半号（11pt vs 11.5pt），视觉上区分"信件"与"附件式审稿报告"。中文正文使用首行缩进 + 两端对齐，符合中文学术文本阅读习惯。

### 7.5 Bullet / Numbered Lists

| Parameter | Value |
|-----------|-------|
| Font | `FONT_BODY`, 11pt |
| Indent | left: 504 DXA (0.35 inch), hanging: 360 DXA |
| Paragraph spacing | 0pt before, 4pt after |
| Line spacing | 1.3 lines → `spacing.line: 312` |
| Alignment | Justified |

使用 docx-js numbering config，不要手写 unicode bullet。

**编号列表重启规则**：Markdown 中多个独立编号列表（如 Identity-Changing Requirements 的 1-2-3 和 Repairable Issues 的 1-2-3）必须使用不同的 numbering reference，否则 Word 会把编号连续递增。判定方法：当遇到以 `1.` 开头的编号项时，视为新列表组的开始，生成新的 numbering reference；后续 `2.`, `3.` 等沿用该 reference。中间夹有空行或 `-` 子列表不影响组的连续性。

### 7.6 Tables (Tier Assessment, etc.)

| Parameter | Value |
|-----------|-------|
| Style | Simple grid, thin borders `#CCCCCC` |
| Header row | Bold, light gray fill `#F2F2F2` |
| Font | `FONT_BODY`, 10.5pt → `size: 21` |
| Cell margins | top/bottom: 60 DXA, left/right: 100 DXA |

不使用三线表（那是论文表格规范）。Review letter 中的表格是信息展示，用简洁网格即可。

---

## 8. Footer

| Parameter | Value |
|-----------|-------|
| Content | 居中页码 |
| Font | `FONT_BODY` |
| Size | 10pt → `size: 20` |
| Color | `#999999` |
| Alignment | Center |

```javascript
footers: {
  default: new Footer({
    children: [new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [new TextRun({
        children: [PageNumber.CURRENT],
        font: FONT_BODY, size: 20, color: '999999',
      })],
    })],
  }),
},
```

不加页眉。

---

## 9. Inline Formatting

编译时不要简单地把 `**` 和 `` ` `` 全部剥掉。应解析 Markdown inline 格式，映射为 TextRun 属性：

| Markdown | TextRun 属性 |
|----------|-------------|
| `**text**` | `bold: true` |
| `` `term` `` | `italics: true` |
| 普通文本 | 无特殊属性 |

解析方法：用正则 `/(\*\*(.+?)\*\*|`(.+?)`)/g` 拆分文本为 segments，每个 segment 生成对应的 TextRun。

```javascript
function parseInline(text, baseFont, baseSize) {
  const runs = [];
  const re = /(\*\*(.+?)\*\*|`(.+?)`)/g;
  let last = 0;
  let m;
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) {
      runs.push(new TextRun({
        text: text.slice(last, m.index),
        font: baseFont, size: baseSize,
      }));
    }
    if (m[2]) {
      runs.push(new TextRun({
        text: m[2], font: baseFont, size: baseSize, bold: true,
      }));
    } else if (m[3]) {
      runs.push(new TextRun({
        text: m[3], font: baseFont, size: baseSize, italics: true,
      }));
    }
    last = m.index + m[0].length;
  }
  if (last < text.length) {
    runs.push(new TextRun({
      text: text.slice(last),
      font: baseFont, size: baseSize,
    }));
  }
  return runs;
}
```

---

## 10. CJK Text Handling

### 10.1 行拼接

Markdown 文件中，一个段落可能在编辑器中被软换行为多行。编译时需要将同一段落的多行拼接为一个字符串。

拼接规则：当相邻两行的拼接点两侧均为 CJK 字符时，用空字符串拼接（中文之间不加空格）；否则用空格拼接（英文需要空格）。

```javascript
const CJK_RE = /[\u4e00-\u9fff\u3000-\u303f\uff00-\uffef]/;

function joinLines(lines) {
  if (lines.length === 0) return '';
  let result = lines[0];
  for (let i = 1; i < lines.length; i++) {
    const prevChar = result[result.length - 1];
    const nextChar = lines[i][0];
    const sep = (CJK_RE.test(prevChar) && CJK_RE.test(nextChar)) ? '' : ' ';
    result += sep + lines[i];
  }
  return result;
}
```

### 10.2 中英文段落区分

| 区域 | 语言 | 对齐 | 首行缩进 |
|------|------|------|----------|
| Letter Body (§5) | 英文 | Left (ragged right) | 无 |
| Review Detail Body (§7.4) | 中文 | Justified (两端对齐) | 440 DXA (≈ 2 字符) |
| Review Detail Lists (§7.5) | 中文 | Justified | 由 numbering indent 控制 |

中文段落中的英文术语、变量名、期刊名、作者姓名保持英文原文，由 `FONT_BODY` 的 `ascii` slot 自动匹配 Times New Roman。

---

## 11. docx-js Parameter Quick Reference

```javascript
// ===== Page Setup =====
page: {
  size: { width: 12240, height: 15840 },
  margin: { top: 1728, right: 1728, bottom: 1440, left: 1728 },
}

// ===== Font Objects =====
const FONT_BODY = {
  ascii: 'Times New Roman', hAnsi: 'Times New Roman',
  cs: 'Times New Roman', eastAsia: 'SimSun',
};
const FONT_HEADING = {
  ascii: 'Times New Roman', hAnsi: 'Times New Roman',
  cs: 'Times New Roman', eastAsia: 'SimHei',
};

// ===== Sizes (half-point) =====
const SIZES = {
  paperTitle: 28,     // 14pt — paper title
  sectionH1: 26,      // 13pt — review detail section heading
  decisionLine: 24,   // 12pt — decision line
  letterBody: 23,     // 11.5pt — letter paragraphs
  subsectionH2: 23,   // 11.5pt — subsection heading (bold)
  reviewBody: 22,     // 11pt — review detail body text
  concernH3: 22,      // 11pt — concern heading (bold)
  tableBody: 21,      // 10.5pt — table content
  headerLabel: 20,    // 10pt — "EDITORIAL REVIEW" label + date
  footerPage: 20,     // 10pt — footer page number
};

// ===== Line Spacing =====
const LINE_SPACING = {
  letter: { line: 276, lineRule: 'atLeast' },   // 1.15 lines — letter body
  review: { line: 312, lineRule: 'atLeast' },   // 1.3 lines — review detail
  single: { line: 240, lineRule: 'atLeast' },   // single — tables, lists
};

// ===== Paragraph Spacing (twips, 20 twips = 1pt) =====
const PARA_SPACING = {
  headerLabel:  { after: 240 },                  // 12pt after
  paperTitle:   { after: 120 },                  // 6pt after
  decisionLine: { before: 240, after: 360 },     // 12pt before, 18pt after
  letterPara:   { before: 0, after: 160 },       // 8pt after
  closing:      { before: 320, after: 80 },      // 16pt before, 4pt after
  separator:    { before: 360, after: 360 },     // 18pt before, 18pt after
  sectionH1:    { before: 480, after: 160 },     // 24pt before, 8pt after
  subsecH2:     { before: 280, after: 120 },     // 14pt before, 6pt after
  concernH3:    { before: 200, after: 80 },      // 10pt before, 4pt after
  reviewPara:   { before: 0, after: 120 },       // 6pt after
  listItem:     { before: 0, after: 80 },        // 4pt after
};

// ===== Separator =====
const separator = new Paragraph({
  spacing: { before: 360, after: 360 },
  border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: 'CCCCCC', space: 1 } },
  children: [],
});

// ===== Numbered List — Dynamic Reference (CRITICAL) =====
// Each independent numbered list group MUST use a separate numbering
// reference, otherwise Word continues the counter across groups.
// Detect by item number: `1.` starts a new group, `2.`+ continues.
const numberingConfigs = [];
let numListCounter = 0;

function newNumberingRef() {
  numListCounter++;
  const ref = 'numbers-' + numListCounter;
  numberingConfigs.push({
    reference: ref,
    levels: [{
      level: 0,
      format: LevelFormat.DECIMAL,
      text: '%1.',
      alignment: AlignmentType.LEFT,
      style: {
        paragraph: { indent: { left: 504, hanging: 360 } },
        run: { font: FONT_BODY },
      },
    }],
  });
  return ref;
}

// In the line-by-line parser:
//   if (/^\d+\.\s+/.test(trimmed)) {
//     const itemNum = parseInt(trimmed.match(/^(\d+)\./)[1], 10);
//     if (itemNum === 1) currentNumRef = newNumberingRef();
//     children.push(listParagraph(text, currentNumRef));
//   }
//
// Then in Document constructor:
//   numbering: { config: [ bulletConfig, ...numberingConfigs ] }

// ===== Table Borders (simple grid) =====
const GRID_BORDER = { style: 'single', size: 4, color: 'CCCCCC' };
const GRID_BORDERS = {
  top: GRID_BORDER, bottom: GRID_BORDER,
  left: GRID_BORDER, right: GRID_BORDER,
};
```

---

## 12. Mapping editorial_review.md → Word

按 md 文件从上到下，逐段映射：

| Markdown 内容 | Word 区域 | 样式 |
|---------------|-----------|------|
| (auto-generated) | Label + Date line | §4.1 |
| `# Editorial Review: [Title]` | Letter Header → Paper Title | §4.2 |
| `**Decision: ...**` | Letter Header → Decision Line | §4.3 |
| `Dear Author(s),` ... `Sincerely, Editor` | Letter Body | §5 |
| `---` | Separator | §6 |
| `## 1. Decision Rationale` | Review Detail, Section Heading | §7.1 |
| 正文段落 | Review Detail, Body Text (首行缩进 + 两端对齐) | §7.4 |
| `### 2.1 Contribution Level` 等 | Review Detail, Subsection Heading | §7.2 |
| `#### Concern N. ... — Severity` | Review Detail, Concern Heading (severity tag italic) | §7.3 |
| `- item` / `1. item` | Review Detail, Bullet/Numbered List | §7.5 |
| Markdown table | Review Detail, Simple Grid Table | §7.6 |
| `## 3. Revision Roadmap` | Review Detail, Section Heading | §7.1 |
| `## 4. Journal Recommendation` | Review Detail, Section Heading | §7.1 |
| (auto-generated) | Footer — 居中页码 | §8 |

### Inline Formatting

段落文本中的 `**bold**` 和 `` `code` `` 不要剥掉，按 §9 规则解析为带样式的 TextRun。

### CJK Paragraph Rules

Review detail 中的正文段落按 §10 规则处理：两端对齐 + 首行缩进 + CJK 感知行拼接。

### Numbered List Restart (CRITICAL)

**不要对所有编号列表使用同一个 numbering reference。** 同一 reference 下 Word 会把编号连续递增（1-2-3 接着 4-5-6），而不是每组重新从 1 开始。必须按 §7.5 和 §11 的 `newNumberingRef()` 模式，在遇到 `1.` 开头的行时生成新 reference。中间夹有空行、`-` 子列表或正文段落不影响同一组的连续性。

---

## 13. Output

- 输出路径与 `editorial_review.md` 同目录，文件名 `editorial_review.docx`
- 生成后执行校验：`python "/path/to/docx/scripts/office/validate.py" <path>`
