---
name: literature-review
description: Search, screen, organize, and synthesize academic literature using journal lists, OpenAlex, Chinese sources, and working-paper sources. Use for literature searches, bibliographies, evidence mapping, or drafting a literature review.
---

# Literature Review

Build a reproducible evidence set and synthesize it around the user's research question.

## Modes

- Exploration: map concepts, adjacent fields, foundational work, and current frontier papers.
- Targeted: find evidence for a specific claim, mechanism, method, or citation gap.

## Route

- Read `references/keyword_design.md` before broad or ambiguous searches.
- Read `references/openalex_api.md` for filters, IDs, batching, and API details.
- Read `references/review_writing.md` before drafting a synthesis.
- Pass `assets/journal_list.json`, `assets/chinese_journal_list.json`, and `assets/working_paper_sources.json` directly to bundled scripts; do not load entire lists into context.

## Workflow

1. Translate the topic into concepts, mechanisms, synonyms, and exclusion terms.
2. Search Chinese and English sources as the question requires; add working papers for active frontiers.
3. Record queries, filters, dates, and source pools in `search_log.md`.
4. Screen titles and abstracts against explicit inclusion criteria; separate peer-reviewed work from working papers.
5. Verify metadata and deduplicate before writing `reference.bib` or `workingpaper.json`.
6. Read the most relevant papers deeply enough to compare questions, designs, results, and limitations.
7. Stop when new searches add little conceptual coverage, not after an arbitrary paper count.

Use the project's environment for project outputs. The bundled search scripts may be run with the configured skill interpreter when used for temporary analysis.

## Output

Deliver the requested artifacts and a synthesis organized by arguments or mechanisms, not a paper-by-paper list. Mark unresolved metadata and inaccessible evidence explicitly.
