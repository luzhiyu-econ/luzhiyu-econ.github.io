# Keyword Design for OpenAlex Searches

This note explains how to define search keywords so one research topic is covered as completely as possible in OpenAlex.

## 1 · Core Principle

Do not treat a topic as a single phrase. A usable OpenAlex search strategy should represent the topic as a small **keyword set**, not one isolated query.

For this skill, a well-covered topic usually needs **1-3 English keyword groups**, and each group should collectively capture:
- the core concept,
- common academic synonyms,
- adjacent phrasing used in papers,
- and, when needed, the method, setting, mechanism, or outcome dimension.

The goal is not to maximize query complexity. The goal is to make sure the search can contain the topic's main academic expression space without drifting too far away from the topic.

## 2 · Default Workflow

When the user gives a topic, define keywords in this order:

1. Write the topic in plain Chinese.
2. Split it into conceptual blocks:
   - research object,
   - explanatory factor or treatment,
   - outcome variable,
   - mechanism or channel,
   - setting, sample, country, or period,
   - method terms if the literature is often method-labeled.
3. Translate each block into standard English academic language.
4. For the most important blocks, add 1-3 close synonyms or adjacent formulations.
5. Build 1-3 keyword groups, each with a slightly different emphasis.
6. Search iteratively and inspect the first pages of results.
7. Refine the keyword groups if the results are too narrow, too broad, or clearly off-topic.

## 3 · What It Means to “Contain a Topic”

A keyword design “contains a topic” when it can retrieve papers from the topic's major expression forms, rather than only one wording.

In practice, that means your keyword groups should be able to cover most of the following when relevant:
- canonical field term,
- alternative naming convention,
- broader umbrella term,
- narrower but common subterm,
- policy or institutional phrasing,
- empirical outcome phrasing,
- mechanism phrasing.

If one topic is known under several labels in the literature, the keyword design is incomplete unless those labels are represented somewhere in the search rounds.

## 4 · Query Construction Rules

### 4.1 Start from the canonical English term

Prefer the expression most often seen in article titles, abstracts, and top-journal wording.

Example:
- Chinese topic: `环境规制`
- Prefer first query term: `environmental regulation`
- Also consider: `environmental policy`, `environmental governance`

### 4.2 Add synonyms selectively

Do not dump many synonyms into one query. Add only the ones that are common and meaningfully expand coverage.

Good:
- `ESG performance`
- `sustainability performance`
- `corporate sustainability`

Bad:
- adding 8-10 loosely related buzzwords that make the query noisy

### 4.3 Separate topic coverage into multiple rounds

Instead of making one oversized query, use several focused keyword groups.

Recommended pattern:
- Group A: canonical topic wording
- Group B: close synonym wording
- Group C: mechanism / method / setting wording

This is usually better than forcing all terms into one Boolean expression.

### 4.4 Use Boolean logic to preserve topic structure

Use `AND` to bind the main dimensions of the topic.

Examples:
- `ESG performance AND financing constraints`
- `environmental regulation AND green innovation`
- `institutional investors AND carbon disclosure`

Use `OR` only when multiple expressions are genuinely interchangeable.

Example:
- `"ESG disclosure" OR "sustainability disclosure"`

Use `NOT` cautiously. Only exclude a term when it repeatedly introduces a stable and clearly irrelevant literature stream.

### 4.5 Add method terms only when they are part of the literature identity

Sometimes the literature is organized around an empirical design or framework. In those cases, method terms can improve precision.

Examples:
- `difference-in-differences AND environmental regulation`
- `event study AND ESG disclosure`

Do not make method terms mandatory if they would wrongly exclude large parts of the literature.

## 5 · Topic Expansion Template

Use this template when designing searches for a new topic:

### Step A: Define the topic

- Chinese topic:
- Research question:
- What kind of literature is needed: theory / empirical / review / policy / methods

### Step B: Split the topic

- Core concept:
- Synonym 1:
- Synonym 2:
- Treatment / explanatory factor:
- Outcome:
- Mechanism:
- Setting:
- Method phrase:

### Step C: Build 1-3 keyword groups

- Group 1: canonical wording
- Group 2: synonym or adjacent wording
- Group 3: mechanism / method / setting wording

### Step D: Evaluate whether the topic is fully covered

Check:
- Do the results include the obvious classic papers?
- Do the results include recent frontier papers?
- Do titles and abstracts use multiple expected phrasings?
- Are important substreams missing?
- Are too many irrelevant papers entering because one term is too broad?

## 6 · Worked Examples

### Example 1: 企业ESG表现与融资约束

Topic blocks:
- Core concept: ESG performance
- Outcome: financing constraints
- Adjacent phrasing: sustainability performance, financial constraints

Suggested keyword groups:
- `ESG performance AND financing constraints`
- `sustainability performance AND financial constraints`
- `ESG AND corporate finance`

Why this works:
- The first query captures the direct expression.
- The second covers common wording variation.
- The third widens into the nearby corporate-finance conversation without fully leaving the topic.

### Example 2: 环境规制与绿色创新

Topic blocks:
- Treatment: environmental regulation
- Outcome: green innovation
- Adjacent phrasing: environmental policy, eco-innovation

Suggested keyword groups:
- `environmental regulation AND green innovation`
- `environmental policy AND green innovation`
- `environmental regulation AND eco-innovation`

Why this works:
- It covers both standard policy wording and the variant innovation terminology used by different journals.

### Example 3: 机构投资者与碳信息披露

Topic blocks:
- Actor: institutional investors
- Outcome: carbon disclosure
- Adjacent phrasing: climate disclosure, carbon reporting

Suggested keyword groups:
- `institutional investors AND carbon disclosure`
- `institutional ownership AND climate disclosure`
- `institutional investors AND carbon reporting`

## 7 · Common Failure Modes

### Failure 1: Mechanical translation

Bad keyword design often comes from translating Chinese literally rather than using established English academic expressions.

### Failure 2: One query tries to do everything

If a topic is broad, one query is rarely enough. Use multiple keyword groups and compare results.

### Failure 3: Query is too short

A single broad term like `innovation` or `governance` usually cannot represent a full topic.

### Failure 4: Query is too crowded

A long chain of terms connected by `AND` may become so narrow that obvious papers disappear.

### Failure 5: Synonyms are missing

If the literature uses several standard names, omitting them creates false gaps.

## 8 · Recommended Operating Rule

For every new literature search task:

1. Start with 1 canonical English keyword group.
2. Add 1 synonym-based keyword group.
3. Add 1 mechanism, method, or adjacent-framing group if needed.
4. Search by relevance first.
5. Review the first result pages and refine before scaling up.

If the user gives the topic in Chinese, the agent should still execute the OpenAlex search in English unless the user explicitly requests Chinese-language literature retrieval.
