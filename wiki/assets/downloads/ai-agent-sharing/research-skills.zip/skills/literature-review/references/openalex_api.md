# OpenAlex API Reference

## Contents

1. Base URL and rate limits
2. Endpoints, filters, sorting, and pagination
3. Selected fields and object schemas
4. Working-paper and SSRN queries
5. Common pitfalls

Quick reference for the OpenAlex API as used by this skill. For full docs: https://docs.openalex.org

---

## 1 · Base URL & Rate Limits

- **Base:** `https://api.openalex.org`
- **Project standard:** use the bundled `search_openalex.py` / `search_working_papers.py` scripts, which auto-load `OPENALEX_API_KEY` from the repo-root `.env`.
- **Recommended practice:** treat missing `OPENALEX_API_KEY` as an environment issue; do not use anonymous ad hoc requests as the normal workflow.
- **Rate limit:** 10 requests/second (polite pool), 1 request/second (anonymous)
- **Max URL length:** 4096 characters

---

## 2 · Key Endpoints

### Works (papers)
```
GET /works?filter=FILTERS&search=KEYWORDS&sort=SORT&per_page=N&cursor=*
```

### Sources (journals)
```
GET /sources?search=JOURNAL_NAME
GET /sources/S160506855   # by OpenAlex Source ID
```

---

## 3 · Filters for Works

Filters are comma-separated (AND logic). Use `|` for OR within a filter.

| Filter | Example | Description |
|--------|---------|-------------|
| `primary_location.source.id` | `S160506855\|S111116695` | Papers from specific journals |
| `default.search` | `corporate governance` | Keyword search (title + abstract + fulltext) |
| `title.search` | `earnings management` | Title-only search |
| `abstract.search` | `ESG disclosure` | Abstract-only search |
| `publication_year` | `2020` or `>2019` | Year filter |
| `open_access.is_oa` | `true` | Only OA papers |
| `cited_by_count` | `>50` | Minimum citations |
| `type` | `article` or `article\|preprint` | Document type (pipe-separate for OR) |
| `authorships.institutions.id` | `I1321305853\|I4210140326` | Papers by authors at given institutions |
| `primary_topic.field.id` | `fields/20` | Papers in a specific field (e.g. Economics) |
| `is_retracted` | `false` | Exclude retractions |
| `has_abstract` | `true` | Only papers with abstracts |

### Boolean Search
Use UPPERCASE `AND`, `OR`, `NOT` in search terms:
```
default.search:corporate governance AND earnings management
default.search:"ESG disclosure" OR "sustainability reporting"
default.search:innovation NOT patent
```

Quotation marks search for exact phrases (after stemming).

### Combining Multiple Source IDs
```
primary_location.source.id:https://openalex.org/S160506855|https://openalex.org/S111116695
```

Up to ~50 source IDs can be combined with `|` in a single query.

---

## 4 · Sort Options

| Sort | Description |
|------|-------------|
| `relevance_score:desc` | Most relevant first (default when search is used) |
| `cited_by_count:desc` | Most cited first |
| `publication_date:desc` | Newest first |
| `publication_date:asc` | Oldest first |

### Recommended Screening Order

OpenAlex can sort by relevance, date, and citations, but it does **not** natively sort by a custom journal quality field such as ABS Rank. Therefore this skill uses a staged screening workflow:

1. Run `relevance_score:desc` to obtain the core topic-matching paper pool.
2. Screen the returned papers against the journal's `abs_rank` stored in `journal_list.json`.
3. Run `publication_date:desc` to capture the latest studies.
4. Run `cited_by_count:desc` to add classic, highly cited papers.

In practice, `abs_rank` is a local metadata field maintained by the project, not an OpenAlex API field.

---

## 5 · Pagination

Use **cursor-based paging** (more reliable than offset paging):

```
# First request
/works?filter=...&per_page=50&cursor=*

# Subsequent requests: use meta.next_cursor from previous response
/works?filter=...&per_page=50&cursor=IlsxNjk2ODk5MjAwLCAnaHR...
```

When `meta.next_cursor` is `null`, all results have been retrieved.

Maximum `per_page`: 200.

---

## 6 · Select Fields

Use `select` to reduce response size:
```
select=id,doi,display_name,publication_year,authorships,primary_location,biblio,open_access,best_oa_location,cited_by_count,abstract_inverted_index
```

---

## 7 · Work Object — Key Fields

```json
{
  "id": "https://openalex.org/W1234567890",
  "doi": "https://doi.org/10.1234/example",
  "display_name": "Paper Title",
  "publication_year": 2023,
  "publication_date": "2023-06-15",
  "authorships": [
    {
      "author_position": "first",
      "author": {
        "id": "https://openalex.org/A1234",
        "display_name": "John Smith"
      },
      "institutions": [{"display_name": "MIT"}]
    }
  ],
  "primary_location": {
    "source": {
      "id": "https://openalex.org/S160506855",
      "display_name": "The Accounting Review"
    }
  },
  "biblio": {
    "volume": "45",
    "issue": "3",
    "first_page": "123",
    "last_page": "156"
  },
  "open_access": {
    "is_oa": true,
    "oa_status": "gold"  // gold, green, hybrid, bronze, closed
  },
  "best_oa_location": {
    "pdf_url": "https://..../paper.pdf",
    "landing_page_url": "https://..../paper"
  },
  "cited_by_count": 89,
  "abstract_inverted_index": {
    "Despite": [0],
    "growing": [1],
    "interest": [2]
  }
}
```

### Reconstructing Abstract from Inverted Index

```python
def reconstruct_abstract(inverted_index):
    if not inverted_index:
        return ""
    positions = []
    for word, pos_list in inverted_index.items():
        for pos in pos_list:
            positions.append((pos, word))
    positions.sort()
    return " ".join(w for _, w in positions)
```

---

## 8 · Source Object — Key Fields

```json
{
  "id": "https://openalex.org/S160506855",
  "display_name": "The Accounting Review",
  "issn": ["0001-4826", "1558-7967"],
  "type": "journal",
  "works_count": 12345
}
```

---

## 9 · Working Paper / SSRN Specifics

### 9.1 Source ID

| Source | OpenAlex ID | Notes |
|--------|-------------|-------|
| SSRN Electronic Journal | `S4210172589` | Repository, 1.5M+ works |

### 9.2 Institution IDs (经济学常用研究机构)

Filter key: `authorships.institutions.id` — 匹配论文中任一作者所属机构。多机构用 `|` 连接（OR 逻辑）。

> 查询未列出的机构：`GET /institutions?search=机构名`

#### 核心政策研究机构

| Institution | OpenAlex ID | Type | Country |
|-------------|-------------|------|---------|
| NBER (National Bureau of Economic Research) | `I1321305853` | nonprofit | US |
| CEPR (Centre for Economic Policy Research) | `I4210140326` | nonprofit | UK |
| IZA (Institute of Labor Economics) | `I197518295` | nonprofit | DE |
| RAND Corporation | `I1309849503` | nonprofit | US |
| Brookings Institution | `I115283149` | nonprofit | US |
| Peterson Institute for International Economics | `I149640151` | nonprofit | US |
| Resources for the Future | `I2801278523` | nonprofit | US |
| Urban Institute | `I183320395` | nonprofit | US |
| American Enterprise Institute (AEI) | `I1301666793` | nonprofit | US |
| Cato Institute | `I1313505808` | other | US |
| J-PAL (Abdul Latif Jameel Poverty Action Lab) | `I4210113636` | facility | US |

#### 国际组织

| Institution | OpenAlex ID | Type | Country |
|-------------|-------------|------|---------|
| World Bank | `I1334329717` | other | US |
| World Bank Group | `I55633929` | other | US |
| International Monetary Fund (IMF) | `I1310145890` | other | US |

#### 美联储系统

| Institution | OpenAlex ID | Works |
|-------------|-------------|-------|
| Federal Reserve (总行) | `I1317239608` | 14K+ |
| Federal Reserve Board of Governors | `I2802905149` | 14K+ |
| Federal Reserve Bank of New York | `I43638361` | 4K+ |
| Federal Reserve Bank of St. Louis | `I77793887` | 4K+ |
| Federal Reserve Bank of Philadelphia | `I57502794` | 3K+ |
| Federal Reserve Bank of Cleveland | `I4210109900` | 3K+ |
| Federal Reserve Bank of Chicago | `I77697173` | 3K+ |
| Federal Reserve Bank of San Francisco | `I19990318` | 3K+ |
| Federal Reserve Bank of Atlanta | `I119878761` | 2K+ |
| Federal Reserve Bank of Dallas | `I68415526` | 2K+ |
| Federal Reserve Bank of Richmond | `I4210158875` | 2K+ |
| Federal Reserve Bank of Boston | `I46510805` | 2K+ |
| Federal Reserve Bank of Minneapolis | `I1341575764` | 3K+ |
| Federal Reserve Bank of Kansas City | `I84318336` | 1K+ |

### 9.3 Field & Subfield IDs (经济学及交叉学科)

Filter key: `primary_topic.field.id` / `primary_topic.subfield.id`

**重要：** field/subfield/domain ID 在 filter 中使用**短格式**（如 `fields/20`），**不要**加 `https://openalex.org/` 前缀。这与 source、institution ID 需要完整 URL 不同。

#### 核心：经济学

| Field / Subfield | ID | 说明 |
|------------------|-----|------|
| Economics, Econometrics and Finance | `fields/20` | 经济、计量、金融（大类） |
| ├─ Economics and Econometrics | `subfields/2002` | 经济学与计量经济学 |
| ├─ Finance | `subfields/2003` | 金融学 |
| └─ General Economics, Econometrics and Finance | `subfields/2000` | 综合 |

#### 经管交叉：商业与会计

| Field / Subfield | ID | 说明 |
|------------------|-----|------|
| Business, Management and Accounting | `fields/14` | 商业管理会计（大类） |
| ├─ Accounting | `subfields/1402` | 会计学 |
| ├─ Business and International Management | `subfields/1403` | 企业与国际管理 |
| ├─ Management Information Systems | `subfields/1404` | 管理信息系统 |
| ├─ Management of Technology and Innovation | `subfields/1405` | 技术与创新管理 |
| ├─ Marketing | `subfields/1406` | 市场营销 |
| ├─ Organizational Behavior and HR | `subfields/1407` | 组织行为与人力资源 |
| ├─ Strategy and Management | `subfields/1408` | 战略管理 |
| └─ Industrial Relations | `subfields/1410` | 劳动关系 |

#### 社会科学

| Field / Subfield | ID | 说明 |
|------------------|-----|------|
| Social Sciences | `fields/33` | 社会科学（大类） |
| ├─ Law | `subfields/3308` | 法学 |
| ├─ Sociology and Political Science | `subfields/3312` | 社会学与政治学 |
| ├─ Political Science and International Relations | `subfields/3320` | 政治学与国际关系 |
| ├─ Public Administration | `subfields/3321` | 公共管理 |
| ├─ Education | `subfields/3304` | 教育学 |
| ├─ Development | `subfields/3303` | 发展研究 |
| ├─ Geography, Planning and Development | `subfields/3305` | 地理、规划与发展 |
| ├─ Demography | `subfields/3317` | 人口学 |
| ├─ Urban Studies | `subfields/3322` | 城市研究 |
| ├─ Health (social) | `subfields/3306` | 健康（社会科学视角） |
| ├─ Anthropology | `subfields/3314` | 人类学 |
| └─ Communication | `subfields/3315` | 传播学 |

#### 人文学科

| Field / Subfield | ID | 说明 |
|------------------|-----|------|
| Arts and Humanities | `fields/12` | 人文学科（大类） |
| ├─ History | `subfields/1202` | 历史学 |
| ├─ Philosophy | `subfields/1211` | 哲学 |
| └─ History and Philosophy of Science | `subfields/1207` | 科学史与科学哲学 |

#### 决策科学

| Field / Subfield | ID | 说明 |
|------------------|-----|------|
| Decision Sciences | `fields/18` | 决策科学（大类） |
| ├─ Statistics, Probability and Uncertainty | `subfields/1804` | 统计、概率与不确定性 |
| ├─ Management Science and Operations Research | `subfields/1803` | 管理科学与运筹学 |
| └─ Information Systems and Management | `subfields/1802` | 信息系统与管理 |

#### 数学

| Field / Subfield | ID | 说明 |
|------------------|-----|------|
| Mathematics | `fields/26` | 数学（大类） |
| ├─ Applied Mathematics | `subfields/2604` | 应用数学 |
| ├─ Statistics and Probability | `subfields/2613` | 统计与概率 |
| ├─ Computational Mathematics | `subfields/2605` | 计算数学 |
| └─ Modeling and Simulation | `subfields/2611` | 建模与模拟 |

#### 计算机科学

| Field / Subfield | ID | 说明 |
|------------------|-----|------|
| Computer Science | `fields/17` | 计算机科学（大类） |
| ├─ Artificial Intelligence | `subfields/1702` | 人工智能 |
| ├─ Computer Science Applications | `subfields/1706` | 计算机科学应用 |
| ├─ Computational Theory and Mathematics | `subfields/1703` | 计算理论 |
| ├─ Information Systems | `subfields/1710` | 信息系统 |
| └─ Human-Computer Interaction | `subfields/1709` | 人机交互 |

#### 环境科学（与环境经济学交叉）

| Field / Subfield | ID | 说明 |
|------------------|-----|------|
| Environmental Science | `fields/23` | 环境科学（大类） |
| ├─ Management, Monitoring, Policy and Law | `subfields/2308` | 环境管理、政策与法律 |
| ├─ Ecological Modeling | `subfields/2302` | 生态建模 |
| └─ Global and Planetary Change | `subfields/2306` | 全球与行星变化 |

#### 心理学（与行为经济学交叉）

| Field / Subfield | ID | 说明 |
|------------------|-----|------|
| Psychology | `fields/32` | 心理学（大类） |

#### Domain 级别（最宽泛）

| Domain | ID | 包含字段 |
|--------|-----|----------|
| Social Sciences | `domains/2` | Economics, Business, Social Sciences, Decision Sciences, Arts & Humanities, Psychology |
| Physical Sciences | `domains/3` | Mathematics, Computer Science, Engineering, Environmental Science… |

### 9.4 Filtering for SSRN Working Papers

```
# SSRN papers by NBER or CEPR affiliated authors
filter=primary_location.source.id:https://openalex.org/S4210172589,authorships.institutions.id:https://openalex.org/I1321305853|https://openalex.org/I4210140326

# SSRN papers in the Economics field
# NOTE: field IDs use the short form (fields/20), NOT the full URL
filter=primary_location.source.id:https://openalex.org/S4210172589,primary_topic.field.id:fields/20

# 跨学科示例：SSRN + Economics OR Business/Accounting
filter=primary_location.source.id:https://openalex.org/S4210172589,primary_topic.field.id:fields/20|fields/14

# 联邦储备系统所有分行的 working papers
filter=primary_location.source.id:https://openalex.org/S4210172589,authorships.institutions.id:https://openalex.org/I1317239608|https://openalex.org/I2802905149|https://openalex.org/I43638361|https://openalex.org/I77793887
```

### 9.5 SSRN-specific Caveats

- **`type` is `"preprint"`**, not `"article"`. Do not filter `type:article` when searching SSRN.
- **`abstract_inverted_index` is almost always `null`** for SSRN papers. Abstracts must be fetched separately from `https://papers.ssrn.com/sol3/papers.cfm?abstract_id=XXXX`.
- **`pdf_url` is almost always `null`**. PDFs must be downloaded from the SSRN page directly.
- **SSRN DOI format:** `10.2139/ssrn.XXXXXXX` — the number after `ssrn.` is the SSRN abstract ID.
- **`biblio` fields** (volume, issue, pages) are typically `null` for preprints.

### 9.6 Institution filter details

`authorships.institutions.id` matches any author in the paper who lists the given institution. Multiple institutions can be OR-joined with `|`. The filter uses the institution's OpenAlex ID (starts with `I`), with full URL prefix.

To find an institution's ID:
```
GET /institutions?search=National%20Bureau%20of%20Economic%20Research
```

### 9.7 Field / Topic filter details

OpenAlex organizes topics in a four-level hierarchy: domain > field > subfield > topic.

**Important:** Field, subfield, and domain IDs use the **short form** in filters (e.g. `fields/20`), **not** the full URL (`https://openalex.org/fields/20`). This differs from source and institution IDs which require the full URL.

- `primary_topic.field.id:fields/20` — papers whose primary topic is in Economics, Econometrics and Finance.
- `primary_topic.subfield.id:subfields/2002` — narrower: Economics and Econometrics only.
- `primary_topic.domain.id:domains/2` — broader: all Social Sciences.
- `topics.id:T10019` — papers tagged with a specific topic (e.g. "Corporate Finance and Governance").

如果上面的 ID 表中没有覆盖你需要的 field，可以用以下 API 查询所有可用 fields 和 subfields：
```
GET /fields?per_page=50        # 获取全部 field（约 27 个）
GET /fields/20                 # 获取某个 field 的所有 subfields
GET /subfields?per_page=200    # 获取全部 subfields
```

---

## 10 · Common Pitfalls

1. **Source IDs need full URL in filters:** Use `https://openalex.org/S160506855`, not just `S160506855`, when filtering by source.
2. **Institution IDs need full URL in filters:** Use `https://openalex.org/I1321305853`, not just `I1321305853`.
3. **Field/subfield/domain IDs use short form:** `fields/20`, `subfields/2002`, `domains/2` — do **NOT** prefix with `https://openalex.org/`。这是与 source/institution 最大的区别。
4. **Abstract is inverted index, not plaintext:** Must reconstruct. For SSRN, it is usually `null`.
5. **Not all OA papers have PDF URLs:** Check both `pdf_url` and `landing_page_url`.
6. **Cursor pagination resets if filters change:** Always start with `cursor=*` for new queries.
7. **Boolean operators must be UPPERCASE:** `AND` not `and`.
8. **URL encoding matters:** Let urllib handle encoding of filter values.
9. **SSRN preprints use `type:preprint`:** Do not hardcode `type:article` when including working papers.
10. **ID 前缀含义：** `S` = Source（期刊/仓库），`I` = Institution，`fields/` `subfields/` `domains/` = 学科层级，`T` = Topic。
