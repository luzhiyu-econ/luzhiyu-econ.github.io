#!/usr/bin/env python3
"""
SSRN Abstract Fetcher
======================
Reads workingpaper.json, fetches missing abstracts via:
  1. Semantic Scholar title search (primary, API-based, reliable)
  2. SSRN website scraping (fallback, uses requests.Session with cookie
     persistence and modern browser headers)

Updates workingpaper.json and reference.bib in place. No PDF downloads.

Usage:
    python fetch_ssrn_meta.py --input workingpaper.json --output-dir .
    python fetch_ssrn_meta.py --input workingpaper.json --output-dir . --source s2
    python fetch_ssrn_meta.py --input workingpaper.json --output-dir . --max-fetch 30 --delay 5
"""

import argparse
import json
import os
import random
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime
from difflib import SequenceMatcher
from html.parser import HTMLParser
from pathlib import Path

try:
    import requests as _requests_lib  # type: ignore[import-untyped]
    HAS_REQUESTS = True
except ImportError:
    _requests_lib = None  # type: ignore[assignment]
    HAS_REQUESTS = False


# ─── Configuration ────────────────────────────────────────────────────────────

SSRN_ABSTRACT_URL = "https://papers.ssrn.com/sol3/papers.cfm?abstract_id={ssrn_id}"
DEFAULT_DELAY = 4
S2_DELAY = 3.2
USER_AGENT = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
)
S2_API_BASE = "https://api.semanticscholar.org/graph/v1"
DEFAULT_MAX_CONSECUTIVE_FAILURES = 5


# ─── Semantic Scholar Abstract Fetcher ────────────────────────────────────────

def _title_similarity(a, b):
    """Normalized similarity between two titles (0–1)."""
    a_clean = re.sub(r"[^a-z0-9 ]", "", a.lower().strip())
    b_clean = re.sub(r"[^a-z0-9 ]", "", b.lower().strip())
    return SequenceMatcher(None, a_clean, b_clean).ratio()


def fetch_abstract_from_s2(title, year=None, delay=S2_DELAY):
    """
    Search Semantic Scholar by title. Return (abstract, s2_paper_id) or
    (None, None) if no confident match is found.

    Matching criteria:
      - Title similarity >= 0.85
      - If year is provided, must match within +-1
    """
    params = urllib.parse.urlencode({
        "query": title,
        "limit": 5,
        "fields": "title,abstract,year,externalIds",
    })
    url = f"{S2_API_BASE}/paper/search?{params}"
    headers = {"User-Agent": "LiteratureReviewSkill/2.0"}

    data = None
    max_retries = 3
    for attempt in range(max_retries):
        req = urllib.request.Request(url, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=20) as resp:
                data = json.loads(resp.read().decode("utf-8"))
            break
        except urllib.error.HTTPError as e:  # noqa: E501
            if e.code == 429:
                wait = min(30 * (attempt + 1), 90)
                print(f"    S2 rate-limited (attempt {attempt+1}/"
                      f"{max_retries}), waiting {wait}s...")
                time.sleep(wait)
                continue
            else:
                print(f"    S2 HTTP {e.code}")
                return None, None
        except Exception as e:
            print(f"    S2 error: {e}")
            return None, None

    if not data:
        print("    S2: exhausted retries (rate-limited)")
        return None, None

    results = data.get("data", [])
    if not results:
        return None, None

    for paper in results:
        s2_title = paper.get("title", "")
        sim = _title_similarity(title, s2_title)
        if sim < 0.85:
            continue
        if year and paper.get("year") and abs(paper["year"] - year) > 1:
            continue
        abstract = paper.get("abstract")
        if abstract and len(abstract.strip()) > 30:
            s2_id = paper.get("paperId", "")
            return abstract.strip(), s2_id

    return None, None


# ─── HTML Parser for SSRN Abstract Page ──────────────────────────────────────

class SSRNAbstractParser(HTMLParser):
    """Minimal HTML parser to extract abstract text from an SSRN abstract page."""

    def __init__(self):
        super().__init__()
        self.abstract = ""
        self._in_abstract_div = False
        self._abstract_depth = 0
        self._abstract_parts = []
        self._current_tag = ""
        self._current_attrs = {}

    def handle_starttag(self, tag, attrs):
        self._current_tag = tag
        attrs_dict = dict(attrs)
        self._current_attrs = attrs_dict

        if tag == "div" and self._in_abstract_div:
            self._abstract_depth += 1

        if tag == "div":
            cls = attrs_dict.get("class") or ""
            if "abstract-text" in cls or "abstractSection" in cls:
                self._in_abstract_div = True
                self._abstract_depth = 0

        if tag == "meta":
            name = attrs_dict.get("name", "")
            if name == "description" and not self.abstract:
                content = attrs_dict.get("content", "")
                if content and len(content) > 50:
                    self.abstract = content.strip()

    def handle_endtag(self, tag):
        if tag == "div" and self._in_abstract_div:
            if self._abstract_depth <= 0:
                self._in_abstract_div = False
                joined = " ".join(self._abstract_parts).strip()
                if joined and len(joined) > len(self.abstract):
                    self.abstract = joined
            else:
                self._abstract_depth -= 1

    def handle_data(self, data):
        if self._in_abstract_div:
            text = data.strip()
            if text:
                self._abstract_parts.append(text)


# ─── SSRN Fetcher (requests.Session) ─────────────────────────────────────────

def _build_ssrn_session():
    """Build a requests.Session with persistent cookies and modern headers."""
    if not HAS_REQUESTS or _requests_lib is None:
        return None
    session = _requests_lib.Session()
    session.headers.update({
        "User-Agent": USER_AGENT,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
        "Accept-Encoding": "gzip, deflate, br",
        "Connection": "keep-alive",
        "Upgrade-Insecure-Requests": "1",
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "none",
        "Sec-Fetch-User": "?1",
        "sec-ch-ua": '"Chromium";v="124", "Google Chrome";v="124", "Not-A.Brand";v="99"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"macOS"',
        "Cache-Control": "max-age=0",
        "Referer": "https://www.google.com/",
    })
    return session


def fetch_ssrn_page(ssrn_id, session=None, delay=DEFAULT_DELAY, max_retries=3):
    """
    Fetch the SSRN abstract page HTML for a given SSRN ID.
    Uses requests.Session if available, falls back to urllib.
    Returns (html_str, error_type) where error_type is None on success,
    'network' for connectivity issues, 'http_NNN' for HTTP errors.
    """
    url = SSRN_ABSTRACT_URL.format(ssrn_id=ssrn_id)

    for attempt in range(max_retries):
        try:
            if session and HAS_REQUESTS:
                resp = session.get(url, timeout=30, allow_redirects=True)
                if resp.status_code == 200:
                    return resp.text, None
                elif resp.status_code == 403:
                    wait = 2 ** (attempt + 1) + random.uniform(0, 1)
                    print(f"    HTTP 403 (attempt {attempt+1}/{max_retries}), "
                          f"retrying in {wait:.1f}s...")
                    time.sleep(wait)
                    continue
                elif resp.status_code == 429:
                    wait = 2 ** (attempt + 2) + random.uniform(0, 2)
                    print(f"    HTTP 429 rate-limited, waiting {wait:.1f}s...")
                    time.sleep(wait)
                    continue
                else:
                    print(f"    HTTP {resp.status_code} for SSRN {ssrn_id}")
                    return None, f"http_{resp.status_code}"
            else:
                headers = {
                    "User-Agent": USER_AGENT,
                    "Accept": "text/html,application/xhtml+xml",
                    "Accept-Language": "en-US,en;q=0.9",
                    "Referer": "https://www.ssrn.com/",
                }
                req = urllib.request.Request(url, headers=headers)
                with urllib.request.urlopen(req, timeout=30) as resp:
                    if resp.status != 200:
                        return None, f"http_{resp.status}"
                    return resp.read().decode("utf-8", errors="replace"), None

        except (OSError, ConnectionError) as e:
            err_str = str(e)
            if "Network is unreachable" in err_str or "Errno 101" in err_str:
                print(f"    Network unreachable for SSRN {ssrn_id}")
                return None, "network"
            if attempt < max_retries - 1:
                time.sleep(2 ** (attempt + 1))
                continue
            print(f"    Connection error for SSRN {ssrn_id}: {e}")
            return None, "network"
        except Exception as e:
            if HAS_REQUESTS and _requests_lib and isinstance(e, _requests_lib.exceptions.RequestException):
                print(f"    Request error for SSRN {ssrn_id}: {e}")
                return None, "network"
            if attempt < max_retries - 1:
                time.sleep(2 ** (attempt + 1))
                continue
            print(f"    Fetch error for SSRN {ssrn_id}: {e}")
            return None, "unknown"

    return None, "http_403"


def parse_ssrn_page(html):
    """Parse SSRN abstract page to extract abstract text."""
    parser = SSRNAbstractParser()
    parser.feed(html)

    abstract = parser.abstract
    if not abstract:
        m = re.search(
            r'<meta\s+name=["\']description["\']\s+content=["\'](.+?)["\']',
            html, re.IGNORECASE | re.DOTALL,
        )
        if m:
            text = m.group(1).strip()
            text = re.sub(r'<[^>]+>', '', text)
            text = re.sub(r'\s+', ' ', text).strip()
            if len(text) > 50:
                abstract = text

    return abstract


# ─── BibTeX Abstract Update ──────────────────────────────────────────────────

def update_bib_abstract(bib_path, openalex_id, abstract):
    """Insert abstract into an existing BibTeX entry identified by openalex ID."""
    if not os.path.exists(bib_path) or not abstract:
        return

    with open(bib_path, "r", encoding="utf-8") as f:
        content = f.read()

    abs_clean = abstract.replace("{", "").replace("}", "").replace("\n", " ")
    if len(abs_clean) > 2000:
        abs_clean = abs_clean[:2000] + "..."

    pattern = re.compile(
        r'(openalex\s*=\s*\{' + re.escape(openalex_id) + r'\})',
        re.MULTILINE,
    )
    match = pattern.search(content)
    if not match:
        return

    preceding = content[max(0, match.start() - 500):match.start()]
    if re.search(r'abstract\s*=\s*\{', preceding):
        return

    replacement = f'{match.group(1)},\n  abstract  = {{{abs_clean}}}'
    content = content[:match.start()] + replacement + content[match.end():]

    with open(bib_path, "w", encoding="utf-8") as f:
        f.write(content)


# ─── Incremental Save ────────────────────────────────────────────────────────

def save_papers(wp_path, papers):
    """Atomically save papers list to JSON."""
    tmp_path = str(wp_path) + ".tmp"
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(papers, f, ensure_ascii=False, indent=2)
    os.replace(tmp_path, str(wp_path))


# ─── Main Pipeline ────────────────────────────────────────────────────────────

def run(args):
    wp_path = Path(args.input)
    if not wp_path.exists():
        print(f"File not found: {wp_path}")
        return

    output_dir = Path(args.output_dir)
    bib_path = output_dir / "reference.bib"

    papers = json.loads(wp_path.read_text(encoding="utf-8"))
    pending = [p for p in papers
               if not p.get("ssrn_abstract_fetched") and p.get("ssrn_id")]

    if not pending:
        print("All papers already have abstracts fetched. Nothing to do.")
        return

    to_fetch = pending[:args.max_fetch]
    source = args.source
    print(f"Fetching abstracts for {len(to_fetch)} / {len(pending)} pending papers")
    print(f"  source={source}  delay={args.delay}s  "
          f"circuit_breaker={args.max_consecutive_failures}")

    papers_by_id = {p["openalex_id"]: p for p in papers}

    s2_ok = 0
    ssrn_ok = 0
    abstract_count = 0
    consecutive_ssrn_failures = 0
    ssrn_circuit_broken = False

    ssrn_session = None
    if source in ("auto", "ssrn") and HAS_REQUESTS:
        ssrn_session = _build_ssrn_session()

    for idx, paper in enumerate(to_fetch, 1):
        ssrn_id = paper["ssrn_id"]
        title = paper.get("title", "")
        year = paper.get("year")
        print(f"  [{idx}/{len(to_fetch)}] SSRN {ssrn_id}: {title[:60]}")

        rec = papers_by_id[paper["openalex_id"]]
        abstract = None
        abstract_source = None

        # ── Phase 1: Semantic Scholar ──
        if source in ("auto", "s2"):
            s2_abstract, s2_id = fetch_abstract_from_s2(title, year)
            if s2_abstract:
                abstract = s2_abstract
                abstract_source = "s2_search"
                s2_ok += 1
                print(f"    S2 abstract: {len(abstract)} chars")
            else:
                print("    S2: no match")
            time.sleep(S2_DELAY)

        # ── Phase 2: SSRN Scraping (if still needed) ──
        if not abstract and source in ("auto", "ssrn"):
            if ssrn_circuit_broken:
                print("    SSRN: skipped (circuit breaker active)")
            else:
                html, err_type = fetch_ssrn_page(
                    ssrn_id, session=ssrn_session, delay=args.delay)

                if html:
                    ssrn_abstract = parse_ssrn_page(html)
                    if ssrn_abstract:
                        abstract = ssrn_abstract
                        abstract_source = "ssrn_scrape"
                        ssrn_ok += 1
                        consecutive_ssrn_failures = 0
                        print(f"    SSRN abstract: {len(abstract)} chars")
                    else:
                        abstract_source = "ssrn_scrape_empty"
                        consecutive_ssrn_failures = 0
                        print("    SSRN: page loaded but no abstract found")
                else:
                    consecutive_ssrn_failures += 1
                    err_label = err_type or "unknown"
                    print(f"    SSRN: failed ({err_label}), "
                          f"consecutive failures: "
                          f"{consecutive_ssrn_failures}/"
                          f"{args.max_consecutive_failures}")

                    if (consecutive_ssrn_failures
                            >= args.max_consecutive_failures):
                        ssrn_circuit_broken = True
                        print(f"    ** Circuit breaker triggered: "
                              f"stopping SSRN scraping after "
                              f"{consecutive_ssrn_failures} consecutive "
                              f"failures ({err_label}). **")
                        if err_type == "network":
                            print("    ** Cause: network unreachable. "
                                  "Check firewall/proxy settings. **")
                        elif "403" in str(err_type):
                            print("    ** Cause: Cloudflare anti-bot. "
                                  "SSRN blocking automated access. **")

                jitter = args.delay + random.uniform(0, 2)
                time.sleep(jitter)

        # ── Update record ──
        if abstract:
            rec["abstract"] = abstract
            rec["abstract_source"] = abstract_source
            rec["ssrn_abstract_fetched"] = True
            abstract_count += 1
            update_bib_abstract(str(bib_path), rec["openalex_id"], abstract)
        elif abstract_source == "ssrn_scrape_empty":
            rec["ssrn_abstract_fetched"] = True
            rec["abstract_source"] = "ssrn_scrape_empty"

        # ── Incremental save ──
        save_papers(wp_path, papers)

    # ── Final summary ──
    print(f"\n{'='*60}")
    print("SSRN abstract fetch complete")
    print(f"   Source strategy:           {source}")
    print(f"   Abstracts via S2:          {s2_ok}")
    print(f"   Abstracts via SSRN scrape: {ssrn_ok}")
    print(f"   Total abstracts retrieved: {abstract_count}")
    if ssrn_circuit_broken:
        print(f"   SSRN circuit breaker:      TRIGGERED "
              f"(after {args.max_consecutive_failures} failures)")
    remaining = sum(1 for p in papers if not p.get("ssrn_abstract_fetched"))
    if remaining:
        print(f"   Still pending:             {remaining}")
    print(f"{'='*60}")


# ─── CLI ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Fetch SSRN abstracts via Semantic Scholar + SSRN scraping."
    )
    parser.add_argument("--input", "-i", required=True,
                        help="Path to workingpaper.json")
    parser.add_argument("--output-dir", "-o", type=str, default=".",
                        help="Output directory (for reference.bib)")
    parser.add_argument("--max-fetch", type=int, default=50,
                        help="Max papers to fetch in this run")
    parser.add_argument("--delay", type=float, default=DEFAULT_DELAY,
                        help="Base delay between SSRN requests (seconds)")
    parser.add_argument("--source", type=str, default="auto",
                        choices=["auto", "s2", "ssrn"],
                        help="Abstract source: auto (S2 first, SSRN fallback),"
                             " s2 (Semantic Scholar only),"
                             " ssrn (SSRN scraping only)")
    parser.add_argument("--max-consecutive-failures", type=int,
                        default=DEFAULT_MAX_CONSECUTIVE_FAILURES,
                        help="Stop SSRN scraping after this many consecutive "
                             "failures (circuit breaker)")

    args = parser.parse_args()
    run(args)


if __name__ == "__main__":
    main()
