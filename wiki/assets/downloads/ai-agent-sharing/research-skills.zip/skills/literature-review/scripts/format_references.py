#!/usr/bin/env python3
"""
BibTeX to Reference List Converter
====================================
Converts reference.bib to a formatted reference list (Markdown or plain text)
suitable for appending to a Chinese literature review.

Usage:
    python format_references.py reference.bib --output references.md
    python format_references.py reference.bib --output references.md --style chinese
"""

import argparse
import re
import sys
from pathlib import Path


def parse_bib_file(bib_path):
    """Parse a BibTeX file into a list of entry dicts."""
    with open(bib_path, "r", encoding="utf-8") as f:
        content = f.read()
    
    entries = []
    # Match each @article{...} block
    pattern = r'@article\{([^,]+),\s*(.*?)\n\}'
    for match in re.finditer(pattern, content, re.DOTALL):
        key = match.group(1).strip()
        body = match.group(2)
        
        entry = {"key": key}
        # Extract fields
        for field_match in re.finditer(
            r'(\w+)\s*=\s*\{((?:[^{}]|\{[^{}]*\})*)\}', body
        ):
            field_name = field_match.group(1).strip().lower()
            field_value = field_match.group(2).strip()
            # Unescape BibTeX
            field_value = field_value.replace(r"\&", "&").replace(r"\%", "%")
            field_value = field_value.replace(r"\_", "_").replace(r"\#", "#")
            entry[field_name] = field_value
        
        entries.append(entry)
    
    return entries


def format_apa_english(entry):
    """Format an entry in APA-like English style."""
    authors = entry.get("author", "Unknown")
    year = entry.get("year", "n.d.")
    title = entry.get("title", "Untitled")
    journal = entry.get("journal", "")
    volume = entry.get("volume", "")
    number = entry.get("number", "")
    pages = entry.get("pages", "")
    doi = entry.get("doi", "")
    
    # Format author list: keep as-is from BibTeX "Last, First and Last, First"
    # Convert to "Last, F., Last, F., and Last, F."
    author_parts = [a.strip() for a in authors.split(" and ")]
    formatted_authors = []
    for a in author_parts:
        if "," in a:
            last, first = a.split(",", 1)
            initials = "".join(w[0] + "." for w in first.strip().split() if w)
            formatted_authors.append(f"{last.strip()}, {initials}")
        else:
            formatted_authors.append(a)
    
    if len(formatted_authors) > 2:
        author_str = ", ".join(formatted_authors[:-1]) + ", and " + formatted_authors[-1]
    elif len(formatted_authors) == 2:
        author_str = " and ".join(formatted_authors)
    else:
        author_str = formatted_authors[0] if formatted_authors else "Unknown"
    
    ref = f"{author_str}. {year}. {title}."
    if journal:
        ref += f" *{journal}*"
        if volume:
            ref += f", {volume}"
            if number:
                ref += f"({number})"
        if pages:
            ref += f": {pages}"
        ref += "."
    if doi:
        ref += f" https://doi.org/{doi}"
    
    return ref


def format_chinese_style(entry):
    """Format an entry in Chinese academic journal style."""
    authors = entry.get("author", "Unknown")
    year = entry.get("year", "n.d.")
    title = entry.get("title", "Untitled")
    journal = entry.get("journal", "")
    volume = entry.get("volume", "")
    number = entry.get("number", "")
    pages = entry.get("pages", "")
    doi = entry.get("doi", "")
    
    # Simplified author format
    author_parts = [a.strip() for a in authors.split(" and ")]
    if len(author_parts) > 3:
        author_str = ", ".join(author_parts[:3]) + ", et al."
    else:
        author_str = ", ".join(author_parts)
    
    ref = f"{author_str}, {year}, \"{title}\""
    if journal:
        ref += f", *{journal}*"
        if volume:
            ref += f", Vol.{volume}"
            if number:
                ref += f"({number})"
        if pages:
            ref += f", pp.{pages}"
    ref += "."
    if doi:
        ref += f" DOI: {doi}"
    
    return ref


def generate_reference_list(entries, style="english"):
    """Generate a formatted reference list."""
    formatter = format_apa_english if style == "english" else format_chinese_style
    
    # Sort by first author's last name, then year
    def sort_key(e):
        author = e.get("author", "ZZZ")
        first = author.split(" and ")[0].split(",")[0].strip().lower()
        year = e.get("year", "0000")
        return (first, year)
    
    entries.sort(key=sort_key)
    
    lines = ["## 参考文献\n"] if style == "chinese" else ["## References\n"]
    for i, entry in enumerate(entries, 1):
        ref = formatter(entry)
        lines.append(f"[{i}] {ref}\n")
    
    return "\n".join(lines)


def generate_stats(entries):
    """Generate summary statistics about the reference collection."""
    years = [int(e["year"]) for e in entries if e.get("year", "").isdigit()]
    journals = {}
    for e in entries:
        j = e.get("journal", "Unknown")
        journals[j] = journals.get(j, 0) + 1
    
    lines = ["## 参考文献统计\n"]
    lines.append(f"- **总文献数量：** {len(entries)}")
    if years:
        lines.append(f"- **年份范围：** {min(years)}-{max(years)}")
        recent = sum(1 for y in years if y >= max(years) - 5)
        lines.append(f"- **近5年文献：** {recent} ({100*recent//len(years)}%)")
    lines.append(f"- **期刊分布：**")
    for j, count in sorted(journals.items(), key=lambda x: -x[1])[:15]:
        lines.append(f"  - {j}: {count}")
    
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="BibTeX to Reference List Converter")
    parser.add_argument("bib_file", type=str, help="Path to reference.bib")
    parser.add_argument("--output", "-o", type=str, default=None, help="Output file path")
    parser.add_argument("--style", type=str, default="english",
                        choices=["english", "chinese"], help="Citation style")
    parser.add_argument("--stats", action="store_true", help="Include statistics")
    
    args = parser.parse_args()
    
    entries = parse_bib_file(args.bib_file)
    print(f"Parsed {len(entries)} entries from {args.bib_file}")
    
    output_parts = []
    if args.stats:
        output_parts.append(generate_stats(entries))
        output_parts.append("")
    
    output_parts.append(generate_reference_list(entries, args.style))
    
    result = "\n".join(output_parts)
    
    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(result)
        print(f"Written to {args.output}")
    else:
        print(result)


if __name__ == "__main__":
    main()
