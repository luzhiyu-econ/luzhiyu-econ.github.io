#!/usr/bin/env python3
"""
search_chinese_lit.py — 检索本地 ncpssd SQLite 数据库中的中文文献

用法示例：
  python search_chinese_lit.py --keywords "融资约束 企业投资" --output-dir 01_literature/articles/financing-constraints
  python search_chinese_lit.py --keywords "环境规制" --journal-list assets/chinese_journal_list.json --min-year 2022
"""

import argparse
import json
import os
import re
import sqlite3
import sys
from datetime import datetime
from pathlib import Path


DEFAULT_DB = os.path.expanduser("~/Developer/05_Literature/ncpssd_2020_2026.db")
DEFAULT_JOURNAL_LIST = os.path.join(
    os.path.dirname(__file__), "../assets/chinese_journal_list.json"
)


# ─────────────────────────────────────────────
# 数据库搜索
# ─────────────────────────────────────────────

def build_query(keywords: list[str], journals: list[str] | None,
                min_year: int, max_year: int, logic: str, max_results: int) -> tuple[str, list]:
    """构造 SQL 查询语句。"""
    op = " AND " if logic == "AND" else " OR "

    # 每个关键词匹配 title / abstract / keywords（中英文）
    kw_clauses = []
    params = []
    for kw in keywords:
        pattern = f"%{kw}%"
        kw_clauses.append(
            "(title LIKE ? OR abstract LIKE ? OR keywords LIKE ? "
            " OR title_en LIKE ? OR abstract_en LIKE ? OR keywords_en LIKE ?)"
        )
        params.extend([pattern] * 6)

    where = f"({op.join(kw_clauses)})"
    where += " AND year >= ? AND year <= ?"
    params += [min_year, max_year]

    if journals:
        placeholders = ",".join("?" * len(journals))
        where += f" AND journal_name IN ({placeholders})"
        params += journals

    sql = f"""
        SELECT id, title, authors, year, journal_name, volume, issue, pages,
               abstract, keywords, article_url, title_en, authors_en, abstract_en, keywords_en
        FROM articles
        WHERE {where}
        ORDER BY year DESC, id ASC
        LIMIT ?
    """
    params.append(max_results)
    return sql, params


def search_db(db_path: str, keywords: list[str], journals: list[str] | None,
              min_year: int, max_year: int, logic: str, max_results: int) -> list[dict]:
    """执行数据库搜索，返回结果列表。"""
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()

    sql, params = build_query(keywords, journals, min_year, max_year, logic, max_results)
    cur.execute(sql, params)
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows


# ─────────────────────────────────────────────
# BibTeX 生成（中文名称）
# ─────────────────────────────────────────────

def make_bibtex_key(authors: str, year: int, keywords: str) -> str:
    """生成 BibTeX key：cn_第一作者姓_年份_首关键词。"""
    first_author = ""
    if authors:
        # 作者格式：姓名[机构];姓名[机构] 或 姓名;姓名
        first = re.split(r"[;，,]", authors)[0].strip()
        # 去掉方括号内的机构信息
        first = re.sub(r"\[.*?\]", "", first).strip()
        # 取姓（第一个字）
        first_author = first[0] if first else "佚"

    # 首个关键词（去掉空格和特殊字符，取前4字）
    kw_slug = ""
    if keywords:
        kw_first = re.split(r"[；;，, ]", keywords)[0].strip()
        kw_slug = re.sub(r"[^\w\u4e00-\u9fff]", "", kw_first)[:4]

    key = f"cn_{first_author}{year}"
    if kw_slug:
        key += f"_{kw_slug}"
    return key


def row_to_bibtex(row: dict, existing_keys: set[str]) -> str:
    """将数据库行转为 BibTeX @article 条目（中文作者名）。"""
    raw_key = make_bibtex_key(row.get("authors", ""), row.get("year", 0), row.get("keywords", ""))

    # 处理 key 冲突（追加 a/b/c）
    key = raw_key
    suffix = ord("a")
    while key in existing_keys:
        key = f"{raw_key}{chr(suffix)}"
        suffix += 1
    existing_keys.add(key)

    # 作者格式：去掉机构标注，过滤纯英文名，用 " and " 连接
    authors_raw = row.get("authors") or ""
    authors_clean = re.sub(r"\[[\d,]+\]", "", authors_raw)
    # 按分号拆分，只保留含中文字符的部分
    parts = [p.strip() for p in re.split(r"\s*;\s*", authors_clean) if p.strip()]
    cn_parts = [p for p in parts if re.search(r"[\u4e00-\u9fff]", p)]
    authors_clean = " and ".join(cn_parts) if cn_parts else " and ".join(parts)

    title = (row.get("title") or "").replace("{", "\\{").replace("}", "\\}")
    journal = row.get("journal_name") or ""
    year = row.get("year") or ""
    volume = row.get("volume") or ""
    issue = row.get("issue") or ""
    pages = row.get("pages") or ""
    abstract = (row.get("abstract") or "").replace("\n", " ").strip()
    keywords = row.get("keywords") or ""
    url = row.get("article_url") or ""

    lines = [f"@article{{{key},"]
    lines.append(f"  author  = {{{authors_clean}}},")
    lines.append(f"  title   = {{{title}}},")
    lines.append(f"  journal = {{{journal}}},")
    lines.append(f"  year    = {{{year}}},")
    if volume:
        lines.append(f"  volume  = {{{volume}}},")
    if issue:
        lines.append(f"  number  = {{{issue}}},")
    if pages:
        lines.append(f"  pages   = {{{pages}}},")
    if abstract:
        lines.append(f"  abstract = {{{abstract}}},")
    if keywords:
        lines.append(f"  keywords = {{{keywords}}},")
    if url:
        lines.append(f"  url     = {{{url}}},")
    lines.append("}")
    return "\n".join(lines)


# ─────────────────────────────────────────────
# 输出文件处理
# ─────────────────────────────────────────────

def load_existing_bib_keys(bib_path: Path) -> set[str]:
    """从已有 .bib 文件中读取所有 key，避免重复。"""
    keys = set()
    if bib_path.exists():
        text = bib_path.read_text(encoding="utf-8")
        for m in re.finditer(r"@\w+\{([^,]+),", text):
            keys.add(m.group(1).strip())
    return keys


def load_existing_chinese_ids(json_path: Path) -> set[str]:
    """从已有 chinese_papers.json 中读取 article_url，避免重复写入。"""
    if not json_path.exists():
        return set()
    try:
        data = json.loads(json_path.read_text(encoding="utf-8"))
        return {r.get("article_url", "") for r in data if r.get("article_url")}
    except Exception:
        return set()


def append_to_bib(bib_path: Path, entries: list[str]) -> None:
    """追加 BibTeX 条目到 reference.bib。"""
    with bib_path.open("a", encoding="utf-8") as f:
        for entry in entries:
            f.write("\n" + entry + "\n")


def append_to_chinese_json(json_path: Path, rows: list[dict]) -> None:
    """追加记录到 chinese_papers.json（中文文献专用存储）。"""
    existing = []
    if json_path.exists():
        try:
            existing = json.loads(json_path.read_text(encoding="utf-8"))
        except Exception:
            pass
    existing.extend(rows)
    json_path.write_text(
        json.dumps(existing, ensure_ascii=False, indent=2), encoding="utf-8"
    )


def append_to_search_log(log_path: Path, keywords: list[str], logic: str,
                          journals: list[str] | None, min_year: int, max_year: int,
                          total_found: int, new_added: int) -> None:
    """追加一条检索记录到 search_log.md。"""
    ts = datetime.now().strftime("%Y-%m-%d %H:%M")
    journal_str = "（期刊白名单）" if journals else "（全部期刊）"
    kw_str = f" {logic} ".join(keywords)

    entry = (
        f"\n## 中文文献检索 {ts}\n\n"
        f"- **来源**: ncpssd 本地数据库\n"
        f"- **关键词**: {kw_str}\n"
        f"- **逻辑**: {logic}\n"
        f"- **年份范围**: {min_year}–{max_year}\n"
        f"- **期刊过滤**: {journal_str}\n"
        f"- **命中总数**: {total_found}\n"
        f"- **新增条目**: {new_added}\n"
    )
    with log_path.open("a", encoding="utf-8") as f:
        f.write(entry)


# ─────────────────────────────────────────────
# 主流程
# ─────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="检索本地 ncpssd 数据库中的中文文献"
    )
    parser.add_argument("--keywords", required=True, nargs="+",
                        help="中文或英文关键词（多个词之间默认 AND）")
    parser.add_argument("--db", default=DEFAULT_DB,
                        help=f"数据库路径（默认 {DEFAULT_DB}）")
    parser.add_argument("--output-dir", required=True,
                        help="输出目录，如 01_literature/articles/esg-financing")
    parser.add_argument("--journal-list", default=None,
                        help="中文期刊白名单 JSON 路径（可选）")
    parser.add_argument("--min-year", type=int, default=2020)
    parser.add_argument("--max-year", type=int, default=2026)
    parser.add_argument("--logic", choices=["AND", "OR"], default="AND",
                        help="多关键词逻辑（默认 AND）")
    parser.add_argument("--max-results", type=int, default=100)
    args = parser.parse_args()

    # 解析期刊白名单
    journals = None
    journal_list_path = args.journal_list or DEFAULT_JOURNAL_LIST
    if args.journal_list or os.path.exists(journal_list_path):
        try:
            jdata = json.loads(Path(journal_list_path).read_text(encoding="utf-8"))
            journals = [j["title"] for j in jdata]
        except Exception as e:
            print(f"[警告] 无法加载期刊白名单：{e}，将检索全部期刊", file=sys.stderr)

    # 准备输出目录
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    bib_path = out_dir / "reference.bib"
    json_path = out_dir / "chinese_papers.json"
    log_path = out_dir / "search_log.md"

    # 加载已有数据（去重用）
    existing_bib_keys = load_existing_bib_keys(bib_path)
    existing_urls = load_existing_chinese_ids(json_path)

    # 搜索
    print(f"[搜索] 关键词: {' AND '.join(args.keywords)}")
    print(f"[搜索] 年份: {args.min_year}–{args.max_year}, 最大条数: {args.max_results}")
    if journals:
        print(f"[搜索] 期刊白名单: {len(journals)} 本")

    rows = search_db(
        args.db, args.keywords, journals,
        args.min_year, args.max_year, args.logic, args.max_results
    )
    print(f"[结果] 共命中 {len(rows)} 条")

    # 过滤已存在条目
    new_rows = [r for r in rows if r.get("article_url") not in existing_urls]
    print(f"[结果] 新增条目 {len(new_rows)} 条（去重后）")

    if not new_rows:
        print("[完成] 无新条目，跳过写入")
        append_to_search_log(log_path, args.keywords, args.logic, journals,
                              args.min_year, args.max_year, len(rows), 0)
        return

    # 生成 BibTeX 并写入
    bib_entries = []
    for row in new_rows:
        entry = row_to_bibtex(row, existing_bib_keys)
        bib_entries.append(entry)

    append_to_bib(bib_path, bib_entries)
    append_to_chinese_json(json_path, new_rows)
    append_to_search_log(log_path, args.keywords, args.logic, journals,
                          args.min_year, args.max_year, len(rows), len(new_rows))

    print(f"[写入] reference.bib   ← {len(bib_entries)} 条")
    print(f"[写入] chinese_papers.json ← {len(new_rows)} 条")
    print(f"[写入] search_log.md   ← 检索记录已追加")


if __name__ == "__main__":
    main()
