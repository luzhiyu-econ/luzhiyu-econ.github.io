#!/usr/bin/env python3
"""
Literature Review — OpenAlex Search & Reference Manager
=========================================================
Searches OpenAlex for papers in specified journals, manages BibTeX references,
and maintains a search log. Abstracts are retrieved from OpenAlex metadata;
no PDF downloads are performed.

Keyword policy:
    - OpenAlex retrieval is primarily for English-language literature discovery.
    - If the research topic is provided in Chinese, convert it to English
      academic keyword groups before searching.
    - A good query usually captures a full topic through 1-3 keyword groups
      covering the core concept, close synonyms, and adjacent framing.

Usage:
    python search_openalex.py --keywords "KEYWORDS" --journal-list journal_list.json --output-dir .
    python search_openalex.py --find-journal "Journal of Finance"
"""

import argparse
import json
import os
import re
import time
import urllib.parse
import urllib.request
from datetime import datetime
from pathlib import Path

# ─── Configuration ────────────────────────────────────────────────────────────


def load_repo_env():
    """Load repo-root .env without overwriting existing environment variables."""
    env_path = Path(__file__).resolve().parents[4] / ".env"
    if not env_path.exists():
        return
    for raw_line in env_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip("'\"")
        if key:
            os.environ.setdefault(key, value)


load_repo_env()

OPENALEX_API = "https://api.openalex.org"
POLITE_EMAIL = os.getenv("OPENALEX_EMAIL", "").strip()
OPENALEX_API_KEY = os.getenv("OPENALEX_API_KEY", "").strip()
PER_PAGE_DEFAULT = 50
MAX_RESULTS_DEFAULT = 200
BATCH_SIZE = 50  # Max source IDs per query (OpenAlex limit)
REQUEST_DELAY = 0.15  # Seconds between API calls (respect rate limits)


# ─── Abstract Reconstruction ─────────────────────────────────────────────────


def reconstruct_abstract(inverted_index):
    """Convert OpenAlex inverted index to plaintext abstract."""
    if not inverted_index:
        return ""
    word_positions = []
    for word, positions in inverted_index.items():
        for pos in positions:
            word_positions.append((pos, word))
    word_positions.sort(key=lambda x: x[0])
    return " ".join(w for _, w in word_positions)


def normalize_openalex_id(value):
    """Normalize an OpenAlex URL or short ID to the short ID form."""
    if not value:
        return ""
    return str(value).replace("https://openalex.org/", "").strip()


def build_journal_metadata(journals):
    """Build a lookup of source ID to journal metadata."""
    metadata = {}
    for journal in journals:
        source_id = normalize_openalex_id(journal.get("openalex_id"))
        if source_id:
            metadata[source_id] = journal
    return metadata


def contains_cjk(text):
    """Return True when the text contains CJK Unified Ideographs."""
    if not text:
        return False
    return bool(re.search(r"[\u4e00-\u9fff]", text))


def resolve_openalex_auth(email=None, api_key=None):
    """Resolve the effective OpenAlex auth settings for this request."""
    contact_email = (email if email is not None else POLITE_EMAIL).strip()
    effective_api_key = (api_key if api_key is not None else OPENALEX_API_KEY).strip()
    return contact_email, effective_api_key


def build_user_agent(contact_email=""):
    """Build a stable User-Agent header without exposing a hardcoded mailbox."""
    base = "LiteratureReviewSkill/1.0"
    return f"{base} (contact:{contact_email})" if contact_email else base


def describe_openalex_auth(email=None, api_key=None):
    """Return a human-readable auth mode and whether it is a fallback path."""
    contact_email, effective_api_key = resolve_openalex_auth(email, api_key)
    if effective_api_key:
        return "api_key (.env or --api-key)", False
    if contact_email:
        return "fallback without api_key (contact email only)", True
    return "fallback without api_key (anonymous compatibility mode)", True


# ─── API Helpers ──────────────────────────────────────────────────────────────


def api_get(endpoint, params=None, email=None, api_key=None):
    """Make a GET request to the OpenAlex API with repo auth defaults."""
    url = f"{OPENALEX_API}/{endpoint}"
    request_params = dict(params or {})
    contact_email, effective_api_key = resolve_openalex_auth(email, api_key)
    if contact_email:
        request_params.setdefault("mailto", contact_email)
    if effective_api_key:
        request_params.setdefault("api_key", effective_api_key)
    if request_params:
        url += "?" + urllib.parse.urlencode(request_params, safe=":,|/")

    headers = {"User-Agent": build_user_agent(contact_email)}
    req = urllib.request.Request(url, headers=headers)

    max_retries = 3
    for attempt in range(max_retries):
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            if e.code == 429:  # Rate limited
                wait = 2 ** (attempt + 1)
                print(f"  ⏳ Rate limited, waiting {wait}s...")
                time.sleep(wait)
            elif e.code == 403:
                print(f"  ⚠️  403 Forbidden for URL: {url}")
                return None
            else:
                raise
        except Exception as e:
            if attempt < max_retries - 1:
                time.sleep(1)
            else:
                print(f"  ❌ API error after {max_retries} retries: {e}")
                return None
    return None


def find_journal(name, email=None, api_key=None):
    """Search for a journal's OpenAlex source ID."""
    data = api_get("sources", {"search": name, "per_page": 5}, email, api_key)
    if not data or "results" not in data:
        print(f"No results for '{name}'")
        return

    print(f"\nSearch results for '{name}':")
    print("-" * 80)
    for i, src in enumerate(data["results"], 1):
        oa_id = src.get("id", "").replace("https://openalex.org/", "")
        print(f"  {i}. {src.get('display_name', 'Unknown')}")
        print(f"     OpenAlex ID: {oa_id}")
        print(f"     ISSN: {src.get('issn', ['N/A'])}")
        print(f"     Type: {src.get('type', 'N/A')}")
        print(f"     Works count: {src.get('works_count', 'N/A')}")
        print()


# ─── BibTeX Management ───────────────────────────────────────────────────────


def load_existing_openalex_ids(bib_path):
    """Extract all OpenAlex IDs from an existing .bib file."""
    ids = set()
    if not os.path.exists(bib_path):
        return ids
    with open(bib_path, encoding="utf-8") as f:
        content = f.read()
    for match in re.finditer(r"openalex\s*=\s*\{([^}]+)\}", content):
        ids.add(match.group(1).strip())
    return ids


def make_cite_key(work):
    """Generate a citation key like 'Smith2023_W1234567890'."""
    authors = work.get("authorships", [])
    if authors and authors[0].get("author", {}).get("display_name"):
        last_name = authors[0]["author"]["display_name"].split()[-1]
        # Clean non-ASCII for key safety
        last_name = re.sub(r"[^a-zA-Z]", "", last_name) or "Unknown"
    else:
        last_name = "Unknown"
    year = work.get("publication_year", "XXXX")
    oa_id = work.get("id", "").replace("https://openalex.org/", "")
    return f"{last_name}{year}_{oa_id}"


def format_authors_bibtex(work):
    """Format author list for BibTeX."""
    authors = work.get("authorships", [])
    parts = []
    for a in authors[:20]:  # Limit to 20 authors
        name = a.get("author", {}).get("display_name", "")
        if not name:
            continue
        tokens = name.split()
        if len(tokens) >= 2:
            parts.append(f"{tokens[-1]}, {' '.join(tokens[:-1])}")
        else:
            parts.append(name)
    return " and ".join(parts)


def escape_bibtex(text):
    """Escape special LaTeX/BibTeX characters."""
    if not text:
        return ""
    replacements = [("&", r"\&"), ("%", r"\%"), ("_", r"\_"), ("#", r"\#")]
    for old, new in replacements:
        text = text.replace(old, new)
    return text


def work_to_bibtex(work, abstract_text=""):
    """Convert an OpenAlex work object to a BibTeX entry string."""
    key = make_cite_key(work)
    authors = format_authors_bibtex(work)
    title = work.get("display_name", "Untitled")
    year = work.get("publication_year", "")
    doi = (work.get("doi") or "").replace("https://doi.org/", "")
    oa_id = work.get("id", "").replace("https://openalex.org/", "")

    # Journal info
    primary = work.get("primary_location", {}) or {}
    source = primary.get("source", {}) or {}
    journal = source.get("display_name", "")

    biblio = work.get("biblio", {}) or {}
    volume = biblio.get("volume", "")
    issue = biblio.get("issue", "")
    first_page = biblio.get("first_page", "")
    last_page = biblio.get("last_page", "")
    pages = (
        f"{first_page}--{last_page}" if first_page and last_page else first_page or ""
    )

    lines = [f"@article{{{key},"]
    lines.append(f"  title     = {{{escape_bibtex(title)}}},")
    lines.append(f"  author    = {{{authors}}},")
    if journal:
        lines.append(f"  journal   = {{{escape_bibtex(journal)}}},")
    lines.append(f"  year      = {{{year}}},")
    if volume:
        lines.append(f"  volume    = {{{volume}}},")
    if issue:
        lines.append(f"  number    = {{{issue}}},")
    if pages:
        lines.append(f"  pages     = {{{pages}}},")
    if doi:
        lines.append(f"  doi       = {{{doi}}},")
    lines.append(f"  openalex  = {{{oa_id}}},")
    if abstract_text:
        # Truncate very long abstracts for BibTeX
        abs_clean = abstract_text.replace("{", "").replace("}", "").replace("\n", " ")
        if len(abs_clean) > 2000:
            abs_clean = abs_clean[:2000] + "..."
        lines.append(f"  abstract  = {{{abs_clean}}}")
    lines.append("}")
    return "\n".join(lines)


# ─── Search & Collect ─────────────────────────────────────────────────────────


def search_works(
    keywords,
    source_ids,
    min_year=None,
    max_results=200,
    per_page=50,
    sort="relevance_score:desc",
    email=None,
    work_type="article",
    api_key=None,
):
    """
    Search OpenAlex for works matching keywords in specified sources.
    Returns a list of work objects.

    work_type: comma-separated types, e.g. "article" or "article,preprint".
    """
    all_works = []

    # Batch source IDs (OpenAlex supports pipe-separated IDs)
    batches = [
        source_ids[i : i + BATCH_SIZE] for i in range(0, len(source_ids), BATCH_SIZE)
    ]

    for batch_idx, batch in enumerate(batches):
        if len(all_works) >= max_results:
            break

        source_filter = "|".join(
            f"https://openalex.org/{sid}" if not sid.startswith("http") else sid
            for sid in batch
        )

        # Build filter string
        filters = [f"primary_location.source.id:{source_filter}"]
        filters.append(f"default.search:{keywords}")
        if min_year:
            filters.append(f"publication_year:>{min_year - 1}")
        if work_type:
            if "," in work_type:
                filters.append(f"type:{work_type.replace(',', '|')}")
            else:
                filters.append(f"type:{work_type}")

        filter_str = ",".join(filters)

        cursor = "*"
        batch_works = []
        page_num = 0

        while (
            cursor
            and len(batch_works) < max_results
            and len(all_works) + len(batch_works) < max_results
        ):
            remaining = max_results - len(all_works) - len(batch_works)
            params = {
                "filter": filter_str,
                "per_page": min(per_page, remaining),
                "cursor": cursor,
                "sort": sort,
                "select": "id,doi,display_name,publication_year,publication_date,"
                "authorships,primary_location,biblio,open_access,"
                "best_oa_location,cited_by_count,abstract_inverted_index,"
                "language,type,is_retracted",
            }

            data = api_get("works", params, email, api_key)
            if not data or "results" not in data:
                break

            results = data["results"]
            if not results:
                break

            batch_works.extend(results[:remaining])
            page_num += 1

            # Get next cursor
            meta = data.get("meta", {})
            cursor = meta.get("next_cursor")

            total = meta.get("count", "?")
            print(
                f"  📄 Batch {batch_idx + 1}/{len(batches)}, "
                f"page {page_num}: fetched {len(results)} "
                f"(total available: {total})"
            )

            time.sleep(REQUEST_DELAY)

        all_works.extend(batch_works)

    return all_works


# ─── Output Writers ───────────────────────────────────────────────────────────


def append_to_bib(bib_path, entries_text):
    """Append BibTeX entries to the .bib file."""
    with open(bib_path, "a", encoding="utf-8") as f:
        f.write("\n" + entries_text + "\n")


def write_search_log_entry(
    log_path, keywords, works, new_count, dup_count, journal_metadata
):
    """Append a search round entry to search_log.md."""
    now = datetime.now().strftime("%Y-%m-%d %H:%M")

    with open(log_path, "a", encoding="utf-8") as f:
        f.write(f'\n## Search: "{keywords}"\n')
        f.write(
            f"**Date:** {now} | **Results:** {len(works)} | "
            f"**New:** {new_count} | **Duplicates skipped:** {dup_count}\n\n"
        )

        for i, (work, abstract) in enumerate(works, 1):
            # Author string
            authors = work.get("authorships", [])
            if authors:
                first_author = (
                    authors[0].get("author", {}).get("display_name", "Unknown")
                )
                if len(authors) > 1:
                    author_str = f"{first_author} et al."
                else:
                    author_str = first_author
            else:
                author_str = "Unknown"

            year = work.get("publication_year", "N/A")
            title = work.get("display_name", "Untitled")

            primary = work.get("primary_location", {}) or {}
            source = primary.get("source", {}) or {}
            journal = source.get("display_name", "N/A")
            source_id = normalize_openalex_id(source.get("id", ""))
            abs_rank = journal_metadata.get(source_id, {}).get("abs_rank", "N/A")

            doi = work.get("doi", "N/A")
            citations = work.get("cited_by_count", 0)

            oa_info = work.get("open_access", {}) or {}
            is_oa = oa_info.get("is_oa", False)
            oa_status = oa_info.get("oa_status", "closed")
            oa_label = f"Yes ({oa_status.title()})" if is_oa else "No"

            oa_id = work.get("id", "").replace("https://openalex.org/", "")

            f.write(f'### [{i}] {author_str} ({year}) — "{title}"\n')
            f.write(
                f"- **Journal:** {journal} | **Year:** {year} | "
                f"**ABS Rank:** {abs_rank} | **Citations:** {citations}\n"
            )
            f.write(f"- **DOI:** {doi} | **OA:** {oa_label}\n")
            f.write(f"- **OpenAlex:** {oa_id}\n")
            if abstract:
                f.write(f"- **Abstract:** {abstract}\n")
            f.write("\n")


# ─── Main Pipeline ────────────────────────────────────────────────────────────


def run_search(args):
    """Execute the full search pipeline."""
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    bib_path = output_dir / "reference.bib"
    log_path = output_dir / "search_log.md"

    # Initialize search_log.md header if new
    if not log_path.exists():
        with open(log_path, "w", encoding="utf-8") as f:
            f.write("# Literature Search Log\n\n")
            f.write(
                f"_Project initialized: {datetime.now().strftime('%Y-%m-%d %H:%M')}_\n"
            )

    # Initialize reference.bib if new
    if not bib_path.exists():
        with open(bib_path, "w", encoding="utf-8") as f:
            f.write("% Literature Review BibTeX References\n")
            f.write("% Generated by literature-review skill\n")
            f.write(f"% Created: {datetime.now().strftime('%Y-%m-%d')}\n\n")

    # Load journal list
    with open(args.journal_list, encoding="utf-8") as f:
        journals = json.load(f)
    journal_metadata = build_journal_metadata(journals)

    source_ids = [j["openalex_id"] for j in journals if j.get("openalex_id")]
    print(f'Searching {len(source_ids)} journals for: "{args.keywords}"')
    print(
        f"   Min year: {args.min_year or 'None'} | Sort: {args.sort} | Max results: {args.max_results}"
    )
    auth_label, is_fallback = describe_openalex_auth(args.email, args.api_key)
    print(f"   OpenAlex auth: {auth_label}")
    if is_fallback:
        print(
            "   WARNING: OPENALEX_API_KEY is missing; using a compatibility fallback instead of the standard key-based path."
        )
    if contains_cjk(args.keywords):
        print("   Detected Chinese characters in --keywords.")
        print(
            "      OpenAlex mainly works best for English-language literature discovery."
        )
        print(
            "      Convert the topic into English academic keyword groups before treating this as the main query."
        )

    # Load existing IDs for dedup
    existing_ids = load_existing_openalex_ids(bib_path)
    print(f"   Existing references in bib: {len(existing_ids)}")

    # Search
    works = search_works(
        keywords=args.keywords,
        source_ids=source_ids,
        min_year=args.min_year,
        max_results=args.max_results,
        per_page=args.per_page,
        sort=args.sort,
        email=args.email,
        work_type=args.type,
        api_key=args.api_key,
    )

    print(f"\nFound {len(works)} results. Processing...")

    # Process results
    new_bibtex_entries = []
    log_works = []  # (work, abstract)
    new_count = 0
    dup_count = 0

    for work in works:
        oa_id = work.get("id", "").replace("https://openalex.org/", "")

        # Skip retracted
        if work.get("is_retracted", False):
            continue

        # Reconstruct abstract
        abstract = reconstruct_abstract(work.get("abstract_inverted_index"))

        # Dedup check
        if oa_id in existing_ids:
            dup_count += 1
            continue

        existing_ids.add(oa_id)
        new_count += 1

        # Generate BibTeX
        bib_entry = work_to_bibtex(work, abstract)
        new_bibtex_entries.append(bib_entry)
        log_works.append((work, abstract))

    # Write outputs
    if new_bibtex_entries:
        append_to_bib(bib_path, "\n\n".join(new_bibtex_entries))

    write_search_log_entry(
        log_path, args.keywords, log_works, new_count, dup_count, journal_metadata
    )

    # Summary
    print(f"\n{'=' * 60}")
    print(f'Search complete: "{args.keywords}"')
    print(f"   New papers added:     {new_count}")
    print(f"   Duplicates skipped:   {dup_count}")
    print(f"   Total in reference.bib: {len(existing_ids)}")
    print(f"{'=' * 60}")


# ─── CLI ──────────────────────────────────────────────────────────────────────


def main():
    parser = argparse.ArgumentParser(
        description=(
            "Literature Review — OpenAlex Search & Reference Manager. "
            "Use English academic keyword groups as the main OpenAlex query language."
        ),
        epilog=(
            "Keyword guidance: OpenAlex is mainly used here for English-language literature. "
            "If your topic is in Chinese, first convert it into 1-3 English keyword groups "
            "that cover the core concept, close synonyms, and adjacent framing. "
            "Example: '环境规制与绿色创新' -> "
            "'environmental regulation AND green innovation'."
        ),
    )
    # Default: search mode (also works without subcommand)
    parser.add_argument(
        "--keywords",
        "-k",
        type=str,
        help="Search keywords (supports Boolean: AND, OR, NOT)",
    )
    parser.add_argument(
        "--journal-list", "-j", type=str, help="Path to journal_list.json"
    )
    parser.add_argument(
        "--output-dir", "-o", type=str, default=".", help="Output directory"
    )
    parser.add_argument(
        "--min-year", type=int, default=None, help="Minimum publication year"
    )
    parser.add_argument(
        "--max-results",
        type=int,
        default=MAX_RESULTS_DEFAULT,
        help="Max results to fetch",
    )
    parser.add_argument(
        "--per-page", type=int, default=PER_PAGE_DEFAULT, help="Results per API page"
    )
    parser.add_argument(
        "--sort",
        type=str,
        default="relevance_score:desc",
        help="Sort order: relevance_score:desc, cited_by_count:desc, publication_date:desc",
    )
    parser.add_argument(
        "--email",
        type=str,
        default=POLITE_EMAIL,
        help="Optional compatibility contact email for fallback OpenAlex requests",
    )
    parser.add_argument(
        "--api-key",
        type=str,
        default=None,
        help="Optional OpenAlex API key. If omitted, auto-load OPENALEX_API_KEY from the repo-root .env",
    )
    parser.add_argument(
        "--type",
        type=str,
        default="article",
        help="Work type filter: article (default), preprint, or article,preprint",
    )
    parser.add_argument(
        "--find-journal", type=str, default=None, help="Find a journal's OpenAlex ID"
    )

    args = parser.parse_args()

    if args.find_journal:
        find_journal(args.find_journal, args.email, args.api_key)
    elif args.keywords and args.journal_list:
        run_search(args)
    else:
        parser.print_help()
        print("\nExamples:")
        print(
            '  python search_openalex.py --keywords "ESG disclosure" --journal-list journal_list.json'
        )
        print('  python search_openalex.py --find-journal "Journal of Finance"')


if __name__ == "__main__":
    main()
