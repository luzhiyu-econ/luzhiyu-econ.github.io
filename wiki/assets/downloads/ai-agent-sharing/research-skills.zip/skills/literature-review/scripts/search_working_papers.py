#!/usr/bin/env python3
"""
Working Paper Search — OpenAlex SSRN / NBER / CEPR Discovery
==============================================================
Searches OpenAlex for working papers on SSRN, filtered by institution
(NBER / CEPR) or by economics field. Outputs to workingpaper.json and
optionally to reference.bib / search_log.md.

Usage:
    python search_working_papers.py --mode institution --keywords "school choice" --output-dir .
    python search_working_papers.py --mode field --min-year 2025 --output-dir .
    python search_working_papers.py --mode institution --output-dir . --max-results 500
"""

import argparse
import json
import os
import re
import time
import urllib.parse
import urllib.request
from datetime import datetime
from pathlib import Path

# ─── Configuration ────────────────────────────────────────────────────────────


def load_repo_env():
    """Load repo-root .env without overwriting existing environment variables."""
    env_path = Path(__file__).resolve().parents[4] / ".env"
    if not env_path.exists():
        return
    for raw_line in env_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip("'\"")
        if key:
            os.environ.setdefault(key, value)


load_repo_env()

OPENALEX_API = "https://api.openalex.org"
POLITE_EMAIL = os.getenv("OPENALEX_EMAIL", "").strip()
OPENALEX_API_KEY = os.getenv("OPENALEX_API_KEY", "").strip()
PER_PAGE_DEFAULT = 50
MAX_RESULTS_DEFAULT = 200
REQUEST_DELAY = 0.15

SSRN_SOURCE_ID = "S4210172589"
NBER_INSTITUTION_ID = "I1321305853"
CEPR_INSTITUTION_ID = "I4210140326"
ECONOMICS_FIELD_ID = "fields/20"


# ─── Shared Helpers (mirrored from search_openalex.py) ────────────────────────


def api_get(endpoint, params=None, email=None, api_key=None):
    """GET request to OpenAlex with repo auth defaults."""
    url = f"{OPENALEX_API}/{endpoint}"
    request_params = dict(params or {})
    contact_email, effective_api_key = resolve_openalex_auth(email, api_key)
    if contact_email:
        request_params.setdefault("mailto", contact_email)
    if effective_api_key:
        request_params.setdefault("api_key", effective_api_key)
    if request_params:
        url += "?" + urllib.parse.urlencode(request_params, safe=":,|/")

    headers = {"User-Agent": build_user_agent(contact_email)}
    req = urllib.request.Request(url, headers=headers)

    max_retries = 3
    for attempt in range(max_retries):
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            if e.code == 429:
                wait = 2 ** (attempt + 1)
                print(f"  Rate limited, waiting {wait}s...")
                time.sleep(wait)
            elif e.code == 403:
                print(f"  403 Forbidden: {url}")
                return None
            else:
                raise
        except Exception as e:
            if attempt < max_retries - 1:
                time.sleep(1)
            else:
                print(f"  API error after {max_retries} retries: {e}")
                return None
    return None


def normalize_openalex_id(value):
    if not value:
        return ""
    return str(value).replace("https://openalex.org/", "").strip()


def reconstruct_abstract(inverted_index):
    if not inverted_index:
        return ""
    word_positions = []
    for word, positions in inverted_index.items():
        for pos in positions:
            word_positions.append((pos, word))
    word_positions.sort(key=lambda x: x[0])
    return " ".join(w for _, w in word_positions)


def contains_cjk(text):
    if not text:
        return False
    return bool(re.search(r"[\u4e00-\u9fff]", text))


def resolve_openalex_auth(email=None, api_key=None):
    """Resolve the effective OpenAlex auth settings for this request."""
    contact_email = (email if email is not None else POLITE_EMAIL).strip()
    effective_api_key = (api_key if api_key is not None else OPENALEX_API_KEY).strip()
    return contact_email, effective_api_key


def build_user_agent(contact_email=""):
    """Build a stable User-Agent header without exposing a hardcoded mailbox."""
    base = "LiteratureReviewSkill/1.0"
    return f"{base} (contact:{contact_email})" if contact_email else base


def describe_openalex_auth(email=None, api_key=None):
    """Return a human-readable auth mode and whether it is a fallback path."""
    contact_email, effective_api_key = resolve_openalex_auth(email, api_key)
    if effective_api_key:
        return "api_key (.env or --api-key)", False
    if contact_email:
        return "fallback without api_key (contact email only)", True
    return "fallback without api_key (anonymous compatibility mode)", True


def make_cite_key(work):
    authors = work.get("authorships", [])
    if authors and authors[0].get("author", {}).get("display_name"):
        last_name = authors[0]["author"]["display_name"].split()[-1]
        last_name = re.sub(r"[^a-zA-Z]", "", last_name) or "Unknown"
    else:
        last_name = "Unknown"
    year = work.get("publication_year", "XXXX")
    oa_id = normalize_openalex_id(work.get("id", ""))
    return f"{last_name}{year}_{oa_id}"


def escape_bibtex(text):
    if not text:
        return ""
    for old, new in [("&", r"\&"), ("%", r"\%"), ("_", r"\_"), ("#", r"\#")]:
        text = text.replace(old, new)
    return text


def format_authors_bibtex(work):
    parts = []
    for a in work.get("authorships", [])[:20]:
        name = a.get("author", {}).get("display_name", "")
        if not name:
            continue
        tokens = name.split()
        if len(tokens) >= 2:
            parts.append(f"{tokens[-1]}, {' '.join(tokens[:-1])}")
        else:
            parts.append(name)
    return " and ".join(parts)


def work_to_bibtex(work, abstract_text=""):
    key = make_cite_key(work)
    authors = format_authors_bibtex(work)
    title = work.get("display_name", "Untitled")
    year = work.get("publication_year", "")
    doi = (work.get("doi") or "").replace("https://doi.org/", "")
    oa_id = normalize_openalex_id(work.get("id", ""))

    primary = work.get("primary_location", {}) or {}
    source = primary.get("source", {}) or {}
    journal = source.get("display_name", "")
    work_type = work.get("type", "article")

    biblio = work.get("biblio", {}) or {}
    volume = biblio.get("volume", "")
    issue = biblio.get("issue", "")
    first_page = biblio.get("first_page", "")
    last_page = biblio.get("last_page", "")
    pages = (
        f"{first_page}--{last_page}" if first_page and last_page else first_page or ""
    )

    entry_type = "unpublished" if work_type == "preprint" else "article"
    lines = [f"@{entry_type}{{{key},"]
    lines.append(f"  title     = {{{escape_bibtex(title)}}},")
    lines.append(f"  author    = {{{authors}}},")
    if journal:
        if entry_type == "unpublished":
            lines.append(f"  note      = {{{escape_bibtex(journal)}}},")
        else:
            lines.append(f"  journal   = {{{escape_bibtex(journal)}}},")
    lines.append(f"  year      = {{{year}}},")
    if volume:
        lines.append(f"  volume    = {{{volume}}},")
    if issue:
        lines.append(f"  number    = {{{issue}}},")
    if pages:
        lines.append(f"  pages     = {{{pages}}},")
    if doi:
        lines.append(f"  doi       = {{{doi}}},")
    lines.append(f"  openalex  = {{{oa_id}}},")
    if abstract_text:
        abs_clean = abstract_text.replace("{", "").replace("}", "").replace("\n", " ")
        if len(abs_clean) > 2000:
            abs_clean = abs_clean[:2000] + "..."
        lines.append(f"  abstract  = {{{abs_clean}}}")
    lines.append("}")
    return "\n".join(lines)


def load_existing_openalex_ids(bib_path):
    ids = set()
    if not os.path.exists(bib_path):
        return ids
    with open(bib_path, encoding="utf-8") as f:
        content = f.read()
    for match in re.finditer(r"openalex\s*=\s*\{([^}]+)\}", content):
        ids.add(match.group(1).strip())
    return ids


# ─── SSRN ID Extraction ──────────────────────────────────────────────────────


def extract_ssrn_id(doi):
    """Extract SSRN abstract ID from a DOI like 10.2139/ssrn.6375377."""
    if not doi:
        return ""
    doi_str = doi.replace("https://doi.org/", "")
    m = re.search(r"10\.2139/ssrn\.(\d+)", doi_str)
    return m.group(1) if m else ""


# ─── Working Paper JSON I/O ──────────────────────────────────────────────────


def load_working_papers(json_path):
    if not os.path.exists(json_path):
        return []
    with open(json_path, encoding="utf-8") as f:
        return json.load(f)


def save_working_papers(json_path, papers):
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(papers, f, ensure_ascii=False, indent=2)


def existing_wp_ids(papers):
    return {p["openalex_id"] for p in papers}


# ─── Author Metadata Extraction ──────────────────────────────────────────────


def extract_author_info(work):
    """Build author list with institution and NBER/CEPR flags."""
    result = []
    for a in work.get("authorships", [])[:20]:
        name = a.get("author", {}).get("display_name", "Unknown")
        institutions = []
        is_nber = False
        is_cepr = False
        for inst in a.get("institutions", []):
            inst_id = normalize_openalex_id(inst.get("id", ""))
            inst_name = inst.get("display_name", "")
            if inst_name:
                institutions.append(inst_name)
            if inst_id == NBER_INSTITUTION_ID:
                is_nber = True
            if inst_id == CEPR_INSTITUTION_ID:
                is_cepr = True
        result.append(
            {
                "name": name,
                "institutions": institutions,
                "nber": is_nber,
                "cepr": is_cepr,
            }
        )
    return result


def work_to_wp_record(work, keywords_used=""):
    """Convert an OpenAlex work object to a workingpaper.json record."""
    oa_id = normalize_openalex_id(work.get("id", ""))
    doi = (work.get("doi") or "").replace("https://doi.org/", "")
    ssrn_id = extract_ssrn_id(doi)
    abstract = reconstruct_abstract(work.get("abstract_inverted_index"))

    primary = work.get("primary_location", {}) or {}
    source = primary.get("source", {}) or {}

    oa_info = work.get("open_access", {}) or {}
    best_oa = work.get("best_oa_location", {}) or {}

    topics = []
    field = ""
    for t in work.get("topics", []):
        topics.append(t.get("display_name", ""))
        if not field:
            f = t.get("field", {})
            if f:
                field = f.get("display_name", "")
    primary_topic = work.get("primary_topic", {}) or {}
    if primary_topic and not field:
        f = primary_topic.get("field", {})
        if f:
            field = f.get("display_name", "")
    if primary_topic and not topics:
        topics.append(primary_topic.get("display_name", ""))

    return {
        "openalex_id": oa_id,
        "doi": doi,
        "ssrn_id": ssrn_id,
        "title": work.get("display_name", "Untitled"),
        "authors": extract_author_info(work),
        "year": work.get("publication_year"),
        "source": source.get("display_name", ""),
        "type": work.get("type", ""),
        "abstract": abstract,
        "abstract_source": "openalex" if abstract else None,
        "cited_by_count": work.get("cited_by_count", 0),
        "is_oa": oa_info.get("is_oa", False),
        "oa_url": best_oa.get("landing_page_url") or (work.get("doi") or ""),
        "topics": topics[:5],
        "field": field,
        "keywords_used": keywords_used,
        "search_date": datetime.now().strftime("%Y-%m-%d"),
        "ssrn_abstract_fetched": bool(abstract),
    }


# ─── Search Engine ────────────────────────────────────────────────────────────


def search_working_papers(
    mode,
    keywords=None,
    min_year=None,
    max_results=200,
    per_page=50,
    sort="publication_date:desc",
    email=None,
    api_key=None,
):
    """
    Search OpenAlex for SSRN working papers.

    mode: "institution" — filter to NBER/CEPR affiliations on SSRN
          "field"       — filter to Economics field on SSRN
    """
    all_works = []

    filters = [f"primary_location.source.id:https://openalex.org/{SSRN_SOURCE_ID}"]

    if mode == "institution":
        filters.append(
            f"authorships.institutions.id:"
            f"https://openalex.org/{NBER_INSTITUTION_ID}"
            f"|https://openalex.org/{CEPR_INSTITUTION_ID}"
        )
    elif mode == "field":
        filters.append(f"primary_topic.field.id:{ECONOMICS_FIELD_ID}")

    if keywords:
        filters.append(f"default.search:{keywords}")
    if min_year:
        filters.append(f"publication_year:>{min_year - 1}")

    filter_str = ",".join(filters)

    cursor = "*"
    page_num = 0

    select_fields = (
        "id,doi,display_name,publication_year,publication_date,"
        "authorships,primary_location,biblio,open_access,"
        "best_oa_location,cited_by_count,abstract_inverted_index,"
        "language,type,is_retracted,primary_topic,topics"
    )

    while cursor and len(all_works) < max_results:
        remaining = max_results - len(all_works)
        params = {
            "filter": filter_str,
            "per_page": min(per_page, remaining),
            "cursor": cursor,
            "sort": sort,
            "select": select_fields,
        }

        data = api_get("works", params, email, api_key)
        if not data or "results" not in data:
            break

        results = data["results"]
        if not results:
            break

        all_works.extend(results[:remaining])
        page_num += 1

        meta = data.get("meta", {})
        cursor = meta.get("next_cursor")
        total = meta.get("count", "?")
        print(f"  Page {page_num}: fetched {len(results)} (total available: {total})")

        time.sleep(REQUEST_DELAY)

    return all_works


# ─── Search Log Writer ────────────────────────────────────────────────────────


def write_wp_search_log(log_path, mode, keywords, records, new_count, dup_count):
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    label = keywords if keywords else f"[{mode} mode, no keywords]"

    with open(log_path, "a", encoding="utf-8") as f:
        f.write(f'\n## WP Search: "{label}"\n')
        f.write(
            f"**Date:** {now} | **Mode:** {mode} | "
            f"**Results:** {len(records)} | "
            f"**New:** {new_count} | **Duplicates skipped:** {dup_count}\n\n"
        )

        for i, rec in enumerate(records, 1):
            authors = rec.get("authors", [])
            if authors:
                first = authors[0].get("name", "Unknown")
                author_str = f"{first} et al." if len(authors) > 1 else first
            else:
                author_str = "Unknown"

            nber_tag = " [NBER]" if any(a.get("nber") for a in authors) else ""
            cepr_tag = " [CEPR]" if any(a.get("cepr") for a in authors) else ""

            f.write(
                f"### [{i}] {author_str} ({rec.get('year', 'N/A')})"
                f'{nber_tag}{cepr_tag} — "{rec.get("title", "")}"\n'
            )
            f.write(
                f"- **Source:** {rec.get('source', 'N/A')} | "
                f"**Type:** {rec.get('type', 'N/A')} | "
                f"**Citations:** {rec.get('cited_by_count', 0)}\n"
            )
            f.write(
                f"- **DOI:** {rec.get('doi', 'N/A')} | "
                f"**SSRN ID:** {rec.get('ssrn_id', 'N/A')}\n"
            )
            f.write(f"- **OpenAlex:** {rec.get('openalex_id', '')}\n")
            if rec.get("abstract"):
                f.write(f"- **Abstract:** {rec['abstract']}\n")
            else:
                f.write(
                    "- **Abstract:** _(not available from OpenAlex — "
                    "run fetch_ssrn_meta.py to retrieve from SSRN)_\n"
                )
            f.write("\n")


# ─── Main Pipeline ────────────────────────────────────────────────────────────


def run(args):
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    wp_path = output_dir / "workingpaper.json"
    bib_path = output_dir / "reference.bib"
    log_path = output_dir / "search_log.md"

    if not log_path.exists():
        with open(log_path, "w", encoding="utf-8") as f:
            f.write("# Literature Search Log\n\n")
            f.write(
                f"_Project initialized: {datetime.now().strftime('%Y-%m-%d %H:%M')}_\n"
            )

    if not bib_path.exists():
        with open(bib_path, "w", encoding="utf-8") as f:
            f.write("% Literature Review BibTeX References\n")
            f.write("% Generated by literature-review skill\n")
            f.write(f"% Created: {datetime.now().strftime('%Y-%m-%d')}\n\n")

    existing_papers = load_working_papers(wp_path)
    existing_ids = existing_wp_ids(existing_papers)
    bib_ids = load_existing_openalex_ids(bib_path)

    mode_label = (
        "NBER/CEPR institution" if args.mode == "institution" else "Economics field"
    )
    kw_label = f'"{args.keywords}"' if args.keywords else "(no keywords)"
    print(f"Searching SSRN working papers [{mode_label}] for: {kw_label}")
    print(
        f"   Min year: {args.min_year or 'None'} | Sort: {args.sort} | "
        f"Max results: {args.max_results}"
    )
    auth_label, is_fallback = describe_openalex_auth(args.email, args.api_key)
    print(f"   OpenAlex auth: {auth_label}")
    if is_fallback:
        print(
            "   WARNING: OPENALEX_API_KEY is missing; using a compatibility fallback instead of the standard key-based path."
        )

    if args.keywords and contains_cjk(args.keywords):
        print(
            "   Warning: Chinese characters detected. Convert to English keywords first."
        )

    works = search_working_papers(
        mode=args.mode,
        keywords=args.keywords,
        min_year=args.min_year,
        max_results=args.max_results,
        per_page=args.per_page,
        sort=args.sort,
        email=args.email,
        api_key=args.api_key,
    )

    print(f"\nFound {len(works)} results. Processing...")

    new_records = []
    new_bibtex = []
    new_count = 0
    dup_count = 0

    for work in works:
        if work.get("is_retracted", False):
            continue

        oa_id = normalize_openalex_id(work.get("id", ""))

        if oa_id in existing_ids:
            dup_count += 1
            continue

        existing_ids.add(oa_id)
        new_count += 1

        record = work_to_wp_record(work, keywords_used=args.keywords or "")
        new_records.append(record)
        existing_papers.append(record)

        if oa_id not in bib_ids:
            bib_ids.add(oa_id)
            bib_entry = work_to_bibtex(work, record.get("abstract", ""))
            new_bibtex.append(bib_entry)

    save_working_papers(wp_path, existing_papers)

    if new_bibtex:
        with open(bib_path, "a", encoding="utf-8") as f:
            f.write("\n" + "\n\n".join(new_bibtex) + "\n")

    write_wp_search_log(
        log_path, args.mode, args.keywords, new_records, new_count, dup_count
    )

    print(f"\n{'=' * 60}")
    print(f"Search complete ({mode_label})")
    print(f"   New papers added:       {new_count}")
    print(f"   Duplicates skipped:     {dup_count}")
    print(f"   Total in workingpaper.json: {len(existing_papers)}")
    print(f"   Total in reference.bib: {len(bib_ids)}")
    missing_abs = sum(1 for p in existing_papers if not p.get("ssrn_abstract_fetched"))
    if missing_abs:
        print(f"   Papers needing SSRN abstract fetch: {missing_abs}")
        print("   Run fetch_ssrn_meta.py to retrieve missing abstracts.")
    print(f"{'=' * 60}")


# ─── CLI ──────────────────────────────────────────────────────────────────────


def main():
    parser = argparse.ArgumentParser(
        description="Search OpenAlex for SSRN working papers (NBER/CEPR or Economics field)."
    )
    parser.add_argument(
        "--mode",
        "-m",
        required=True,
        choices=["institution", "field"],
        help="institution = NBER/CEPR authors on SSRN; field = Economics field on SSRN",
    )
    parser.add_argument(
        "--keywords",
        "-k",
        type=str,
        default=None,
        help="Optional keyword search (Boolean: AND, OR, NOT)",
    )
    parser.add_argument(
        "--output-dir",
        "-o",
        type=str,
        default=".",
        help="Output directory for workingpaper.json etc.",
    )
    parser.add_argument(
        "--min-year", type=int, default=None, help="Minimum publication year"
    )
    parser.add_argument(
        "--max-results",
        type=int,
        default=MAX_RESULTS_DEFAULT,
        help="Maximum results to fetch",
    )
    parser.add_argument(
        "--per-page", type=int, default=PER_PAGE_DEFAULT, help="Results per API page"
    )
    parser.add_argument(
        "--sort",
        type=str,
        default="publication_date:desc",
        help="Sort: publication_date:desc, cited_by_count:desc, relevance_score:desc",
    )
    parser.add_argument(
        "--email",
        type=str,
        default=POLITE_EMAIL,
        help="Optional compatibility contact email for fallback OpenAlex requests",
    )
    parser.add_argument(
        "--api-key",
        type=str,
        default=None,
        help="Optional OpenAlex API key. If omitted, auto-load OPENALEX_API_KEY from the repo-root .env",
    )

    args = parser.parse_args()
    run(args)


if __name__ == "__main__":
    main()
