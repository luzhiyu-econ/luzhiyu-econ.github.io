---
name: pyfixest-empirical
description: Estimate and diagnose econometric models in Python with PyFixest, including fixed effects, IV, PPML, DID/event studies, clustered inference, and Stata-to-Python translation. Use for estimation, not final publication-table formatting.
---

# PyFixest Empirical

Use PyFixest to produce reproducible estimates and structured diagnostics from research data.

## Environment

Use the project's own environment and `uv add pyfixest` when the dependency is missing. Do not create a venv inside a shared data directory and do not use bare `pip install`.

## Route

- Formula syntax, multiple estimations, IV, and result objects: `references/formula_syntax.md`.
- Standard errors, clustering, bootstrap, and randomization inference: `references/inference_guide.md`.
- DID and event-study estimators: `references/did_guide.md`.
- Stata command and option mapping: `references/stata_mapping.md`.
- Reusable result helpers: `scripts/pyfixest_helpers.py`.

## Workflow

1. State the observation unit, outcome, treatment, controls, fixed effects, and intended inference level.
2. Check keys, missingness, variation, treatment timing, singleton groups, and cluster counts.
3. Write the simplest specification that matches the identification design.
4. Estimate the baseline, then vary one modeling decision at a time.
5. Inspect sample changes, coefficient scale, standard errors, convergence, and dropped observations.
6. For DID or IV, report design-specific diagnostics rather than relying on the headline coefficient alone.
7. Return tidy estimates and metadata suitable for `regression-table` or `academic-figure`.

## Guardrails

Do not treat fixed effects as a substitute for identification. Do not silently change samples across columns. Set an explicit event-study reference period. Explain any mismatch with Stata before claiming replication.

## Output

Report the formula, estimator, sample size, fixed effects, variance estimator, coefficient and uncertainty, diagnostics, and code or file paths used.
