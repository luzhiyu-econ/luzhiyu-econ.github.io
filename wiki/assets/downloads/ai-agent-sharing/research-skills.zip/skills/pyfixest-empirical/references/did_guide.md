# PyFixest DID & Event Study Guide

Difference-in-Differences estimation, event studies, and treatment effect heterogeneity with staggered adoption.

## Contents

- `1` Overview of estimators
- `2` TWFE event study
- `3` Gardner DID2S
- `4` Unified `event_study()` API
- `5` Local projections DID
- `6` Panel visualization
- `7` Data requirements
- `8` Complete DID workflow example
- `9` Common pitfalls

---

## 1 · Overview of Estimators

| Estimator | Function | When to Use |
|-----------|----------|-------------|
| **TWFE** | `pf.feols()` with `i()` | Homogeneous treatment effects, no staggered adoption concerns |
| **DID2S** | `pf.did2s()` | Staggered adoption, heterogeneous effects (Gardner 2022) |
| **LPDID** | `pf.lpdid()` | Local projections approach to DID |
| **Unified API** | `pf.event_study()` | Common interface for all estimators |

---

## 2 · TWFE Event Study

The standard two-way fixed effects event study specification.

### Formula syntax

```python
fit_twfe = pf.feols(
    "Y ~ i(rel_year, ref=-1) | unit_id + year",
    data=df,
    vcov={"CRV1": "unit_id"},
)
```

**Key elements:**
- `i(rel_year, ref=-1)` — Creates dummies for each relative time period, omitting period -1 as reference.
- `| unit_id + year` — Unit and time fixed effects.
- `vcov={"CRV1": "unit_id"}` — Cluster at unit level.

### Important: `ref` must match data type

If `rel_year` is float (common when it comes from Stata or has NaN), use:
```python
"Y ~ i(rel_year, ref=-1.0)"    # float ref
```

If `rel_year` is int:
```python
"Y ~ i(rel_year, ref=-1)"      # int ref
```

### Binning distant leads/lags

For clean event study plots, bin extreme relative periods:

```python
# Create binned relative year
df["rel_year_binned"] = df["rel_year"].clip(-5, 10)
# or equivalently:
df["rel_year_binned"] = np.where(df["rel_year"] < -5, -5,
                        np.where(df["rel_year"] > 10, 10,
                                 df["rel_year"]))

fit = pf.feols("Y ~ i(rel_year_binned, ref=-1) | unit_id + year",
               data=df, vcov={"CRV1": "unit_id"})
```

### Event study plot

```python
pf.iplot(
    fit_twfe,
    coord_flip=False,           # horizontal (standard for event studies)
    figsize=(900, 400),         # width × height
    title="Event Study: Effect of Treatment",
    # rotate_xticks=45,         # rotate x-axis labels
)
```

**Stata equivalent:**
```stata
reghdfe Y ib(-1).rel_year, absorb(unit_id year) cluster(unit_id)
coefplot, vertical drop(_cons) yline(0) xline(-0.5)
```

---

## 3 · Gardner's DID2S (Two-Step Estimator)

Addresses bias from heterogeneous treatment effects in staggered DID settings. Step 1 estimates FE from untreated observations; Step 2 estimates treatment effects on residualized outcomes.

### Direct API

```python
fit_did2s = pf.did2s(
    data=df,
    yname="Y",                              # dependent variable
    first_stage="~ 0 | unit_id + year",     # FE specification for step 1
    second_stage="~ i(rel_year, ref=-1)",   # treatment effect specification
    treatment="treated",                     # treatment indicator (0/1)
    cluster="unit_id",                       # clustering variable
)
```

**Parameters explained:**
- `first_stage`: Fixed effects to absorb. `~ 0` means no additional regressors.
  - `~ X1 + X2 | unit_id + year` — include controls in step 1.
- `second_stage`: What to estimate. Can be:
  - `~ i(rel_year, ref=-1)` — full event study
  - `~ is_treated` — single ATT coefficient
- `treatment`: Binary variable (True/1 for treated observations).
- `cluster`: Clustering variable for standard errors.

### Comparing TWFE vs DID2S

```python
fit_twfe = pf.feols(
    "Y ~ i(rel_year, ref=-1) | unit_id + year",
    data=df, vcov={"CRV1": "unit_id"}
)

fit_did2s = pf.did2s(
    df, yname="Y",
    first_stage="~ 0 | unit_id + year",
    second_stage="~ i(rel_year, ref=-1)",
    treatment="treated", cluster="unit_id",
)

# Side-by-side event study plot
pf.iplot(
    [fit_twfe, fit_did2s],
    coord_flip=False,
    title="TWFE vs DID2S",
    figsize=(900, 400),
)

# Side-by-side table
pf.etable([fit_twfe, fit_did2s])
```

**Stata equivalent:**
```stata
* Install: ssc install did2s
did2s Y, first_stage(i.unit_id i.year) ///
    second_stage(ib(-1).rel_year) ///
    treatment(treated) cluster(unit_id)
```

---

## 4 · Unified `event_study()` API

A convenience wrapper that standardizes the interface across estimators.

### ATT estimation (single coefficient)

```python
fit_att = pf.event_study(
    data=df,
    yname="Y",           # dependent variable
    idname="unit_id",    # unit identifier
    tname="year",        # time variable
    gname="g",           # treatment cohort (first treatment year; 0 = never treated)
    estimator="twfe",    # or "did2s"
)
```

### Dynamic event study

```python
fit_dynamic = pf.event_study(
    data=df,
    yname="Y",
    idname="unit_id",
    tname="year",
    gname="g",
    estimator="did2s",
    att=False,           # dynamic effects instead of single ATT
)
```

### Comparing estimators via `event_study()`

```python
fit_twfe = pf.event_study(data=df, yname="Y", idname="id",
                           tname="year", gname="g", estimator="twfe")
fit_did2s = pf.event_study(data=df, yname="Y", idname="id",
                            tname="year", gname="g", estimator="did2s")

pf.etable([fit_twfe, fit_did2s])
```

---

## 5 · Local Projections DID (LPDID)

An alternative estimator using local projections for dynamic treatment effects.

```python
fit_lp = pf.lpdid(
    data=df,
    yname="Y",
    idname="unit_id",
    tname="year",
    gname="g",
    # Additional options available — see API reference
)
```

---

## 6 · Panel Visualization

Visualize treatment assignment patterns in your panel:

```python
pf.panelview(
    data=df,
    unit="unit_id",
    time="year",
    treat="treated",    # binary treatment indicator
    # collapse_to_cohort=True,  # aggregate by treatment cohort
)
```

This helps diagnose:
- Staggered adoption patterns
- Balance of treated/control units across time
- Potential issues with never-treated comparison groups

---

## 7 · Data Requirements

### For `pf.feols()` with `i()`:

| Variable | Type | Description |
|----------|------|-------------|
| `Y` | numeric | Outcome |
| `rel_year` | numeric | Relative time to treatment (e.g., -3, -2, -1, 0, 1, 2, ...) |
| `unit_id` | categorical/numeric | Panel unit identifier |
| `year` | numeric | Calendar time |

### For `pf.did2s()`:

| Variable | Type | Description |
|----------|------|-------------|
| `Y` | numeric | Outcome |
| `treated` | binary (0/1) | Treatment indicator (1 if treated at this time) |
| `unit_id` | categorical/numeric | Panel unit |
| `year` | numeric | Calendar time |

### For `pf.event_study()`:

| Variable | Type | Description |
|----------|------|-------------|
| `Y` | numeric | Outcome |
| `g` | numeric | Treatment cohort year (first year treated; 0 or Inf = never treated) |
| `unit_id` | categorical/numeric | Panel unit |
| `year` | numeric | Calendar time |

---

## 8 · Complete DID Workflow Example

```python
import pandas as pd
import pyfixest as pf

# Load data
df = pd.read_csv("staggered_did_data.csv")

# 1. Visualize treatment pattern
pf.panelview(df, unit="state", time="year", treat="treated")

# 2. Create relative time variable
df["rel_year"] = df["year"] - df["treatment_year"]
df.loc[df["treatment_year"] == 0, "rel_year"] = np.nan  # never-treated
df["rel_year_binned"] = df["rel_year"].clip(-5, 10)

# 3. TWFE event study
fit_twfe = pf.feols(
    "Y ~ i(rel_year_binned, ref=-1) | state + year",
    data=df, vcov={"CRV1": "state"},
)

# 4. DID2S (robust to heterogeneous effects)
fit_did2s = pf.did2s(
    df, yname="Y",
    first_stage="~ 0 | state + year",
    second_stage="~ i(rel_year_binned, ref=-1)",
    treatment="treated", cluster="state",
)

# 5. Compare
pf.iplot([fit_twfe, fit_did2s],
         coord_flip=False, title="TWFE vs DID2S")

# 6. ATT via unified API
att_twfe = pf.event_study(df, yname="Y", idname="state",
                           tname="year", gname="g", estimator="twfe")
att_did2s = pf.event_study(df, yname="Y", idname="state",
                            tname="year", gname="g", estimator="did2s")

pf.etable([att_twfe, att_did2s])
```

---

## 9 · Common Pitfalls

### 9.1 Forgetting `ref` in `i()`
Without a reference period, all dummies are estimated → no clean interpretation.

### 9.2 Float vs int in `ref`
If `rel_year` is float64 (e.g., from Stata), use `ref=-1.0`, not `ref=-1`.

### 9.3 Never-treated units in relative time
Never-treated units have no meaningful `rel_year`. Either:
- Set `rel_year = NaN` for never-treated units, OR
- Assign a distant value (e.g., -999) and let it be absorbed by fixed effects.

### 9.4 Treatment not binary for DID2S
`pf.did2s()` requires a binary treatment indicator. If treatment is continuous or multi-valued, use TWFE with appropriate specification.

### 9.5 Unbalanced panels
PyFixest handles unbalanced panels, but extreme imbalance can affect event study estimates. Check `pf.panelview()` output.
