# PyFixest Formula Syntax Reference

Complete grammar for PyFixest formula strings. All formulas are passed as the first argument to `pf.feols()`, `pf.fepois()`, `pf.feglm()`.

## Contents

- `1` Basic structure
- `2` Categorical variables
- `3` Multiple estimation operators
- `4` Working with `FixestMulti`
- `5` Sample splitting
- `6` Weighted regression
- `7` Prediction and residuals
- `8` Online learning / coefficient updates

---

## 1 · Basic Structure

```
depvar ~ regressors | fixed_effects | endog ~ instruments
  ↑ Part 1 (required)  ↑ Part 2 (optional)  ↑ Part 3 (IV only)
```

### Part 1: Dependent Variable and Regressors

```python
"Y ~ X1"                    # simple bivariate
"Y ~ X1 + X2 + X3"          # multiple regressors
"Y ~ X1 + X2 + X1:X2"       # interaction term
"Y ~ X1 * X2"               # equivalent: X1 + X2 + X1:X2
"Y ~ 1"                     # intercept only
"Y ~ 0 + X1"                # suppress intercept
"Y ~ np.log(X1)"            # transformations (via numpy)
"Y ~ I(X1**2)"              # polynomial (must wrap in I())
```

### Part 2: Fixed Effects (Absorbed)

```python
"Y ~ X1 | f1"               # one-way FE
"Y ~ X1 | f1 + f2"          # two-way FE
"Y ~ X1 | f1 + f2 + f3"     # three-way FE
"Y ~ X1 | f1^f2"            # interaction FE (f1 × f2 pairs)
```

### Part 3: Instrumental Variables

```python
"Y ~ 1 | X_endog ~ Z1"                    # IV, no FE, no exog controls
"Y ~ X_control | X_endog ~ Z1"            # IV with exog control, no FE
"Y ~ 1 | f1 | X_endog ~ Z1"              # IV with FE, no exog
"Y ~ X_control | f1 | X_endog ~ Z1"      # IV with exog + FE
"Y ~ 1 | f1 + f2 | X_endog ~ Z1 + Z2"   # IV, multi FE, multi instruments
```

> **CRITICAL**: If there are no exogenous regressors, you MUST write `1` (not leave blank):
> ```python
> # WRONG:
> "Y ~ | f1 | X1 ~ Z1"
>
> # CORRECT:
> "Y ~ 1 | f1 | X1 ~ Z1"
> ```

---

## 2 · Categorical Variables

### `C()` — Explicit categorical encoding (dummies estimated)

```python
"Y ~ X1 + C(industry)"      # industry dummies in output
"Y ~ X1 + C(year)"          # year dummies in output
```

Use `C()` when:
- You need to **see** the individual dummy coefficients
- The variable has **few** levels (< 50)
- You want to interact a factor with a continuous variable

### `i()` — Factor interaction (event study / treatment heterogeneity)

```python
"Y ~ i(rel_year)"                        # all levels as dummies
"Y ~ i(rel_year, ref=-1)"                # omit period -1 (reference)
"Y ~ i(rel_year, ref=-1.0)"              # use float if variable is float
"Y ~ i(treat, X1)"                       # interact treat dummies with X1
"Y ~ i(treat, X1, ref=0)"               # interact, omit treat=0
```

> **Event study tip**: Always set `ref` to the period before treatment.

### Fixed effects after `|` — Absorbed (not estimated, fast)

```python
"Y ~ X1 | industry"          # absorb industry FE (fast, not in output)
```

Use `|` when:
- The variable has **many** levels (high-dimensional)
- You don't need individual FE coefficients
- Speed matters

---

## 3 · Multiple Estimation Operators

These operators let you estimate **multiple models** from a single formula call. When used, `feols()` returns a `FixestMulti` object.

### `csw0()` — Cumulative stepwise, starting from empty

```python
"Y ~ X1 | csw0(f1, f2, f3)"
```
Produces 4 models:
1. `Y ~ X1`                  (no FE)
2. `Y ~ X1 | f1`             (one FE)
3. `Y ~ X1 | f1 + f2`        (two FE)
4. `Y ~ X1 | f1 + f2 + f3`   (three FE)

### `csw()` — Cumulative stepwise, no empty start

```python
"Y ~ X1 + csw(X2, X3, X4)"
```
Produces 3 models:
1. `Y ~ X1 + X2`
2. `Y ~ X1 + X2 + X3`
3. `Y ~ X1 + X2 + X3 + X4`

### `sw0()` — Stepwise replacement, starting from empty

```python
"Y ~ X1 + sw0(X2, X3)"
```
Produces 3 models:
1. `Y ~ X1`          (empty)
2. `Y ~ X1 + X2`     (X2 replaces empty)
3. `Y ~ X1 + X3`     (X3 replaces empty)

### `sw()` — Stepwise replacement, no empty

```python
"Y ~ X1 + sw(X2, X3)"
```
Produces 2 models:
1. `Y ~ X1 + X2`
2. `Y ~ X1 + X3`

### Multiple dependent variables

```python
"Y1 + Y2 + Y3 ~ X1 | f1"
```
Produces 3 models, one per dependent variable.

### Combining operators

You can use multiple estimation operators simultaneously:
```python
"Y1 + Y2 ~ X1 + csw0(X2, X3) | sw(f1, f2)"
```
This produces the cartesian product: 2 dep vars × 3 RHS specs × 2 FE specs.

---

## 4 · Working with `FixestMulti` Objects

When multi-estimation syntax is used:

```python
multi = pf.feols("Y ~ X1 | csw0(f1, f2)", data=df, vcov="HC1")

# List all models
multi.all_fitted_models    # dict: formula_string → Feols

# Access by index
multi.fetch_model(0)       # first model
multi.fetch_model(1)       # second model

# Access by formula
multi.all_fitted_models["Y ~ X1"]
multi.all_fitted_models["Y ~ X1 | f1"]

# Table of all models
multi.etable()

# Update SE for ALL models at once
multi.vcov("iid").summary()
multi.vcov({"CRV1": "f1"}).summary()

# Plots
multi.coefplot()
```

---

## 5 · Sample Splitting

### `split` — Run model on each subsample

```python
fit = pf.feols("Y ~ X1 | f1", data=df,
               vcov={"CRV1": "f1"},
               split="industry_type")
```
Runs the regression separately for each value of `industry_type`.

### `fsplit` — Full sample + each subsample

```python
fit = pf.feols("Y ~ X1 | f1", data=df,
               vcov={"CRV1": "f1"},
               fsplit="industry_type")
```
Same as `split` but also includes the full-sample result.

---

## 6 · Weighted Regression

```python
fit = pf.feols("Y ~ X1 | f1", data=df, weights="pop_weight")
```

Equivalent Stata: `reghdfe Y X1 [aweight=pop_weight], absorb(f1)`

---

## 7 · Prediction and Residuals

```python
fit = pf.feols("Y ~ X1 + X2 | f1", data=df)

# In-sample
yhat = fit.predict()       # fitted values (without FE)
resid = fit.resid()        # residuals

# New data prediction
yhat_new = fit.predict(newdata=df_new)
```

> **Note**: `predict()` by default does NOT include fixed effects in predictions.
> To include FE, use `fit.predict(type="response")` for GLM or access `fit._fixef_dict` for FE values.

---

## 8 · Online Learning / Coefficient Updates

For streaming data or sequential estimation:

```python
fit = pf.feols("Y ~ X1 + X2", data=df_initial)

# Update with new observations
X_new = np.c_[np.ones(5), new_data[["X1", "X2"]].values]
y_new = new_data["Y"].values
fit.update(X_new, y_new)

# Coefficients are now updated (Sherman-Morrison-Woodbury)
fit.coef()
```
