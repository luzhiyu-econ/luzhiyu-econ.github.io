# PyFixest Inference Guide

Standard errors, bootstrap, randomization inference, multiple testing corrections, and small-sample corrections.

## Contents

- `1` Variance-covariance types
- `2` Small-sample corrections
- `3` Wild cluster bootstrap
- `4` Randomization inference
- `5` Multiple testing corrections
- `6` Causal cluster variance estimator
- `7` Wald tests / joint hypothesis tests
- `8` Joint confidence intervals
- `9` Choosing the right inference method

---

## 1 · Variance-Covariance Types

### Specifying at estimation time

```python
fit = pf.feols("Y ~ X1 | f1", data=df, vcov=<type>)
```

### Switching after estimation (no re-estimation needed)

```python
fit.vcov(<type>).summary()
```

### Available types

| `vcov` value | Description | Stata Equivalent |
|-------------|-------------|-----------------|
| `"iid"` | Spherical errors (homoskedastic) | Default `reg` |
| `"HC1"` | Heteroskedasticity-robust (White) | `robust` / `vce(robust)` |
| `"HC2"` | HC2 robust | `vce(hc2)` |
| `"HC3"` | HC3 robust (jackknife-like) | `vce(hc3)` ⚠️ |
| `{"CRV1": "var"}` | Cluster-robust (Liang-Zeger) | `cluster(var)` |
| `{"CRV1": "v1 + v2"}` | Two-way cluster-robust | `cluster(v1 v2)` ⚠️ |
| `{"CRV3": "var"}` | CRV3 cluster (jackknife) | Not in Stata |
| `{"CRV3": "v1 + v2"}` | Two-way CRV3 | Not in Stata |

> ⚠️ marks types where PyFixest and Stata default SSC differ. See § SSC below.

---

## 2 · Small-Sample Corrections (SSC)

The `pf.ssc()` function controls four parameters that scale the variance-covariance matrix.

```python
fit = pf.feols("Y ~ X1 | f1", data=df,
               vcov={"CRV1": "f1"},
               ssc=pf.ssc(
                   k_adj=True,         # N/(N-k) adjustment
                   k_fixef="none",     # how FE count toward k
                   G_adj=True,         # G/(G-1) cluster adjustment
                   G_df="min",         # multi-way: min vs conventional
               ))
```

### Parameter: `k_adj` (default: `True`)

Controls the N/(N-k) degrees-of-freedom adjustment.

- `True`: Apply `(N-1)/(N-k)` scaling to vcov.
- `False`: No scaling.

For heteroskedastic errors with `k_adj=True`, the correction is `N/(N-k)`.

### Parameter: `k_fixef` (default: `"none"`)

How fixed effects count toward `k` in the k-adjustment:

| Value | FE counted as | Use case |
|-------|--------------|----------|
| `"none"` | 0 (ignore FE) | Default; matches Stata `reghdfe` |
| `"full"` | All FE levels | Conservative; treats FE as estimated params |
| `"nonnested"` | Only non-nested FE | Excludes FE nested within cluster var |

### Parameter: `G_adj` (default: `True`)

The `G/(G-1)` cluster-level correction:

- `True`: Apply the correction (standard practice).
- `False`: No cluster-level correction.

### Parameter: `G_df` (default: `"min"`)

Only relevant for **multi-way clustering**. How `G` is determined per dimension:

| Value | Behavior | Software |
|-------|----------|----------|
| `"min"` | Use min(G_A, G_B) for all dimensions | PyFixest default, fixest (R) |
| `"conventional"` | Each dimension uses its own G | Stata default |

### Recipes to match Stata exactly

```python
# Match Stata: reg Y X1, vce(hc3)
pf.feols("Y ~ X1", data=df, vcov="HC3", ssc=pf.ssc(k_adj=False))

# Match Stata: reghdfe Y X1, absorb(f1) cluster(f1 f2)
pf.feols("Y ~ X1 | f1", data=df,
         vcov={"CRV1": "f1 + f2"},
         ssc=pf.ssc(G_df="conventional"))

# Match Stata: reghdfe Y X1, absorb(f1) cluster(f1)
# (single cluster — no SSC difference)
pf.feols("Y ~ X1 | f1", data=df, vcov={"CRV1": "f1"})
```

### Degrees of freedom for t-distribution

| Error type | df for p-values and CI |
|-----------|----------------------|
| IID / HC | `N - k` (k depends on `k_fixef`) |
| CRV (one-way) | `G - 1` |
| CRV (two-way) | `min(G_1, G_2) - 1` |
| GLM | Normal approximation (z, not t) |

---

## 3 · Wild Cluster Bootstrap

For inference with few clusters (G < 30–50), the wild bootstrap provides more reliable p-values than CRV1.

```python
fit = pf.feols("Y ~ X1", data=df, vcov={"CRV1": "cluster_id"})

result = fit.wildboottest(
    param="X1",          # which coefficient to test
    reps=999,            # bootstrap replications
    # seed=42,           # for reproducibility
    # impose_null=True,  # impose H0 (default, recommended)
)
```

Returns a Series with:
- `param`: tested parameter
- `t value`: original t-statistic
- `Pr(>|t|)`: bootstrap p-value
- `bootstrap_type`: type of bootstrap (e.g., "11")
- `inference`: cluster variable
- `impose_null`: whether H0 was imposed

**Stata equivalent:**
```stata
reg Y X1, cluster(cluster_id)
boottest X1, reps(999)
```

---

## 4 · Randomization Inference

Test sharp null hypotheses by permuting treatment assignment.

```python
fit = pf.feols("Y ~ X1", data=df, vcov={"CRV1": "cluster_id"})

result = fit.ritest(
    resampvar="X1=0",          # H0: coefficient of X1 = 0
    reps=1000,                  # permutations
    cluster="cluster_id",       # cluster-level permutation (optional)
    # seed=42,
)
```

Returns a Series with:
- `H0`: null hypothesis tested
- `ri-type`: randomization type
- `Estimate`: original estimate
- `Pr(>|t|)`: RI p-value
- `Std. Error (Pr(>|t|))`: SE of the p-value
- `2.5% / 97.5%`: CI of the p-value

**Stata equivalent:**
```stata
ritest X1 _b[X1], reps(1000) cluster(cluster_id): reg Y X1
```

---

## 5 · Multiple Testing Corrections

When testing the same hypothesis across multiple outcomes or specifications:

### 5.1 Bonferroni

```python
pf.bonferroni(
    [fit1, fit2, fit3],    # list of fitted models
    param="treatment",      # which parameter
)
```

Simple and conservative. Multiplies p-values by the number of tests.

### 5.2 Romano-Wolf (2005)

```python
pf.rwolf(
    [fit1, fit2, fit3],
    param="treatment",
    reps=9999,
    seed=42,
)
```

Step-down procedure that accounts for dependence between test statistics. Less conservative than Bonferroni.

**Stata equivalent:**
```stata
rwolf Y1 Y2 Y3, indepvar(treatment) method(reghdfe) ///
    abs(firm_id year) cluster(firm_id) reps(9999) seed(42)
```

### 5.3 Westfall-Young

```python
pf.wyoung(
    [fit1, fit2, fit3],
    param="treatment",
    reps=9999,
    seed=42,
)
```

Resampling-based correction. Another alternative to Bonferroni.

### Output format

All three functions return a DataFrame with columns per model:
- `Estimate`, `Std. Error`, `t value`, `Pr(>|t|)`, `2.5%`, `97.5%`
- Plus a row for the adjusted p-value (Bonferroni / RW / WY)

---

## 6 · Causal Cluster Variance Estimator (CCV)

Implements Abadie, Athey, Imbens, and Wooldridge (QJE, 2023). When treatment varies at a level below the cluster, CRV1 can be conservative. CCV provides a tighter bound.

```python
fit = pf.feols("outcome ~ treatment", data=df, vcov={"CRV1": "state"})

result = fit.ccv(
    treatment="treatment",   # treatment variable name
    pk=0.05,                 # share of treated within clusters
    n_splits=2,              # number of sample splits
    seed=42,
)
```

Returns a DataFrame comparing CCV and CRV1 estimates.

---

## 7 · Wald Tests / Joint Hypothesis Tests

### Joint test: β₁ = 0 AND β₂ = 0

```python
fit = pf.feols("Y ~ X1 + X2 | f1", data=df)
fit.wald_test(R=np.eye(2))
# Returns: statistic (F), pvalue
```

**Stata:** `test X1 X2`

### Linear restriction: β₁ + 2β₂ = 3

```python
R = np.array([[1, 2]])
q = np.array([3.0])
fit.wald_test(R=R, q=q)
```

**Stata:** `test X1 + 2*X2 = 3`

### Complex joint test: β₁ + 2β₂ = 2 AND β₂ = 1

```python
R = np.array([[1, 2], [0, 1]])
q = np.array([2.0, 1.0])
fit.wald_test(R=R, q=q)
```

> When R is not an identity matrix and q ≠ 0, the distribution automatically switches from F to χ².

---

## 8 · Joint Confidence Intervals

Simultaneous confidence bands that account for multiple comparisons across coefficients:

```python
fit = pf.feols("Y ~ X1 + C(f1)", data=df)
fit.confint(joint=True)
```

Based on Montiel Olea & Plagborg-Møller (2019). Wider than pointwise CI but valid for simultaneous inference.

---

## 9 · Choosing the Right Inference Method

| Scenario | Recommended |
|----------|------------|
| Cross-section, large N | `vcov="HC1"` |
| Panel, large N and G | `vcov={"CRV1": "id"}` |
| Panel, small G (< 30) | `fit.wildboottest(...)` |
| Experimental, randomized | `fit.ritest(...)` |
| Multiple outcomes | `pf.rwolf(...)` or `pf.bonferroni(...)` |
| Treatment within clusters | `fit.ccv(...)` |
| Many coefficients tested | `fit.confint(joint=True)` |
| Exact Stata replication | Adjust `pf.ssc(...)` per § 2 |
