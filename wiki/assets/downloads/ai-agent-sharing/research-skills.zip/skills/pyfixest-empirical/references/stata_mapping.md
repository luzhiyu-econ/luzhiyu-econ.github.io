# Stata → PyFixest Translation Guide

Exact command-by-command mapping from Stata to PyFixest. Organized by the typical workflow of an empirical economics paper.

## Contents

- `1` Data loading
- `2` OLS without fixed effects
- `3` Robust and clustered standard errors
- `4` Fixed-effect regressions
- `5` Instrumental variables
- `6` Poisson / PPML
- `7` GLM
- `8` Quantile regression
- `9` Post-estimation
- `10` Regression tables
- `11` Bootstrap, RI, and multiple testing
- `12` DID / event study
- `13` Stata `.do` file to Python workflow
- `14` Key differences summary

---

## 1 · Data Loading

| Stata | PyFixest / Pandas |
|-------|-------------------|
| `use "data.dta", clear` | `df = pd.read_stata("data.dta")` |
| `import delimited "data.csv"` | `df = pd.read_csv("data.csv")` |
| `describe` | `df.info()` |
| `summarize Y X1 X2` | `df[["Y","X1","X2"]].describe()` or `pf.dtable(df, vars=["Y","X1","X2"])` |
| `tab industry` | `df["industry"].value_counts()` |
| `xtset id year` | Not needed (PyFixest reads FE from formula) |
| `gen lnY = ln(Y)` | `df["lnY"] = np.log(df["Y"])` |
| `gen X1sq = X1^2` | `df["X1sq"] = df["X1"]**2` |
| `gen treat_post = treat * post` | `df["treat_post"] = df["treat"] * df["post"]` |

---

## 2 · OLS (No Fixed Effects)

> **Design principle:** PyFixest's `feols()` is designed to match **`reghdfe`** (Sergio Correia's package), not `reg` or `xtreg`. For simple OLS without FE, `reg` and `reghdfe` produce identical results, so either Stata command works. But we use `reghdfe` throughout this guide for consistency — it's what your paper will use anyway.

| Stata (`reghdfe`) | PyFixest |
|-------------------|----------|
| `reghdfe Y X1, noabsorb` | `pf.feols("Y ~ X1", data=df)` |
| `reghdfe Y X1 X2 X3, noabsorb` | `pf.feols("Y ~ X1 + X2 + X3", data=df)` |
| `reghdfe Y c.X1#c.X2, noabsorb` | `pf.feols("Y ~ X1 * X2", data=df)` |
| `reghdfe Y i.industry, noabsorb` | `pf.feols("Y ~ C(industry)", data=df)` |
| `reghdfe Y X1 [aweight=w], noabsorb` | `pf.feols("Y ~ X1", data=df, weights="w")` |

> Note: `reghdfe` without `absorb()` requires `noabsorb`. Equivalently, `reg Y X1` produces identical results for these cases.

---

## 3 · Robust and Clustered Standard Errors

| Stata (`reghdfe`) | PyFixest |
|-------------------|----------|
| `reghdfe Y X1, noabsorb vce(robust)` | `pf.feols("Y ~ X1", data=df, vcov="HC1")` |
| `reghdfe Y X1, noabsorb vce(cluster id)` | `pf.feols("Y ~ X1", data=df, vcov={"CRV1": "id"})` |
| `reghdfe Y X1, noabsorb vce(cluster id year)` | `pf.feols("Y ~ X1", data=df, vcov={"CRV1": "id + year"}, ssc=pf.ssc(G_df="conventional"))` ⚠️ |

For HC2/HC3 (no absorbed FE only):

| Stata (`reg`) | PyFixest |
|---------------|----------|
| `reg Y X1, vce(hc2)` | `pf.feols("Y ~ X1", data=df, vcov="HC2")` |
| `reg Y X1, vce(hc3)` | `pf.feols("Y ~ X1", data=df, vcov="HC3", ssc=pf.ssc(k_adj=False))` ⚠️ |

> ⚠️ **SSC difference for HC3**: Stata uses one small-sample correction; PyFixest uses two by default. Add `ssc=pf.ssc(k_adj=False)` to match Stata exactly.
>
> ⚠️ **SSC difference for two-way clustering**: Stata uses "conventional" G_df; PyFixest defaults to "min". Add `ssc=pf.ssc(G_df="conventional")` to match Stata.

---

## 4 · Fixed Effect Regressions

> **⚠️ `xtreg, fe` vs `reghdfe` vs PyFixest:**
>
> PyFixest aligns with **`reghdfe`**, NOT `xtreg`. Point estimates are identical across all three, but **standard errors can differ** because of degrees-of-freedom adjustments:
>
> | Behavior | `xtreg, fe` | `reghdfe` | PyFixest |
> |----------|------------|-----------|----------|
> | Point estimates | ✅ same | ✅ same | ✅ same |
> | Default `k_fixef` | counts all FE levels | `"none"` (ignores FE in DoF) | `"none"` = reghdfe |
> | Singleton detection | ❌ no | ✅ yes | ✅ yes |
> | Multi-way FE | ❌ no | ✅ yes | ✅ yes |
> | Interaction FE (`id#year`) | ❌ no | ✅ yes | ✅ yes (`id^year`) |
>
> **Bottom line:** Always compare PyFixest output against `reghdfe`, not `xtreg`. If you must match `xtreg` SE, set `ssc=pf.ssc(k_fixef="full")`.

| Stata (`reghdfe`) | PyFixest |
|-------------------|----------|
| `reghdfe Y X1, absorb(id)` | `pf.feols("Y ~ X1 \| id", data=df)` |
| `reghdfe Y X1, absorb(id year)` | `pf.feols("Y ~ X1 \| id + year", data=df)` |
| `reghdfe Y X1, absorb(id year) cluster(id)` | `pf.feols("Y ~ X1 \| id + year", data=df, vcov={"CRV1": "id"})` |
| `reghdfe Y X1, absorb(id year) cluster(id year)` | `pf.feols("Y ~ X1 \| id + year", data=df, vcov={"CRV1": "id + year"}, ssc=pf.ssc(G_df="conventional"))` |
| `reghdfe Y X1, absorb(id#year)` | `pf.feols("Y ~ X1 \| id^year", data=df)` |
| `reghdfe Y X1, absorb(id) vce(robust)` | `pf.feols("Y ~ X1 \| id", data=df, vcov="HC1")` |

### Legacy Stata commands → reghdfe equivalents

For reference, if you encounter older `.do` files using legacy commands:

| Legacy Stata | Modern equivalent (`reghdfe`) | Notes |
|-------------|------------------------------|-------|
| `xtreg Y X1, fe` | `reghdfe Y X1, absorb(id)` | SE may differ (DoF) |
| `xtreg Y X1, fe vce(cluster id)` | `reghdfe Y X1, absorb(id) cluster(id)` | SE match if FE nested in cluster |
| `areg Y X1, absorb(id) robust` | `reghdfe Y X1, absorb(id) vce(robust)` | No singleton handling in areg |
| `reg Y X1 i.id` | `reghdfe Y X1, absorb(id)` | Identical, but reghdfe is faster |

---

## 5 · Instrumental Variables

| Stata | PyFixest |
|-------|----------|
| `ivregress 2sls Y (X1 = Z1 Z2)` | `pf.feols("Y ~ 1 \| X1 ~ Z1 + Z2", data=df)` |
| `ivreg2 Y X2 (X1 = Z1 Z2)` | `pf.feols("Y ~ X2 \| X1 ~ Z1 + Z2", data=df)` |
| `ivreghdfe Y (X1 = Z1 Z2), absorb(id year)` | `pf.feols("Y ~ 1 \| id + year \| X1 ~ Z1 + Z2", data=df)` |
| `ivreghdfe Y X2 (X1 = Z1), absorb(id) cluster(id)` | `pf.feols("Y ~ X2 \| id \| X1 ~ Z1", data=df, vcov={"CRV1": "id"})` |

### First stage and diagnostics

| Stata | PyFixest |
|-------|----------|
| `ivreghdfe Y (X1=Z1), first` | `iv._model_1st_stage.summary()` |
| First-stage F (auto-reported) | `iv._f_stat_1st_stage` |
| `weakivtest` (effective F) | `iv.IV_Diag(); iv._eff_F` |

---

## 6 · Poisson / PPML

| Stata | PyFixest |
|-------|----------|
| `ppmlhdfe Y X1, absorb(id)` | `pf.fepois("Y ~ X1 \| id", data=df)` |
| `ppmlhdfe Y X1, absorb(id year) cluster(id)` | `pf.fepois("Y ~ X1 \| id + year", data=df, vcov={"CRV1": "id"})` |

---

## 7 · GLM (Logit, Probit)

> **⚠️ v0.40 limitation:** `feglm()` does NOT support absorbed FE via `|`. Use `C()` dummies instead.

| Stata | PyFixest |
|-------|----------|
| `logit Y X1 X2` | `pf.feglm("Y ~ X1 + X2", data=df, family="logit")` |
| `logit Y X1 X2 i.industry` | `pf.feglm("Y ~ X1 + X2 + C(industry)", data=df, family="logit")` |
| `probit Y X1 X2` | `pf.feglm("Y ~ X1 + X2", data=df, family="probit")` |
| `margins, dydx(X1)` | `from marginaleffects import avg_slopes; avg_slopes(fit, variables="X1")` |
| `predict phat, pr` | `fit.predict(type="response")` |
| `predict xb, xb` | `fit.predict(type="link")` |

---

## 8 · Quantile Regression

| Stata | PyFixest |
|-------|----------|
| `qreg Y X1 X2, quantile(0.5)` | `pf.quantreg("Y ~ X1 + X2", data=df, quantile=0.5)` |
| `sqreg Y X1 X2, q(.1 .25 .5 .75 .9)` | `pf.quantreg("Y ~ X1 + X2", data=df, quantile=[.1,.25,.5,.75,.9])` |
| — | `pf.qplot(fit_qr)` (coefficient plot across quantiles) |

---

## 9 · Post-Estimation

| Stata | PyFixest |
|-------|----------|
| `predict yhat, xb` | `fit.predict()` |
| `predict res, residuals` | `fit.resid()` |
| `matrix list e(b)` | `fit.coef()` |
| `matrix list e(V)` | `fit._vcov` |
| `display e(N)` | `fit._N` |
| `display e(r2)` | `fit._r2` |
| `test X1 X2` | `fit.wald_test(R=np.eye(2))` |
| `test X1 + X2 = 1` | `fit.wald_test(R=np.array([[1,1]]), q=np.array([1.0]))` |
| `lincom X1 + X2` | `fit.wald_test(R=..., q=...)` (use appropriate R matrix) |

---

## 10 · Regression Tables

| Stata | PyFixest |
|-------|----------|
| `eststo m1` + `eststo m2` + `esttab m1 m2` | `pf.etable([fit1, fit2])` |
| `esttab, label` | `pf.etable([fit1, fit2], labels={...})` |
| `esttab, b(3) se(3)` | Default format in etable |
| `esttab using "table.tex", ...` | `pf.etable(..., type="tex")` |
| `esttab, star(* 0.05 ** 0.01 *** 0.001)` | Default in etable |
| `esttab, title("Table 1")` | `pf.etable(..., caption="Table 1")` |
| `esttab, mtitles("OLS" "IV")` | Column headers auto-generated |
| `coefplot m1 m2` | `pf.coefplot([fit1, fit2])` |

---

## 11 · Bootstrap, RI, and Multiple Testing

| Stata | PyFixest |
|-------|----------|
| `boottest X1, reps(999)` | `fit.wildboottest(param="X1", reps=999)` |
| `ritest X1 _b[X1], reps(1000): reg Y X1` | `fit.ritest(resampvar="X1=0", reps=1000)` |
| `ritest X1 _b[X1], cluster(id) reps(1000): reg Y X1` | `fit.ritest(resampvar="X1=0", reps=1000, cluster="id")` |
| `rwolf Y, indepvar(X1) method(reg) reps(9999)` | `pf.rwolf([fit1, fit2], param="X1", reps=9999, seed=42)` |
| — | `pf.bonferroni([fit1, fit2], param="X1")` |
| — | `pf.wyoung([fit1, fit2], param="X1", reps=9999, seed=42)` |

---

## 12 · DID / Event Study

| Stata | PyFixest |
|-------|----------|
| `reghdfe Y ib(-1).rel_year, absorb(id year) cluster(id)` | `pf.feols("Y ~ i(rel_year, ref=-1) \| id + year", data=df, vcov={"CRV1":"id"})` |
| `did2s Y, first_stage(i.id i.year) second_stage(ib(-1).rel_year) treatment(treat) cluster(id)` | `pf.did2s(df, yname="Y", first_stage="~ 0 \| id + year", second_stage="~ i(rel_year, ref=-1)", treatment="treat", cluster="id")` |
| `event_plot` / `coefplot` for event study | `pf.iplot(fit, coord_flip=False)` |

---

## 13 · Common Workflow: Stata `.do` File → Python Script

### Stata `.do` file:

```stata
use "firm_panel.dta", clear

* Baseline
reghdfe ln_revenue treatment X1 X2, absorb(firm_id year) cluster(firm_id)
eststo m1

* Add controls
reghdfe ln_revenue treatment X1 X2 X3 X4, absorb(firm_id year) cluster(firm_id)
eststo m2

* Add industry × year FE
reghdfe ln_revenue treatment X1 X2 X3 X4, absorb(firm_id year#industry) cluster(firm_id)
eststo m3

* IV
ivreghdfe ln_revenue X1 X2 (treatment = Z1), absorb(firm_id year) cluster(firm_id)
eststo m4

esttab m1 m2 m3 m4 using "table2.tex", replace ///
    label b(3) se(3) star(* 0.05 ** 0.01 *** 0.001) ///
    title("Table 2: Baseline Results")
```

### Equivalent Python:

```python
import pandas as pd
import pyfixest as pf

df = pd.read_stata("firm_panel.dta")

# Baseline + progressively add controls
m1 = pf.feols("ln_revenue ~ treatment + X1 + X2 | firm_id + year",
               data=df, vcov={"CRV1": "firm_id"})
m2 = pf.feols("ln_revenue ~ treatment + X1 + X2 + X3 + X4 | firm_id + year",
               data=df, vcov={"CRV1": "firm_id"})

# Industry × year FE
m3 = pf.feols("ln_revenue ~ treatment + X1 + X2 + X3 + X4 | firm_id + year^industry",
               data=df, vcov={"CRV1": "firm_id"})

# IV
m4 = pf.feols("ln_revenue ~ X1 + X2 | firm_id + year | treatment ~ Z1",
               data=df, vcov={"CRV1": "firm_id"})

# Regression table
pf.etable(
    [m1, m2, m3, m4],
    labels={"ln_revenue": "Log Revenue", "treatment": "Treatment"},
    felabels={"firm_id": "Firm FE", "year": "Year FE", "year^industry": "Year × Industry FE"},
    caption="Table 2: Baseline Results",
)
```

---

## 14 · Key Differences Summary

| Feature | Stata (`reghdfe`) | PyFixest |
|---------|-------------------|----------|
| Aligns with | `reghdfe` / `ivreghdfe` / `ppmlhdfe` | ✅ Exact numerical match |
| Does NOT align with | — | `xtreg, fe` (different DoF for SE) |
| Auto-print results | Yes | No (call `.summary()` or `pf.etable()`) |
| Dynamic SE switching | No (re-run model) | Yes (`fit.vcov(...)`) |
| Multi-model syntax | Manual loops | Built-in (`csw0`, `sw`, etc.) |
| SSC defaults (two-way) | `G_df = "conventional"` | `G_df = "min"` |
| SSC defaults (HC3) | `k_adj = False` | `k_adj = True` |
| Missing in cluster var | Silently drops | Error — must drop manually |
| Singleton FE | Auto-drop (reghdfe) | Auto-drop |
| First-stage for IV | `first` option | `iv._model_1st_stage` |
| GPU acceleration | Not available | CuPy / JAX backends |
