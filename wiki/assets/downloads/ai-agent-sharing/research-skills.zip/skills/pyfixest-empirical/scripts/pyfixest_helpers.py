"""
pyfixest_helpers.py — Utility functions for PyFixest empirical workflows.

Usage: Copy to your project or import directly.
"""

import numpy as np
import pandas as pd


def check_cluster_na(df: pd.DataFrame, cluster_vars: list[str]) -> pd.DataFrame:
    """
    Check for NaN in cluster variables and return cleaned DataFrame.
    PyFixest does not support clustering on variables with missing values.

    Args:
        df: Input DataFrame
        cluster_vars: List of cluster variable names (e.g., ["firm_id", "year"])

    Returns:
        Cleaned DataFrame with NaN rows in cluster vars dropped.
        Prints count of dropped rows.
    """
    n_before = len(df)
    df_clean = df.dropna(subset=cluster_vars)
    n_after = len(df_clean)
    n_dropped = n_before - n_after
    if n_dropped > 0:
        print(f"⚠️  Dropped {n_dropped} rows ({n_dropped/n_before:.1%}) "
              f"with NaN in cluster variables: {cluster_vars}")
    return df_clean


def create_relative_time(
    df: pd.DataFrame,
    time_col: str,
    treatment_time_col: str,
    never_treated_value: float = 0,
    bin_min: int = -5,
    bin_max: int = 10,
) -> pd.DataFrame:
    """
    Create relative time and binned relative time variables for event studies.

    Args:
        df: Panel DataFrame
        time_col: Calendar time column (e.g., "year")
        treatment_time_col: Column with first treatment period (e.g., "g")
        never_treated_value: Value in treatment_time_col indicating never-treated (default: 0)
        bin_min: Minimum relative time bin (default: -5)
        bin_max: Maximum relative time bin (default: 10)

    Returns:
        DataFrame with added columns: rel_year, rel_year_binned
    """
    df = df.copy()

    # Relative time
    df["rel_year"] = df[time_col] - df[treatment_time_col]

    # Set never-treated to NaN
    never_treated_mask = df[treatment_time_col] == never_treated_value
    df.loc[never_treated_mask, "rel_year"] = np.nan

    # Binned version
    df["rel_year_binned"] = df["rel_year"].clip(bin_min, bin_max)

    n_never = never_treated_mask.sum()
    print(f"Created rel_year: {df['rel_year'].notna().sum()} treated obs, "
          f"{n_never} never-treated obs (set to NaN)")
    print(f"Binned to [{bin_min}, {bin_max}]")

    return df


def diagnose_iv(iv_fit) -> dict:
    """
    Print and return IV diagnostic statistics.

    Args:
        iv_fit: A fitted IV model from pf.feols() with IV specification

    Returns:
        Dictionary with diagnostic values
    """
    diagnostics = {}

    # First-stage F
    f_stat = iv_fit._f_stat_1st_stage
    diagnostics["first_stage_F"] = f_stat
    print(f"First-stage F-statistic: {f_stat:.2f}")

    if f_stat < 10:
        print("  ⚠️  F < 10 — potential weak instrument problem")
    elif f_stat < 20:
        print("  ⚠️  F in [10, 20] — borderline; consider robust weak-IV inference")
    else:
        print("  ✓  F > 20 — strong first stage")

    # Effective F (Olea-Pflueger)
    try:
        iv_fit.IV_Diag()
        eff_f = iv_fit._eff_F
        diagnostics["effective_F"] = eff_f
        print(f"Effective F-statistic (Olea-Pflueger): {eff_f:.2f}")
    except Exception as e:
        print(f"Could not compute effective F: {e}")

    # First stage summary
    print("\n--- First Stage ---")
    iv_fit._model_1st_stage.summary()

    return diagnostics


def compare_se_types(fit, cluster_var: str = None) -> pd.DataFrame:
    """
    Compare coefficient estimates under different SE types.
    Useful for robustness checks.

    Args:
        fit: A fitted Feols model
        cluster_var: Optional cluster variable name for CRV1/CRV3

    Returns:
        DataFrame comparing SE across supported types
    """
    results = {}

    def _try_add_se(label: str, vcov) -> None:
        try:
            results[label] = fit.vcov(vcov).tidy()["Std. Error"]
        except Exception:
            return

    # IID
    tidy_iid = fit.vcov("iid").tidy()
    results["SE_iid"] = tidy_iid["Std. Error"]

    # HC1
    _try_add_se("SE_HC1", "HC1")

    # HC3
    _try_add_se("SE_HC3", "HC3")

    if cluster_var:
        # CRV1
        _try_add_se(f"SE_CRV1({cluster_var})", {"CRV1": cluster_var})

        # CRV3
        _try_add_se(f"SE_CRV3({cluster_var})", {"CRV3": cluster_var})

    # Estimates (same for all SE types)
    results["Estimate"] = tidy_iid["Estimate"]

    df_result = pd.DataFrame(results)
    # Reorder columns
    cols = ["Estimate"] + [c for c in df_result.columns if c != "Estimate"]
    return df_result[cols]


def export_etable_to_latex(
    fits: list,
    filename: str,
    labels: dict = None,
    felabels: dict = None,
    caption: str = None,
) -> None:
    """
    Export PyFixest etable to LaTeX file.

    Args:
        fits: List of fitted models
        filename: Output filename (without .tex extension)
        labels: Variable label dict
        felabels: FE label dict
        caption: Table caption
    """
    import pyfixest as pf

    table = pf.etable(
        fits,
        labels=labels or {},
        felabels=felabels or {},
        caption=caption or "",
        type="tex",
    )

    outpath = f"{filename}.tex"
    with open(outpath, "w") as f:
        f.write(str(table))
    print(f"LaTeX table saved to: {outpath}")
