---
name: referee-review
description: Audit empirical economics results before final tables or prose, focusing on identification, robustness, mechanisms, and readiness. Use paper-review for a complete manuscript and paper-editor for an editorial decision.
---

# Referee Review

Use this skill as an internal quality gate before treating empirical results as writing-ready.

## Inputs

The review should use as many of these as are available:

- research question and identification summary
- design note or plan
- main regression results
- robustness output
- mechanism and heterogeneity output
- draft tables or figures

If core context is missing, say what is missing before making strong claims.

## Review dimensions

Evaluate these seven dimensions:

1. Identification
2. Specification
3. Data and sample
4. Robustness
5. Mechanisms and heterogeneity
6. Magnitude and economic significance
7. Overclaiming

For each dimension, assign one verdict:

- `sound`
- `concern`
- `critical`

## Output contract

Default response structure:

### Overall assessment

### Detailed findings by dimension

### Priority fixes

### Can writing proceed?

## Blocking rule

If any dimension is `critical`:

- do not treat the project as ready for final writing
- convert the issue into concrete remedial tasks
- hand back to `empirical-workflow`, the relevant implementation skill, or a formal plan revision under `.codex/PLANS.md`

## Rules

- Be skeptical, specific, and non-theatrical.
- Do not give credit for checks that were promised but not actually shown.
- Do not convert suggestive mechanism evidence into proof.
- Use `paper-review` for a fuller manuscript diagnostic and `paper-editor` for an editorial pipeline; this skill is the lighter internal gate for ongoing empirical work.
