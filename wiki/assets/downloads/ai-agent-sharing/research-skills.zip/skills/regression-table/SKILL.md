---
name: regression-table
description: Create publication-quality regression tables in DOCX or LaTeX from structured econometric results. Use for formatting and validating estimation outputs; use pyfixest-empirical for model estimation.
---

# Regression Table

Convert structured estimates into a journal-style table without changing the underlying model or numbers.

## Workflow

1. Identify the table's claim, dependent variable, columns, sample definitions, fixed effects, inference method, and required diagnostics.
2. Verify coefficients, standard errors, p-values or stars, sample sizes, and model metadata against the estimation output.
3. Read `references/TABLE_SPEC.md` for the format policy and JSON schema.
4. Create a small JSON specification and run `scripts/build_table.py` for ordinary DOCX or LaTeX output.
5. Use a custom implementation only when the target journal requires unsupported multi-panel or merged-header behavior.
6. Reopen DOCX output or compile LaTeX, then compare every displayed number with the source results.

## Command

```bash
python "$SKILL_DIR/scripts/build_table.py" table_spec.json
```

Resolve `SKILL_DIR` from the active skill location. The builder is skill infrastructure and uses the shared interpreter; project estimation code remains in the project's own environment.

## Boundaries

- Preserve the user's requested precision and journal style when supplied.
- Do not infer significance stars without p-values or an explicit source.
- Do not silently omit failed, missing, or non-comparable models.
- Hand plotting to `academic-figure` and estimation to the relevant econometric skill.

## Output Contract

Return the table path, source models included, formatting profile, validation performed, and any discrepancies that require manual review.
