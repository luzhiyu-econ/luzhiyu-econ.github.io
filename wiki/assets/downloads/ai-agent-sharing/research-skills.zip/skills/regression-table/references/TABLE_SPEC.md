# Regression Table Policy

Use this policy for journal-style economics regression tables. The bundled
`scripts/build_table.py` implements the ordinary DOCX and LaTeX route.

## Input Schema

The builder accepts UTF-8 JSON with these fields:

```json
{
  "title": "Table 2. Baseline Results",
  "dependent_variable": "Outcome",
  "column_labels": ["Full sample", "Group A"],
  "variables": [
    {"label": "Treatment", "coef": ["0.12345***", "0.10120**"],
     "se": [0.02001, 0.04300]}
  ],
  "indicators": [
    {"label": "Year FE", "values": ["Y", "Y"]}
  ],
  "statistics": [
    {"label": "N", "values": [125830, 89420]},
    {"label": "R²", "values": [0.23456, 0.19872]}
  ],
  "note": "Standard errors clustered by city are in parentheses.",
  "output": "06_manuscripts/tables/table2.docx"
}
```

`variables` and `output` are required. Every value array must match the
length of `column_labels`. Coefficients may be preformatted strings when
significance stars are required.

## Universal Formatting

- Coefficients, standard errors, and R² use five decimals unless the target
  journal explicitly requires another precision.
- Standard errors appear in parentheses immediately below coefficients.
- Stars attach directly to coefficients: `* p<0.10`, `** p<0.05`,
  `*** p<0.01`.
- N uses thousands separators. Negative signs use U+2212 in DOCX.
- Variable names are italic; controls and fixed-effect labels are not.
- Empty cells remain blank. Fixed-effect indicators use `Y`.

## Three-Line Layout

- Use a thick top rule, a thin rule below column numbers, and a thick bottom
  rule. Do not use vertical rules or body-row gridlines.
- Put the dependent variable above the column labels. Number columns with
  full-width parentheses: `（1）（2）`.
- List the core interaction before its main effect when interpretation
  depends on the interaction.
- Place controls and fixed-effect indicators after coefficient rows, followed
  by N, R², and design-specific diagnostics.

## Heterogeneity and Panels

- Use explicit group labels and define the split in the note.
- Report each panel's own N and fit statistics.
- Do not compare coefficients across groups as evidence of a difference unless
  the relevant cross-group test is reported.
- Use panel dividers only when several related specifications share one table.

## Notes

Every note should identify the variance estimator or clustering level, explain
non-obvious samples and variables, define grouping rules, and state the star
legend. Do not claim robustness or causality in the note.

## DOCX

- Times New Roman, 10 pt body, 9 pt standard errors and notes.
- Center numeric cells and left-align row labels.
- Set explicit borders so Word does not inherit unwanted gridlines.
- Reopen the output and inspect representative rows after saving.

## LaTeX

- Use `booktabs` commands and no vertical separators.
- Escape user-provided labels and keep notes within the table width.
- Compile the surrounding manuscript when available.

## Final Checks

Verify column widths, row counts, precision, stars, standard errors, sample
sizes, fixed-effect indicators, notes, and consistency with the underlying
estimation output. A visually correct table with mismatched numbers fails QA.
