#!/usr/bin/env python3
"""Build a regression table from a small JSON specification."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


def display(value: Any, digits: int = 5) -> str:
    if value is None:
        return ""
    if isinstance(value, float):
        return f"{value:.{digits}f}".replace("-", "−")
    if isinstance(value, int):
        return f"{value:,}"
    return str(value).replace("-", "−")


def load_spec(path: Path) -> dict[str, Any]:
    spec = json.loads(path.read_text(encoding="utf-8"))
    required = {"title", "dependent_variable", "variables", "output"}
    missing = sorted(required - spec.keys())
    if missing:
        raise ValueError(f"Missing required keys: {', '.join(missing)}")
    ncols = len(spec.get("column_labels", []))
    if ncols == 0:
        raise ValueError("column_labels must contain at least one column")
    for section in ("variables", "indicators", "statistics"):
        for row in spec.get(section, []):
            values = row.get("values", row.get("coef", []))
            if len(values) != ncols:
                raise ValueError(f"{section} row {row.get('label')} has wrong width")
            if section == "variables" and len(row.get("se", [])) != ncols:
                raise ValueError(f"variable row {row.get('label')} has wrong SE width")
    return spec


def latex_escape(text: str) -> str:
    replacements = {"&": r"\&", "%": r"\%", "_": r"\_", "#": r"\#"}
    return "".join(replacements.get(char, char) for char in text)


def render_latex(spec: dict[str, Any], output: Path) -> None:
    ncols = len(spec["column_labels"])
    rows = [r"\begin{table}[htbp]", r"\centering"]
    rows.append(f"\\caption{{{latex_escape(spec['title'])}}}")
    rows.append(r"\begin{tabular}{l" + "c" * ncols + "}")
    rows.append(r"\toprule")
    dv = latex_escape(spec["dependent_variable"])
    rows.append(" & \\multicolumn{%d}{c}{%s} \\\\" % (ncols, dv))
    labels = [latex_escape(str(v)) for v in spec["column_labels"]]
    rows.append(" & " + " & ".join(labels) + r" \\")
    rows.append(" & " + " & ".join(f"（{i}）" for i in range(1, ncols + 1)) + r" \\")
    rows.append(r"\midrule")
    for row in spec["variables"]:
        coef = [latex_escape(display(v)) for v in row["coef"]]
        se = [f"({latex_escape(display(v))})" if v not in (None, "") else "" for v in row["se"]]
        rows.append("\\textit{%s} & %s \\\\" % (latex_escape(row["label"]), " & ".join(coef)))
        rows.append(" & " + " & ".join(se) + r" \\")
    for row in spec.get("indicators", []):
        vals = [latex_escape(display(v)) for v in row["values"]]
        rows.append(latex_escape(row["label"]) + " & " + " & ".join(vals) + r" \\")
    for row in spec.get("statistics", []):
        vals = [latex_escape(display(v)) for v in row["values"]]
        rows.append(latex_escape(row["label"]) + " & " + " & ".join(vals) + r" \\")
    rows.extend([r"\bottomrule", r"\end{tabular}"])
    if spec.get("note"):
        rows.append("\\begin{minipage}{0.95\\linewidth}\\footnotesize " + latex_escape(spec["note"]) + r"\end{minipage}")
    rows.append(r"\end{table}")
    output.write_text("\n".join(rows) + "\n", encoding="utf-8")


def set_cell_border(cell: Any, *, top: str = "nil", bottom: str = "nil") -> None:
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn

    tc_pr = cell._tc.get_or_add_tcPr()
    borders = tc_pr.first_child_found_in("w:tcBorders")
    if borders is None:
        borders = OxmlElement("w:tcBorders")
        tc_pr.append(borders)
    for edge, style, size in (("top", top, "12"), ("bottom", bottom, "12"), ("left", "nil", "0"), ("right", "nil", "0")):
        tag = "w:" + edge
        element = borders.find(qn(tag))
        if element is None:
            element = OxmlElement(tag)
            borders.append(element)
        element.set(qn("w:val"), style)
        element.set(qn("w:sz"), size)


def add_cell_text(cell: Any, text: str, *, italic: bool = False, size: int = 10) -> None:
    paragraph = cell.paragraphs[0]
    paragraph.alignment = 1
    run = paragraph.add_run(text)
    run.italic = italic
    run.font.name = "Times New Roman"
    run.font.size = __import__("docx").shared.Pt(size)


def render_docx(spec: dict[str, Any], output: Path) -> None:
    from docx import Document
    from docx.enum.table import WD_TABLE_ALIGNMENT
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.shared import Inches, Pt

    ncols = len(spec["column_labels"])
    document = Document()
    section = document.sections[0]
    section.left_margin = section.right_margin = Inches(1)
    title = document.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title_run = title.add_run(spec["title"])
    title_run.bold = True
    title_run.font.name = "Times New Roman"
    title_run.font.size = Pt(11)

    table = document.add_table(rows=0, cols=ncols + 1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False

    def add_row(label: str, values: list[Any], *, italic: bool = False) -> Any:
        row = table.add_row()
        add_cell_text(row.cells[0], label, italic=italic)
        row.cells[0].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.LEFT
        for index, value in enumerate(values, 1):
            add_cell_text(row.cells[index], display(value))
        return row

    dv_row = add_row("", [spec["dependent_variable"]] + [""] * (ncols - 1))
    label_row = add_row("", spec["column_labels"])
    number_row = add_row("", [f"（{i}）" for i in range(1, ncols + 1)])
    for cell in dv_row.cells:
        set_cell_border(cell, top="single")
    for cell in number_row.cells:
        set_cell_border(cell, bottom="single")

    for item in spec["variables"]:
        add_row(item["label"], item["coef"], italic=True)
        se_values = [f"({display(v)})" if v not in (None, "") else "" for v in item["se"]]
        se_row = add_row("", se_values)
        for cell in se_row.cells:
            for run in cell.paragraphs[0].runs:
                run.font.size = Pt(9)
    for item in spec.get("indicators", []):
        add_row(item["label"], item["values"])
    stat_rows = [add_row(item["label"], item["values"], italic=True) for item in spec.get("statistics", [])]
    last_row = stat_rows[-1] if stat_rows else table.rows[-1]
    for cell in last_row.cells:
        set_cell_border(cell, bottom="single")

    if spec.get("note"):
        note = document.add_paragraph()
        run = note.add_run(spec["note"])
        run.font.name = "Times New Roman"
        run.font.size = Pt(9)
    document.save(output)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("spec", type=Path, help="JSON table specification")
    args = parser.parse_args()
    spec = load_spec(args.spec)
    output = Path(spec["output"])
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.suffix.lower() == ".tex":
        render_latex(spec, output)
    elif output.suffix.lower() == ".docx":
        render_docx(spec, output)
    else:
        raise ValueError("output must end in .docx or .tex")
    print(f"OK: {output}")


if __name__ == "__main__":
    main()
