---
name: stata-regression
description: Design, write, revise, validate, and run reproducible Stata regression do-files for empirical research. Use for OLS, fixed-effects, panel, IV, nonlinear, DiD, robustness, and publication-table workflows; use regression-table only when the task is purely final table formatting.
---

# Stata regression do-files

Produce a readable `.do` file whose estimand, sample, fixed effects, inference,
dependencies, inputs, and outputs can be audited. Preserve project conventions
when they are explicit; otherwise use the standards in this skill.

## Workflow

1. Inspect `AGENTS.md`, the master/setup do-file, nearby analysis do-files, data
   documentation, and output conventions. Do not invent paths or variable names.
2. Resolve the estimand and high-impact choices: outcome, key regressor or
   treatment, sample, controls, fixed effects, weights, clustering level, and
   output format. Surface unresolved identification or inference choices.
3. Read [references/do-file-standard.md](references/do-file-standard.md). For
   model and table decisions, also read
   [references/regression-checklist.md](references/regression-checklist.md).
4. Start from [assets/regression-template.do](assets/regression-template.do)
   when no stronger project template exists. Adapt its Stata `version` to the
   project target; do not silently update semantics.
5. Use factor-variable syntax for categories and interactions. Match standard
   errors to the assignment or shock level. Never infer causality from a
   regression without a stated design.
6. Store estimates immediately, report sample size and inference details, and
   make table notes match the actual specification. Do not silently install
   packages inside an analysis do-file; check them and document setup instead.
7. Run `scripts/lint_do_file.py <file>` with the shared Python venv. Fix errors
   and review warnings rather than mechanically suppressing them.
8. When data and Stata are available, execute the file through `stata-mcp`, read
   the full log/output, and verify expected table or figure files. A successful
   return code alone is not evidence that the specification is correct.

## Boundaries

- Never overwrite raw data or change source files merely to make code run.
- Do not add controls, fixed effects, clustering, winsorization, weights, or
  sample restrictions without an empirical rationale or explicit placeholder.
- Keep exploratory and preregistered specifications visibly separated.
- For specialized estimators, consult the installed `stata` reference skill
  and live Stata help before using options that are not already verified.
