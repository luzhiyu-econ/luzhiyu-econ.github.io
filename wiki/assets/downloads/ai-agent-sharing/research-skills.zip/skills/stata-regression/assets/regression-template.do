/*******************************************************************************
PROJECT:      [project name]
PURPOSE:      [estimand and table or figure produced]
INPUTS:       [analysis-ready .dta file]
OUTPUTS:      [table and log files]
DEPENDENCIES: estout, reghdfe
DESIGN:       [unit, treatment or key regressor, fixed effects, inference]
*******************************************************************************/

version 19.5
clear all
macro drop _all
set more off
set varabbrev off
capture log close _all

* 路径应来自主 do-file；若本文件独立运行，只需在此修改项目根目录。
global project "[replace with project root]"
global data    "${project}/data"
global output  "${project}/output"

log using "${output}/regression.log", replace text name(regression)

* 在 setup 中安装依赖；分析文件只检查并明确失败。
foreach command in esttab reghdfe {
    capture which `command'
    if _rc {
        display as error "Required command not installed: `command'"
        exit 199
    }
}

use "${data}/analysis.dta", clear
confirm variable OUTCOME KEY_REGRESSOR CLUSTER_ID

* 用单一标记集中记录主样本限制和缺失值处理。
generate byte sample_main = !missing(OUTCOME, KEY_REGRESSOR, CLUSTER_ID)
count if sample_main
assert r(N) > 0

local controls "CONTROL_1 CONTROL_2"
eststo clear

quietly reghdfe OUTCOME KEY_REGRESSOR `controls' if sample_main, ///
    absorb(FE_1 FE_2) vce(cluster CLUSTER_ID)
eststo main

quietly summarize OUTCOME if sample_main
estadd scalar outcome_mean = r(mean)

esttab main using "${output}/main-results.tex", replace booktabs label ///
    b(3) se(3) star(* 0.10 ** 0.05 *** 0.01) ///
    stats(N outcome_mean, labels("Observations" "Outcome mean")) ///
    addnote("Standard errors clustered by CLUSTER_ID.")

confirm file "${output}/main-results.tex"
log close regression
