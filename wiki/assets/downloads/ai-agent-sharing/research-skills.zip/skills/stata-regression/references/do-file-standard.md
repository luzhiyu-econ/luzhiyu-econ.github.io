# Do-file standard

Use project rules first. Otherwise apply this baseline, adapted from the World
Bank DIME Analytics coding guide and Stata's reproducibility features.

## Structure

- Header: purpose, inputs, outputs, dependencies, and the empirical role of the
  file. Do not fabricate author names or dates.
- Put `version` near the top. Preserve the repository's semantic target; for a
  new local file the installed target is StataNow/MP 19.5.
- Use `set more off`, `set varabbrev off`, and `capture log close _all`.
- Define or inherit one project root and named input/output directories. Avoid
  `cd`, user-specific absolute paths, and ambiguous omitted extensions.
- Open a named text log and close it. Record key package versions with `which`
  in setup or environment logs.
- Organize sections as setup, data/sample checks, variable construction,
  estimation, post-estimation, export, and closing checks.

## Style and safety

- Use lowercase descriptive names, four-space indentation, spaces around
  operators, blank lines between logical blocks, and `///` near 80 characters.
- Comments explain why a choice is made; commands should remain self-documenting.
- Avoid variable abbreviations, fragile wildcards, and `#delimit` in analysis.
- Treat raw inputs as read-only. Save only derived data to declared intermediate
  or output paths.
- Use `confirm`, `isid`, `assert`, `count`, and merge diagnostics at the point
  where their assumptions matter. Handle `_rc` after intentional `capture`.
- Guard comparisons because Stata missing values sort above finite numbers.
- Seed any randomized operation and document the seed.

## Regression-file checks

- Create an explicit analysis-sample indicator when restrictions are material;
  report how observations are lost rather than scattering `drop` statements.
- Label constructed variables and keep transformations auditable.
- Store each estimate immediately with a meaningful model name.
- Table rows and notes must state estimator, fixed effects, controls, weights,
  clustering, and sample differences actually used in each column.
- Export only to declared output paths and verify that expected files exist.

Sources: [DIME Data Handbook](https://worldbank.github.io/dime-data-handbook/),
[Stata manuals](https://www.stata.com/manuals/), and
[AEA replication guidance](https://aeadataeditor.github.io/).
