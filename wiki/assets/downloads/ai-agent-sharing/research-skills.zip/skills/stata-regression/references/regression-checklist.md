# Regression and reporting checklist

## Before coding

- State the estimand and unit of observation.
- Identify how treatment or the key regressor varies and where dependence in
  errors is plausible; this determines clustering more than data convenience.
- Separate predetermined controls from post-treatment variables.
- Establish the analysis sample, missing-data policy, weights, fixed effects,
  reference categories, and preregistered versus exploratory status.
- For panels, verify identifier-time uniqueness before `xtset` or absorption.

## Estimation

- Use `i.` and `c.` factor-variable notation; use `##` when main effects belong
  in the model and set reference groups explicitly when interpretation depends
  on them.
- Use `reghdfe` for multiple high-dimensional fixed effects and report within
  fit measures; use an estimator appropriate to the outcome and design.
- Cluster at the treatment-assignment or shock level when required. Flag few
  clusters and consider design-appropriate small-cluster inference.
- For IV, never hand-code two-stage standard errors. Report first-stage strength,
  instrument count, endogenous variables, and relevant identification tests.
- For DiD or event studies, distinguish common-timing TWFE from staggered
  adoption and use an estimator valid for the design.
- Store estimates before another estimation command overwrites `e()` results.

## Diagnostics and robustness

- Check sample size and cluster count across specifications.
- Inspect omitted coefficients, collinearity, support, leverage, and residual
  behavior when relevant; diagnostics do not substitute for identification.
- Make robustness checks targeted: alternative samples, functional forms,
  inference, fixed effects, or estimators should answer a stated concern.
- Do not use significance changes as the sole robustness criterion.

## Tables

- Use stable model names and preview tables before export.
- Report coefficients with standard errors or confidence intervals, exact
  sample sizes, outcome mean when substantively useful, and the fit measure
  appropriate to the estimator.
- Show fixed effects, controls, weights, and clustering with explicit indicators
  or column notes. Never claim an element that the stored model lacks.
- Keep variable labels and precision consistent; define stars in the note.
- Export machine-readable output alongside presentation output when practical.
