#!/usr/bin/env python3
"""对回归 do-file 做轻量、确定性的结构与安全检查。"""

from __future__ import annotations

import argparse
import re
from pathlib import Path


def add(findings: list[tuple[str, int, str]], level: str, line: int, message: str) -> None:
    findings.append((level, line, message))


def lint(path: Path, component: bool) -> list[tuple[str, int, str]]:
    text = path.read_text(encoding="utf-8")
    lines = text.splitlines()
    lower = text.lower()
    findings: list[tuple[str, int, str]] = []

    required = [
        (r"(?m)^\s*version\s+\d", "缺少 version 语义版本"),
        (r"(?m)^\s*set\s+more\s+off\b", "缺少 set more off"),
        (r"(?m)^\s*set\s+varabbrev\s+off\b", "缺少 set varabbrev off"),
    ]
    for pattern, message in required:
        if not re.search(pattern, lower):
            add(findings, "ERROR", 0, message)

    for field in ("purpose:", "inputs:", "outputs:"):
        if field not in lower:
            add(findings, "WARN", 0, f"文件头缺少 {field[:-1].upper()}")

    if not component:
        if not re.search(r"(?m)^\s*log\s+using\b", lower):
            add(findings, "ERROR", 0, "独立 do-file 缺少 log using")
        if not re.search(r"(?m)^\s*log\s+close\b", lower):
            add(findings, "ERROR", 0, "独立 do-file 缺少 log close")

    risky_random = re.search(r"\b(runiform|rnormal|sample|bsample|simulate)\b", lower)
    if risky_random and not re.search(r"(?m)^\s*set\s+seed\b", lower):
        add(findings, "ERROR", 0, "包含随机操作但未 set seed")

    return scan_lines(lines, findings)


def scan_lines(lines: list[str], findings: list[tuple[str, int, str]]) -> list[tuple[str, int, str]]:
    for number, line in enumerate(lines, start=1):
        stripped = line.strip()
        if "\t" in line:
            add(findings, "WARN", number, "使用四个空格缩进，不要使用 tab")
        if len(line) > 100:
            add(findings, "WARN", number, "行长超过 100；在语义边界用 /// 换行")
        if re.match(r"(?i)^cd\s+", stripped):
            add(findings, "ERROR", number, "避免 cd；使用项目根目录宏构造完整路径")
        if re.search(r'(?i)["\'](?:/home/|/users/|[a-z]:[/\\]users[/\\])', line):
            add(findings, "ERROR", number, "发现用户专属硬编码路径")
        if re.search(r"(?i)^\s*save\b.*(?:[\"']raw[/\\]|[/\\]raw[/\\]).*,\s*replace", line):
            add(findings, "ERROR", number, "禁止覆盖 raw 数据")
        if re.match(r"(?i)^\s*merge\b", line):
            window = "\n".join(lines[number : number + 12]).lower()
            if "_merge" not in window:
                add(findings, "WARN", number, "merge 后 12 行内未见 _merge 诊断")
    return findings


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("path", type=Path)
    parser.add_argument("--component", action="store_true", help="允许日志由 master do-file 管理")
    parser.add_argument("--strict", action="store_true", help="将警告也视为失败")
    args = parser.parse_args()
    if not args.path.is_file():
        parser.error(f"not a file: {args.path}")

    findings = lint(args.path, args.component)
    for level, line, message in findings:
        location = f":{line}" if line else ""
        print(f"{level} {args.path}{location} {message}")
    errors = sum(level == "ERROR" for level, _, _ in findings)
    warnings = sum(level == "WARN" for level, _, _ in findings)
    print(f"SUMMARY errors={errors} warnings={warnings}")
    return 1 if errors or (args.strict and warnings) else 0


if __name__ == "__main__":
    raise SystemExit(main())
