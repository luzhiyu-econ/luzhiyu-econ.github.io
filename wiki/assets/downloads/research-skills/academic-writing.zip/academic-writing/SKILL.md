---
name: academic-writing
description: 撰写或实质性改写中文经济学论文正文，包括引言、文献综述、研究设计、实证结果、机制、异质性、结论与政策启示。用于生成新段落或重组论证。若用户只要求检查已有文本的语体、降低 AI 痕迹或做语言润色，使用 academic-tone；表格和绘图分别使用 regression-table 与 academic-figure。
---

# Chinese Academic Economics Writing

负责生成新正文、补充论证或实质性重组中文经济学论文。只做已有文字的语体清理时转用 `academic-tone`。

## Reference Router

每次读取：

- `references/style_rules.md`：通用学术语体。
- `references/bad_patterns.md`：AI 写作坏习惯与自检。
- `references/section_spine.md`：跨节叙事主线。

再按任务读取一个 section 规范：

- 引言：`references/section_introduction.md`
- 文献综述：`references/section_literature.md`
- 研究假说：`references/section_hypothesis.md`
- 研究设计：`references/section_design.md`
- 实证、机制、异质性：`references/section_results.md`
- 结论与政策启示：`references/section_conclusion.md`

## Workflow

1. 从用户材料、项目 README 和现有前后文提取研究问题、核心结果、识别威胁与量级锚点；信息充分时直接执行。
2. 明确当前段落或章节在全文中的作用：承接什么问题、提供什么证据、向后留下什么待解释内容。
3. 按对应 section 规范撰写，并保持变量、样本、方法和结论与实证材料一致。
4. 对照 `bad_patterns.md` 清除机械排列、填充短语、对称句壳、术语漂移和空洞拔高。
5. 对照 `section_spine.md` 检查跨节衔接、偏误方向和量级解释；发现问题直接修正。

## Boundaries

- 不编造文献、结果、样本定义或识别细节。
- 回归表由 `regression-table` 生成，数据图由 `academic-figure` 生成。
- 论文评审与投稿决策分别使用 `paper-review` 和 `paper-editor`。
- 需要 Word 成品时再调用 `docx` 或 `journal-docx`。

## Output

默认直接给出可粘贴进论文的正文，不附无关解释。若证据不足以支持某个判断，明确标记缺口，不用套话填补。
