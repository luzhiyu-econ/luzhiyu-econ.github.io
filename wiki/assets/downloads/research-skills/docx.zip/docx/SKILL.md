---
name: docx
description: Create, inspect, or edit generic Microsoft Word DOCX files, including formatting, images, tracked changes, comments, and text extraction. Use journal-docx for target-journal formatting.
---

# DOCX

Work on Word documents with the least complex reliable method.

## Route the task

- Read or extract text: use pandoc or `python -m markitdown` from the active environment.
- Create a new document: use docx-js.
- Edit an existing document: unpack OOXML, modify only required parts, then repack.
- Accept tracked changes: use scripts/accept_changes.py.
- Add or inspect comments: use scripts/comment.py.
- Render for visual inspection after material layout changes.

## Detailed guidance

The complete reference is in references/full-guide.md. Read only the relevant
section:

- Creation, styles, lists, tables, images, links, footnotes, and layout.
- Editing, schema compliance, tracked changes, comments, and raw OOXML.
- Dependency setup, validation, and smoke testing.

Search headings first with rg -n '^#{2,3} ' references/full-guide.md.

## Quality gate

Validate the package after editing. Reopen it with an independent parser and,
for user-facing layout changes, render representative pages to confirm that
content is visible, aligned, and not clipped.
