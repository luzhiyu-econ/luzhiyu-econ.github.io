/**
 * smoke-test-docxjs.js
 * 验证 docx-js (npm docx) 在当前仓库环境下能正常生成 .docx 文件。
 * 运行方式: node .codex/skills/docx/scripts/smoke-test-docxjs.js
 * 输出: /tmp/docxjs-smoke-test.docx
 */

const fs = require("fs");
const path = require("path");
const {
  Document,
  Packer,
  Paragraph,
  TextRun,
  Table,
  TableRow,
  TableCell,
  HeadingLevel,
  AlignmentType,
  BorderStyle,
  WidthType,
  ShadingType,
  Header,
  Footer,
  PageNumber,
} = require("docx");

const OUTPUT = path.join("/tmp", "docxjs-smoke-test.docx");

const border = {
  style: BorderStyle.SINGLE,
  size: 1,
  color: "000000",
};
const borders = { top: border, bottom: border, left: border, right: border };

const doc = new Document({
  styles: {
    default: {
      document: { run: { font: "SimSun", size: 24 } },
    },
    paragraphStyles: [
      {
        id: "Heading1",
        name: "Heading 1",
        basedOn: "Normal",
        next: "Normal",
        quickFormat: true,
        run: { size: 32, bold: true, font: "SimHei" },
        paragraph: {
          spacing: { before: 240, after: 240 },
          outlineLevel: 0,
        },
      },
    ],
  },
  sections: [
    {
      properties: {
        page: {
          size: { width: 11906, height: 16838 },
          margin: { top: 1440, right: 1800, bottom: 1440, left: 1800 },
        },
      },
      headers: {
        default: new Header({
          children: [
            new Paragraph({
              children: [new TextRun({ text: "docx-js Smoke Test", italics: true, size: 18, color: "888888" })],
              alignment: AlignmentType.RIGHT,
            }),
          ],
        }),
      },
      footers: {
        default: new Footer({
          children: [
            new Paragraph({
              children: [new TextRun("Page "), new TextRun({ children: [PageNumber.CURRENT] })],
              alignment: AlignmentType.CENTER,
            }),
          ],
        }),
      },
      children: [
        new Paragraph({
          heading: HeadingLevel.HEADING_1,
          children: [new TextRun("Smoke Test: docx-js 环境验证")],
        }),
        new Paragraph({
          children: [new TextRun("本文档由 docx-js 自动生成，用于验证 Node 环境中 docx 包能正常工作。")],
          spacing: { after: 200 },
        }),
        new Paragraph({
          children: [
            new TextRun({ text: "English text: ", bold: true }),
            new TextRun("The quick brown fox jumps over the lazy dog."),
          ],
          spacing: { after: 200 },
        }),
        new Paragraph({
          children: [
            new TextRun({ text: "中文文本: ", bold: true }),
            new TextRun("数字经济背景下企业创新的实证研究。"),
          ],
          spacing: { after: 200 },
        }),
        new Table({
          width: { size: 8306, type: WidthType.DXA },
          columnWidths: [2768, 2769, 2769],
          rows: [
            new TableRow({
              children: ["变量", "均值", "标准差"].map(
                (text) =>
                  new TableCell({
                    borders,
                    width: { size: 2769, type: WidthType.DXA },
                    shading: { fill: "D5E8F0", type: ShadingType.CLEAR },
                    margins: { top: 80, bottom: 80, left: 120, right: 120 },
                    children: [
                      new Paragraph({
                        children: [new TextRun({ text, bold: true })],
                        alignment: AlignmentType.CENTER,
                      }),
                    ],
                  })
              ),
            }),
            ...([
              ["Innovation", "3.45", "1.23"],
              ["Digital", "0.67", "0.47"],
              ["Size", "22.15", "1.34"],
            ].map(
              (row) =>
                new TableRow({
                  children: row.map(
                    (text) =>
                      new TableCell({
                        borders,
                        width: { size: 2769, type: WidthType.DXA },
                        margins: { top: 80, bottom: 80, left: 120, right: 120 },
                        children: [
                          new Paragraph({
                            children: [new TextRun(text)],
                            alignment: AlignmentType.CENTER,
                          }),
                        ],
                      })
                  ),
                })
            )),
          ],
        }),
        new Paragraph({
          children: [new TextRun({ text: "\n", size: 10 })],
        }),
        new Paragraph({
          children: [new TextRun({ text: "验证通过 ✓", bold: true, size: 28 })],
          alignment: AlignmentType.CENTER,
          spacing: { before: 400 },
        }),
      ],
    },
  ],
});

async function main() {
  const buffer = await Packer.toBuffer(doc);
  fs.writeFileSync(OUTPUT, buffer);
  console.log(`SUCCESS: ${OUTPUT} (${buffer.length} bytes)`);
}

main().catch((err) => {
  console.error("FAILED:", err.message);
  process.exit(1);
});
