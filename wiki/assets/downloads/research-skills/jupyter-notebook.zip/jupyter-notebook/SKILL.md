---
name: "jupyter-notebook"
description: "Use when the user asks to create, scaffold, or edit Jupyter notebooks (`.ipynb`) for experiments, explorations, or tutorials; prefer the bundled templates and run the helper script `new_notebook.py` to generate a clean starting notebook."
---


# Jupyter Notebook

创建或定向编辑可复现的 `.ipynb`。项目级 AGENTS.md 对 notebook 的结构要求优先于本通用入口。

## Router

- 探索、实验或假设检验：读取 `references/experiment-patterns.md`。
- 教程或教学演示：读取 `references/tutorial-patterns.md`。
- 需要直接检查 notebook JSON：读取 `references/notebook-structure.md`。
- 完成后读取 `references/quality-checklist.md`。

## Workflow

1. 判断是新建、转换还是局部编辑，并确定 `experiment` 或 `tutorial`。
2. 新建时调用 bundled helper，避免手写 notebook JSON。
3. 编辑现有 notebook 时保留研究目标、TODO、已有探索结果和用户未要求修改的单元格。
4. 按“Markdown 说明目标与粒度 → 读取 → 处理 → 检查”的顺序逐步追加。
5. 每个代码单元只完成一个清晰步骤；不要提前抽象尚未稳定的函数、类或配置。
6. 使用项目级 venv 执行项目代码；skill helper 使用共享解释器。
7. 能运行时从头到尾执行并检查错误、缺失、唯一性与样本量；不能执行时明确说明。

```bash
SKILL_DIR="/path/to/jupyter-notebook"
python "$SKILL_DIR/scripts/new_notebook.py" \
  --kind experiment --title "Compare prompt variants" \
  --out output/jupyter-notebook/compare-prompt-variants.ipynb
```

## Boundaries

- 只修改当前要求的步骤，不重写整个 notebook。
- 同一路径使用两次以上再定义变量。
- 每个中间结果说明一行代表什么。
- 项目缺依赖时在项目目录使用 `uv add`，不要在共享数据目录中创建 `.venv`。

## Output Contract

返回 notebook 路径、修改的单元格范围、执行状态、关键检查结果和未解决问题。
